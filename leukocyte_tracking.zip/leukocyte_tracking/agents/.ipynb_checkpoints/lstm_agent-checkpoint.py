# agents/lstm_agent.py
import torch
import torch.nn as nn
import torch.nn.functional as F
from .base_agent import BaseDetectionAgent  # Add this import


class LSTMDetectionAgent(BaseDetectionAgent):
    def __init__(self, hidden_size=256):
        self.hidden_size = hidden_size
        super().__init__()
        # self.hidden_size = hidden_size
        self.build_model()
        
    def build_model(self):
        # CNN feature extractor
        self.feature_extractor = nn.Sequential(
            nn.Conv2d(1, 32, 3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d((8, 8))
        )
        
        # Convert to sequence
        self.to_sequence = nn.Linear(64 * 8 * 8, self.hidden_size)
        
        # LSTM layers
        self.lstm = nn.LSTM(
            input_size=self.hidden_size,
            hidden_size=self.hidden_size,
            num_layers=2,
            batch_first=True,
            dropout=0.5
        )
        
        # ROI prediction head
        self.roi_head = nn.Sequential(
            nn.Linear(self.hidden_size, 128),
            nn.ReLU(),
            nn.Linear(128, 4)
        )
        
    def forward(self, x):
        batch_size = x.size(0)
        
        # Extract features
        features = self.feature_extractor(x)
        features = features.view(batch_size, -1)
        
        # Convert to sequence
        sequence = self.to_sequence(features)
        sequence = sequence.unsqueeze(1)  # Add sequence length dimension
        
        # LSTM processing
        lstm_out, _ = self.lstm(sequence)
        
        # Predict ROI
        roi = self.roi_head(lstm_out[:, -1, :])
        
        return torch.sigmoid(roi)  # Normalize to [0,1]