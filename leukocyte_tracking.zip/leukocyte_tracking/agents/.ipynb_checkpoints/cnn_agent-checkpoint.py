# agents/cnn_agent.py
import torch
import torch.nn as nn
import torch.nn.functional as F
from .base_agent import BaseDetectionAgent  # Add this import

class CNNDetectionAgent(BaseDetectionAgent):
    def __init__(self):
        super().__init__()
        self.build_model()
        
    def build_model(self):
        # Feature extraction
        self.features = nn.Sequential(
            nn.Conv2d(1, 32, 3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
            
            nn.Conv2d(32, 64, 3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
            
            nn.Conv2d(64, 128, 3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
            
            nn.Conv2d(128, 256, 3, padding=1),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d((4, 4))  # Force output size
        )
        
        # ROI prediction head
        self.roi_head = nn.Sequential(
            nn.Flatten(),
            nn.Linear(256 * 4 * 4, 512),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Linear(256, 4)  # x, y, w, h
        )
        
        # Initialize weights
        self._init_weights()
        
    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)
                
    def forward(self, x):
        # Input shape validation
        if x.dim() != 4:
            raise ValueError(f"Expected 4D input (B,C,H,W), got {x.dim()}D")
            
        # Print shapes for debugging
        print(f"Input shape: {x.shape}")
        
        # Feature extraction
        features = self.features(x)
        print(f"After features: {features.shape}")
        
        # ROI prediction
        roi = self.roi_head(features)
        print(f"ROI output: {roi.shape}")
        
        # Ensure output is normalized to [0,1]
        return torch.sigmoid(roi)