# agents/base_agent.py

import torch
import torch.nn as nn
import numpy as np

class BaseDetectionAgent(nn.Module):
    def __init__(self):
        super().__init__()
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.optimizer = None
        self.criterion = nn.MSELoss()
        self.build_model() 



    def update_weights(self, frame_area, target):
        """
        Update the model weights based on the given frame area and target ROI
        
        Args:
            frame_area (torch.Tensor): Input frame tensor (B, C, H, W)
            target (torch.Tensor): Target ROI coordinates (B, 4) normalized [x, y, w, h]
        
        Returns:
            float: The loss value
        """
        try:
            # Input validation
            if not isinstance(frame_area, torch.Tensor):
                raise ValueError("frame_area must be a torch.Tensor")
            if not isinstance(target, torch.Tensor):
                raise ValueError("target must be a torch.Tensor")
                
            # Ensure correct device
            frame_area = frame_area.to(self.device)
            target = target.to(self.device)
            
            # Print shapes for debugging
            print(f"Frame shape: {frame_area.shape}")
            print(f"Target shape: {target.shape}")
            
            if self.optimizer is None:
                self.optimizer = torch.optim.Adam(self.parameters(), lr=0.001)
            
            self.train()
            self.optimizer.zero_grad()
            
            # Forward pass
            predictions = self(frame_area)
            print(f"Predictions shape: {predictions.shape}")
            
            # Compute loss
            loss = self.criterion(predictions, target)
            print(f"Loss value: {loss.item()}")
            
            # Backward pass
            loss.backward()
            
            # Clip gradients to prevent explosion
            torch.nn.utils.clip_grad_norm_(self.parameters(), max_norm=1.0)
            
            self.optimizer.step()
            
            return loss.item()
            
        except Exception as e:
            print(f"Error in weight update: {e}")
            return float('inf')
    
        finally:
            # Clean up
            torch.cuda.empty_cache()


    def _predictions_to_rect(self, predictions):
        """
        Convert model predictions to QRect
        
        Args:
            predictions (torch.Tensor): Model predictions [x, y, w, h]
        Returns:
            QRect: Rectangle from predictions
        """
        try:
            from PyQt6.QtCore import QRect
            
            # Convert tensor to numpy array
            pred = predictions.cpu().numpy()
            
            # Ensure values are valid
            if any(np.isnan(pred)) or pred[2] <= 0 or pred[3] <= 0:
                print("Invalid prediction values")
                return None
                
            return QRect(
                int(pred[0]),  # x
                int(pred[1]),  # y
                int(pred[2]),  # width
                int(pred[3])   # height
            )
        except Exception as e:
            print(f"Error converting predictions to rect: {e}")
            return None

    def build_model(self):
        pass

    def forward(self, x):
        pass

    def update(self, state, action, reward, next_state):
        pass

    def validate_learning(self, frame, roi_rect):
        """
        Validate if the model is learning correctly
        """
        with torch.no_grad():
            self.eval()
            predictions = self(frame)
            
            # Convert predictions to same format as ROI
            pred_rect = self._predictions_to_rect(predictions[0])
            
            # Calculate IoU between prediction and ground truth
            iou = self._calculate_iou(pred_rect, roi_rect)
            
            print(f"Validation IoU: {iou}")
            return iou > 0.5  # Return True if IoU > 0.5

    def is_trained(self):
        """
        Check if the model has been trained
        """
        try:
            for param in self.parameters():
                if param.requires_grad and param.grad is not None:
                    return True
            return False
        except Exception as e:
            print(f"Error checking if model is trained: {e}")
            return False
    
    def _calculate_iou(self, rect1, rect2):
        """Calculate Intersection over Union between two rectangles"""
        x1 = max(rect1.x(), rect2.x())
        y1 = max(rect1.y(), rect2.y())
        x2 = min(rect1.x() + rect1.width(), rect2.x() + rect2.width())
        y2 = min(rect1.y() + rect1.height(), rect2.y() + rect2.height())
        
        if x2 < x1 or y2 < y1:
            return 0.0
            
        intersection = (x2 - x1) * (y2 - y1)
        area1 = rect1.width() * rect1.height()
        area2 = rect2.width() * rect2.height()
        
        return intersection / (area1 + area2 - intersection)

    @torch.no_grad()
    def predict(self, frame):
        self.eval()
        # Ensure 4D tensor (B, C, H, W)
        if frame.dim() == 3:
            frame = frame.unsqueeze(0)
        return self.forward(frame)