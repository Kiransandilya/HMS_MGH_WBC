# agents/mab_controller.py
import numpy as np
from scipy.stats import beta
import logging

class MABController:
    def __init__(self, n_agents, exploration_rate=0.1):
        """
        Initialize MAB Controller
        
        Args:
            n_agents (int): Number of agents
            exploration_rate (float): Epsilon for exploration (0-1)
        """
        self.n_agents = n_agents
        self.exploration_rate = exploration_rate
        
        # Initialize counts and values for each agent
        self.alpha = np.ones(n_agents)  # Successes
        self.beta = np.ones(n_agents)   # Failures
        
        # Track performance metrics
        self.total_rewards = np.zeros(n_agents)
        self.selection_counts = np.zeros(n_agents)
        self.cumulative_rewards = []
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger('MABController')
        
    def select_agent(self, force_explore=False):
        """
        Select an agent using Thompson sampling with epsilon-greedy strategy
        
        Args:
            force_explore (bool): Force exploration if True
            
        Returns:
            int: Selected agent ID
        """
        try:
            # Epsilon-greedy exploration
            if force_explore or np.random.random() < self.exploration_rate:
                selected_agent = np.random.randint(self.n_agents)
                self.logger.info(f"Exploring: Selected agent {selected_agent}")
                return selected_agent
            
            # Thompson sampling
            samples = [beta.rvs(a, b) for a, b in zip(self.alpha, self.beta)]
            selected_agent = np.argmax(samples)
            
            # Update selection count
            self.selection_counts[selected_agent] += 1
            
            self.logger.info(f"Selected agent {selected_agent} (confidence: {self.get_confidence(selected_agent):.3f})")
            return selected_agent
            
        except Exception as e:
            self.logger.error(f"Error in agent selection: {e}")
            return 0  # Return default agent on error
            
    def update(self, agent_id, reward, certainty=1.0):
        """
        Update agent statistics based on reward
        
        Args:
            agent_id (int): Agent ID
            reward (float): Reward value (-1 to 1)
            certainty (float): Confidence in the reward (0-1)
        """
        try:
            if not 0 <= agent_id < self.n_agents:
                raise ValueError(f"Invalid agent_id: {agent_id}")
                
            # Scale reward by certainty
            effective_reward = reward * certainty
            
            # Update success/failure counts
            if effective_reward > 0:
                self.alpha[agent_id] += abs(effective_reward)
            else:
                self.beta[agent_id] += abs(effective_reward)
                
            # Update performance metrics
            self.total_rewards[agent_id] += effective_reward
            self.cumulative_rewards.append(effective_reward)
            
            # Log update
            self.logger.info(f"Updated agent {agent_id}: reward={effective_reward:.3f}, "
                           f"new confidence={self.get_confidence(agent_id):.3f}")
                           
        except Exception as e:
            self.logger.error(f"Error updating agent stats: {e}")
            
    def get_confidence(self, agent_id):
        """
        Get current confidence for an agent
        
        Args:
            agent_id (int): Agent ID
            
        Returns:
            float: Confidence score (0-1)
        """
        try:
            total = self.alpha[agent_id] + self.beta[agent_id]
            if total == 0:
                return 0.0
            return self.alpha[agent_id] / total
        except Exception as e:
            self.logger.error(f"Error calculating confidence: {e}")
            return 0.0
            
    def get_performance_stats(self):
        """
        Get performance statistics for all agents
        
        Returns:
            dict: Performance statistics
        """
        return {
            'confidences': [self.get_confidence(i) for i in range(self.n_agents)],
            'total_rewards': self.total_rewards.tolist(),
            'selection_counts': self.selection_counts.tolist(),
            'average_rewards': [
                (self.total_rewards[i] / max(1, self.selection_counts[i]))
                for i in range(self.n_agents)
            ]
        }
        
    def reset(self):
        """Reset the controller to initial state"""
        self.__init__(self.n_agents, self.exploration_rate)
        self.logger.info("MAB Controller reset to initial state")

    def save_state(self, path):
        """Save controller state to file"""
        state = {
            'alpha': self.alpha,
            'beta': self.beta,
            'total_rewards': self.total_rewards,
            'selection_counts': self.selection_counts,
            'cumulative_rewards': self.cumulative_rewards
        }
        np.save(path, state)
        
    def load_state(self, path):
        """Load controller state from file"""
        try:
            state = np.load(path, allow_pickle=True).item()
            self.alpha = state['alpha']
            self.beta = state['beta']
            self.total_rewards = state['total_rewards']
            self.selection_counts = state['selection_counts']
            self.cumulative_rewards = state['cumulative_rewards']
            self.logger.info("Successfully loaded MAB state")
        except Exception as e:
            self.logger.error(f"Error loading state: {e}")