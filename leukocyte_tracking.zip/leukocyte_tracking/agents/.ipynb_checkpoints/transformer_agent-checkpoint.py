# agents/transformer_agent.py
import torch
import torch.nn as nn
from .base_agent import BaseDetectionAgent  # Add this import



class TransformerDetectionAgent(BaseDetectionAgent):
    def __init__(self, dim=256, num_heads=8, num_layers=6):
        self.dim = dim 
        super().__init__()
        
        self.build_model()
        
    def build_model(self):
        # Feature extraction
        self.feature_extractor = nn.Sequential(
            nn.Conv2d(1, 32, 7, stride=2, padding=3),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(64, self.dim, 3, padding=1),
            nn.AdaptiveAvgPool2d((8, 8))
        )
        
        # Position embedding
        self.pos_embedding = nn.Parameter(torch.randn(1, 64, self.dim))
        
        # Transformer encoder
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=self.dim,
            nhead=8,
            dim_feedforward=self.dim * 4,
            dropout=0.1,
            batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=6)
        
        # ROI prediction head
        self.roi_head = nn.Sequential(
            nn.Linear(self.dim, 128),
            nn.ReLU(),
            nn.Linear(128, 4)
        )
        
    def forward(self, x):
        # Extract features
        features = self.feature_extractor(x)
        
        # Reshape for transformer (B, C, H, W) -> (B, H*W, C)
        B, C, H, W = features.shape
        features = features.flatten(2).transpose(1, 2)
        
        # Add position embeddings
        features = features + self.pos_embedding[:, :features.size(1), :]
        
        # Transformer processing
        transformed = self.transformer(features)
        
        # Global average pooling
        pooled = transformed.mean(dim=1)
        
        # Predict ROI
        roi = self.roi_head(pooled)
        
        return torch.sigmoid(roi)  # Normalize to [0,1]