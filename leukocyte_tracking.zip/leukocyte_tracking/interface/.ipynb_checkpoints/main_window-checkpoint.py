# interface/main_window.py

import sys
import torch
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                         QHBoxLayout, QPushButton, QLabel, QFileDialog)
from PyQt6.QtCore import Qt, QRect, QSize
from PyQt6.QtGui import QImage, QPixmap, QKeySequence, QShortcut
import numpy as np

from interface.components.roi_selector import ROISelector
from interface.visualization.overlay import ROIOverlay
from interface.components.frame_navigator import FrameNavigator
from interface.components.roi_manager import ROIManager
from interface.visualization.loss_display import LossDisplay

from interface.components.progress import ProgressIndicator

from interface.visualization.confidence_display import ConfidenceDisplay


from utils.tiff_handler import TiffHandler
from preprocessing.pipeline import PreprocessingPipeline
from agents.mab_controller import MABController
from agents.cnn_agent import CNNDetectionAgent
from agents.transformer_agent import TransformerDetectionAgent
from agents.lstm_agent import LSTMDetectionAgent

from interface.components.preprocessing_controls import PreprocessingControls


class LeukocyteTracker(QMainWindow):
   def __init__(self):
       super().__init__()
       self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
       self.setup_agents()
       self.tiff_handler = None
       self.preprocessing = PreprocessingPipeline()
       self.mab_controller = MABController(
        n_agents=3,
        exploration_rate=0.1 ) # 10% exploration)
       self.current_frame = 0
       self.is_roi_mode = False
       
       self.setWindowTitle("Leukocyte Tracking System")
       self.setGeometry(100, 100, 1200, 800)
       
       self.setup_ui()
       self.setup_menubar()
       self.setup_shortcuts()
       self.progress = ProgressIndicator(self)


   def setup_ui(self):
        # 1) Create the central widget and main layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout(central_widget)
    
        # ------------------------------------------------------------------------
        # LEFT COLUMN: Raw Image
        # ------------------------------------------------------------------------
        left_layout = QVBoxLayout()
    
        raw_label = QLabel("Raw Image")
        raw_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
    
        self.raw_display = QLabel()
        self.raw_display.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.raw_display.setStyleSheet("background-color: black;")
    
        # ROI Selection Button
        roi_controls = QHBoxLayout()
        self.roi_button = QPushButton("Select ROI")
        self.roi_button.setCheckable(True)
        self.roi_button.clicked.connect(self.toggle_roi_selection)
        roi_controls.addWidget(self.roi_button)
    
        left_layout.addWidget(raw_label)
        left_layout.addWidget(self.raw_display, stretch=4)
        left_layout.addLayout(roi_controls)
    
        # ------------------------------------------------------------------------
        # CENTER COLUMN: Processed Image + Frame Navigator
        # ------------------------------------------------------------------------
        center_layout = QVBoxLayout()
    
        processed_label = QLabel("Processed Image")
        processed_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
    
        self.processed_display = QLabel()
        self.processed_display.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.processed_display.setStyleSheet("background-color: black;")
    
        self.frame_navigator = FrameNavigator()
    
        center_layout.addWidget(processed_label)
        center_layout.addWidget(self.processed_display, stretch=4)
        center_layout.addWidget(self.frame_navigator)
    
        # ------------------------------------------------------------------------
        # RIGHT COLUMN: ROI Manager + Preprocessing Controls
        # ------------------------------------------------------------------------
        right_layout = QVBoxLayout()
        self.roi_manager = ROIManager()
        right_layout.addWidget(self.roi_manager, stretch=4)
    
        self.preprocess_controls = PreprocessingControls(self.preprocessing)
        self.preprocess_controls.parameters_changed.connect(lambda: self.update_frame_display(self.current_frame))
        right_layout.addWidget(self.preprocess_controls, stretch=1)
       
        self.loss_display = LossDisplay()
        right_layout.addWidget(self.loss_display)

        self.confidence_display = ConfidenceDisplay()
        right_layout.addWidget(self.confidence_display)
    
        # ------------------------------------------------------------------------
        # Assemble All Columns
        # ------------------------------------------------------------------------
        # Adjust stretches as you prefer. 
        # For example, left=3, center=3, right=2.
        main_layout.addLayout(left_layout, stretch=3)
        main_layout.addLayout(center_layout, stretch=3)
        main_layout.addLayout(right_layout, stretch=2)
    
        # ------------------------------------------------------------------------
        # ROI Overlay
        # ------------------------------------------------------------------------
        self.roi_selector = ROISelector(self.raw_display)
        self.roi_overlay = ROIOverlay(self.raw_display)
        self.roi_overlay.resize(self.raw_display.size())

        # # Add prediction overlay
        # self.prediction_overlay = QWidget(self.processed_display)
        # self.prediction_overlay.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        # self.prediction_overlay.resize(self.processed_display.size())
    
        # Connect frame slider to display update
        self.frame_navigator.slider.valueChanged.connect(self.update_frame_display)
    
     
        
   def setup_agents(self):
       self.agents = {
           0: CNNDetectionAgent(),
           1: TransformerDetectionAgent(),
           2: LSTMDetectionAgent()
       }
       for agent in self.agents.values():
           agent.to(self.device)

   def setup_shortcuts(self):
       validate_shortcut = QShortcut(QKeySequence("Ctrl+V"), self)
       validate_shortcut.activated.connect(self.validate_selected_roi)
       delete_shortcut = QShortcut(QKeySequence("Del"), self)
       delete_shortcut.activated.connect(self.delete_selected_roi)

   def setup_menubar(self):
       menubar = self.menuBar()
       file_menu = menubar.addMenu("File")
       open_action = file_menu.addAction("Open TIFF")
       open_action.triggered.connect(self.load_tiff_file)

   def load_tiff_file(self):
       self.progress.show_loading("Loading TIFF file...")
       try:
           file_path, _ = QFileDialog.getOpenFileName(self, "Open TIFF", "", "TIFF files (*.tif *.tiff)")
           if file_path:
               self.tiff_handler = TiffHandler(file_path)
               self.frame_navigator.slider.setMaximum(self.tiff_handler.total_frames - 1)
               self.update_frame_display(0)
       except Exception as e:
           print(f"Error loading file: {e}")
       finally:
           self.progress.hide()




   def update_models_with_roi(self, frame, roi_rect):
        try:
            print(f"Updating models with ROI: {roi_rect}")
            
            # Convert frame and ROI to correct format
            if not isinstance(frame, torch.Tensor):
                frame = torch.tensor(frame, device=self.device)
            
            # Ensure frame is in correct shape (B, C, H, W)
            if frame.dim() == 2:
                frame = frame.unsqueeze(0).unsqueeze(0)
            elif frame.dim() == 3:
                frame = frame.unsqueeze(0)
                
            # Preprocess frame
            processed_frame, operation = self.preprocessing.process(frame)
            
            # Convert ROI to target format
            target = torch.tensor([
                roi_rect.x(), roi_rect.y(),
                roi_rect.width(), roi_rect.height()
            ], device=self.device).float().unsqueeze(0)
            
            # Normalize target coordinates if needed
            frame_height, frame_width = processed_frame.shape[-2:]
            normalized_target = torch.tensor([
                roi_rect.x() / frame_width,
                roi_rect.y() / frame_height,
                roi_rect.width() / frame_width,
                roi_rect.height() / frame_height
            ], device=self.device).float().unsqueeze(0)
            
            # Update each agent and collect losses
            losses = {}
            for agent_id, agent in self.agents.items():
                print(f"Training agent {agent_id}")
                try:
                    # Update weights and get loss
                    loss = agent.update_weights(processed_frame, normalized_target)
                    losses[agent_id] = loss
                    
                    # Update loss display
                    self.loss_display.update_loss(agent_id, loss)
                    print(f"Agent {agent_id} loss: {loss}")
                    
                except Exception as e:
                    print(f"Error updating agent {agent_id}: {e}")
                    continue
            
            # Update MAB controller with best performing agent
            if losses:
                best_agent = min(losses.items(), key=lambda x: x[1])[0]
                self.mab_controller.update(best_agent, 1.0)
                
                # Update confidence display
                for agent_id in self.agents:
                    confidence = self.mab_controller.get_confidence(agent_id)
                    self.confidence_display.update_confidence(agent_id, confidence)
            
            # Save the preprocessing operation that was used
            self.preprocessing.current_operation = operation
            
            return True
            
        except Exception as e:
            print(f"Error in model update: {e}")
            return False

   def update_frame_display(self, frame_index):
        if not self.tiff_handler:
            return
            
        self.current_frame = frame_index  # Update current frame
        frame = self.tiff_handler.get_frame(frame_index)
        if frame is None:
            return
            
        try:
            # Update raw display
            self._update_display(frame, self.raw_display)
            
            # Update processed display
            processed_frame, operation = self.preprocessing.process(frame)
            agent_id = self.mab_controller.select_agent()
            predictions = self.agents[agent_id].predict(processed_frame)
            print(f"Raw predictions shape and values: {predictions.shape}, {predictions}")
            
            self._update_display(processed_frame, self.processed_display)
            
            # Update ROI overlays for new frame
            self.roi_overlay.update_frame(frame_index)  # Update current frame in overlay
            self.roi_manager.set_current_frame(frame_index)  # Update ROI manager
            
            # Handle predictions
            if predictions is not None:
                roi_rect = self._predictions_to_rect(predictions)
                if roi_rect:
                    roi_data = {
                        'frame': frame_index,
                        'rect': roi_rect,
                        'predicted': True,
                        'confidence': self.mab_controller.get_confidence(agent_id),
                        'agent_id': agent_id,
                        'operation': operation
                    }
                    self.roi_overlay.add_roi(roi_data)
                
        except Exception as e:
            print(f"Error processing frame: {e}")

           

   def _update_display(self, frame, display_widget):
       frame_np = frame.cpu().numpy().squeeze()
       if frame_np.ndim == 3 and frame_np.shape[0] == 1:
           frame_np = frame_np[0]
   
       frame_np = (frame_np * 255.0).clip(0, 255).astype(np.uint8)
   
       if frame_np.ndim == 2:
           frame_np = np.stack([frame_np, frame_np, frame_np], axis=-1)
   
       height, width, channels = frame_np.shape
       bytes_per_line = channels * width
       q_img = QImage(frame_np.data, width, height, bytes_per_line, 
                     QImage.Format.Format_RGB888)
   
       pixmap = QPixmap.fromImage(q_img)
       display_widget.setPixmap(pixmap.scaled(display_widget.size(),
                              Qt.AspectRatioMode.KeepAspectRatio))

   def _update_predictions(self, predictions, agent_id, operation):
       if self.roi_overlay:
           self.roi_overlay.update_rois(predictions, agent_id, operation)

   def _predictions_to_rect(self, predictions):
       try:
           x, y, w, h = predictions.cpu().numpy()
           if any(np.isnan([x, y, w, h])) or w <= 0 or h <= 0:
               raise ValueError("Invalid prediction values")
           
           x = max(0, min(x, self.raw_display.width()))
           y = max(0, min(y, self.raw_display.height()))
           w = min(w, self.raw_display.width() - x)
           h = min(h, self.raw_display.height() - y)
           
           return QRect(int(x), int(y), int(w), int(h))
           
       except (ValueError, RuntimeError) as e:
           print(f"Prediction error: {e}")
           return None

   def toggle_roi_selection(self, checked):
        if checked:
            self.roi_selector.active = True
            self.raw_display.setCursor(Qt.CursorShape.CrossCursor)
            self.raw_display.mousePressEvent = self.roi_selector.mousePressEvent
            self.raw_display.mouseMoveEvent = self.roi_selector.mouseMoveEvent
            self.raw_display.mouseReleaseEvent = self.handle_roi_selection
        else:
            self.roi_selector.active = False
            self.raw_display.setCursor(Qt.CursorShape.ArrowCursor)
            self.raw_display.mousePressEvent = None
            self.raw_display.mouseMoveEvent = None
            self.raw_display.mouseReleaseEvent = None


                

   def handle_roi_selection(self, event):
        roi_rect = self.roi_selector.mouseReleaseEvent(event)
        if roi_rect:
            try:
                # Convert to image coordinates
                image_rect = self.roi_selector.get_image_coordinates(roi_rect)
                if not image_rect:
                    print("Failed to convert coordinates")
                    return
                    
                # Get current frame
                frame = self.tiff_handler.get_frame(self.current_frame)
                if frame is None:
                    print("No frame available")
                    return
                    
                # Create normalized coordinates for training
                frame_height, frame_width = frame.shape[-2:]
                normalized_coords = {
                    'x': image_rect.x() / frame_width,
                    'y': image_rect.y() / frame_height,
                    'width': image_rect.width() / frame_width,
                    'height': image_rect.height() / frame_height
                }
                
                # Create ROI data
                roi_data = {
                    'frame': self.current_frame,
                    'rect': image_rect,
                    'normalized_coords': normalized_coords,
                    'manual': True,
                    'validated': False,
                    'selected': False
                }
                
                # Update visualization
                self.roi_overlay.add_roi(roi_data)
                self.roi_manager.add_roi(roi_data)
                
                # Update models with normalized coordinates
                self.update_models_with_roi(frame, normalized_coords)
                
                print(f"ROI added - Image coords: {image_rect}")
                print(f"Normalized coords: {normalized_coords}")
                
            except Exception as e:
                print(f"Error handling ROI selection: {e}")

   def resizeEvent(self, event):
       if hasattr(self, 'prediction_overlay'):
           self.roi_overlay.resize(self.raw_display.size())
           self.prediction_overlay.resize(self.processed_display.size())

   def validate_selected_roi(self):
       if hasattr(self.roi_manager, 'selected_roi'):
           self.handle_roi_validation(self.roi_manager.selected_roi)

   def delete_selected_roi(self):
       if hasattr(self.roi_manager, 'selected_roi'):
           self.roi_overlay.remove_roi(self.roi_manager.selected_roi_index)
           self.roi_manager.delete_roi(self.roi_manager.selected_roi_index)

   def handle_roi_validation(self, roi_data):
       if roi_data.get('validated'):
           agent_id = roi_data['agent_id']
           certainty = self.agents[agent_id].get_prediction_confidence()
           self.mab_controller.update(agent_id, 1.0, certainty)
           # Get performance stats
           stats = self.mab_controller.get_performance_stats()
           print("Agent Performance:", stats)

   def update_models_with_roi(self, frame, normalized_coords):
        try:
            # Ensure frame is tensor and in correct shape
            if not isinstance(frame, torch.Tensor):
                frame = torch.tensor(frame, device=self.device)
            if frame.dim() == 2:
                frame = frame.unsqueeze(0).unsqueeze(0)
            elif frame.dim() == 3:
                frame = frame.unsqueeze(0)
                
            # Create target tensor from normalized coordinates
            target = torch.tensor([
                normalized_coords['x'],
                normalized_coords['y'],
                normalized_coords['width'],
                normalized_coords['height']
            ], device=self.device).float().unsqueeze(0)
            
            # Update each agent
            losses = {}
            for agent_id, agent in self.agents.items():
                try:
                    loss = agent.update_weights(frame, target)
                    losses[agent_id] = loss
                    self.loss_display.update_loss(agent_id, loss)
                    print(f"Agent {agent_id} loss: {loss}")
                except Exception as e:
                    print(f"Error updating agent {agent_id}: {e}")
                    
            # Update MAB controller
            if losses:
                best_agent = min(losses.items(), key=lambda x: x[1])[0]
                self.mab_controller.update(best_agent, 1.0)
                
        except Exception as e:
            print(f"Error in model update: {e}")

