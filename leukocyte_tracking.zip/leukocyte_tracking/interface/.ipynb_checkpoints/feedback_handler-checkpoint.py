# interface/feedback_handler.py

class FeedbackHandler:
   def __init__(self, mab_controller, preprocessing):
       self.mab_controller = mab_controller
       self.preprocessing = preprocessing

   def handle_roi_validation(self, roi_data, is_valid):
       agent_id = roi_data['agent_id']
       operation = roi_data['operation']
       
       reward = 1.0 if is_valid else -0.5
       self.mab_controller.update(agent_id, reward)
       self.preprocessing.mab.update(operation, reward)