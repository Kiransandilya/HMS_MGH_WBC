# interface/components/roi_manager.py
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QScrollArea, 
    QPushButton, QListWidget, QListWidgetItem
)
from PyQt6.QtCore import Qt, pyqtSignal

class ROIManager(QWidget):
    roi_deleted = pyqtSignal(int)
    roi_validated = pyqtSignal(int)
    roi_selected = pyqtSignal(dict)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.selected_roi = None
        self.selected_roi_index = None
        self.rois_by_frame = {}  # Store ROIs per frame
        self.current_frame = None  # Add this attribute to track current frame
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout()
        
        # ROI List with scroll
        scroll = QScrollArea()
        self.roi_list = QListWidget()
        self.roi_list.setMinimumHeight(200)
        self.roi_list.itemClicked.connect(self.on_roi_selected)
        scroll.setWidget(self.roi_list)
        scroll.setWidgetResizable(True)
        scroll.setMinimumHeight(200)
        layout.addWidget(scroll, stretch=8)
        
        # Control buttons
        button_layout = QHBoxLayout()
        validate_btn = QPushButton("Validate")
        delete_btn = QPushButton("Delete")
        validate_btn.clicked.connect(self.validate_selected)
        delete_btn.clicked.connect(self.delete_selected)
        button_layout.addWidget(validate_btn)
        button_layout.addWidget(delete_btn)
        layout.addLayout(button_layout)
        
        self.setLayout(layout)

    def set_current_frame(self, frame):
        """
        Update the current frame and refresh the ROI list
        
        :param frame: Current frame number
        """
        self.current_frame = frame
        self.update_roi_list(frame)

    def add_roi(self, roi_data):
        """
        Add a new ROI for the current frame
        
        :param roi_data: Dictionary containing ROI information
        """
        frame = roi_data.get('frame')
        if frame is None:
            print("Warning: ROI data missing frame information")
            return

        if frame not in self.rois_by_frame:
            self.rois_by_frame[frame] = []
        self.rois_by_frame[frame].append(roi_data)
        
        # Update list if this ROI is for the current frame
        if frame == self.current_frame:
            self.update_roi_list(frame)

    def update_roi_list(self, current_frame):
        """
        Update the ROI list for the given frame
        
        :param current_frame: Frame number to display ROIs for
        """
        self.roi_list.clear()
        if current_frame in self.rois_by_frame:
            for idx, roi in enumerate(self.rois_by_frame[current_frame]):
                item = QListWidgetItem(f"ROI {idx+1} (Frame {current_frame})")
                if roi.get('validated', False):
                    item.setText(f"✓ {item.text()}")
                self.roi_list.addItem(item)

    def delete_selected(self):
        """
        Delete the currently selected ROI
        """
        if self.selected_roi_index is not None and self.current_frame is not None:
            print(f"Deleting ROI {self.selected_roi_index}")
            
            if self.current_frame in self.rois_by_frame:
                # Remove from storage
                deleted_roi = self.rois_by_frame[self.current_frame].pop(self.selected_roi_index)
                
                # Emit signal for any additional cleanup
                self.roi_deleted.emit(self.selected_roi_index)
                
                # Update list
                self.update_roi_list(self.current_frame)
                
                # Reset selection
                self.selected_roi_index = None
                self.selected_roi = None

    def validate_selected(self):
        """
        Validate the currently selected ROI
        """
        if self.selected_roi_index is not None and self.current_frame is not None:
            print(f"Validating ROI {self.selected_roi_index}")
            
            if self.current_frame in self.rois_by_frame:
                roi = self.rois_by_frame[self.current_frame][self.selected_roi_index]
                roi['validated'] = True
                
                # Trigger model prediction (you'll need to implement this method)
                # self.parent().make_predictions(roi)
                
                self.update_roi_list(self.current_frame)

    def on_roi_selected(self, item):
        """
        Handle ROI selection from the list
        
        :param item: Selected QListWidgetItem
        """
        if self.current_frame is not None:
            self.selected_roi_index = self.roi_list.row(item)
            
            if self.current_frame in self.rois_by_frame:
                self.selected_roi = self.rois_by_frame[self.current_frame][self.selected_roi_index]
                self.roi_selected.emit(self.selected_roi)

    def select_next_roi(self):
        """
        Select the next ROI in the current frame
        """
        if self.current_frame not in self.rois_by_frame or not self.rois_by_frame[self.current_frame]:
            return
        
        current_idx = self.selected_roi_index or -1
        next_idx = (current_idx + 1) % len(self.rois_by_frame[self.current_frame])
        
        self.roi_list.setCurrentRow(next_idx)
        self.selected_roi_index = next_idx
        self.selected_roi = self.rois_by_frame[self.current_frame][next_idx]
        self.roi_selected.emit(self.selected_roi)

    def select_prev_roi(self):
        """
        Select the previous ROI in the current frame
        """
        if self.current_frame not in self.rois_by_frame or not self.rois_by_frame[self.current_frame]:
            return
        
        current_idx = self.selected_roi_index or 0
        prev_idx = (current_idx - 1) % len(self.rois_by_frame[self.current_frame])
        
        self.roi_list.setCurrentRow(prev_idx)
        self.selected_roi_index = prev_idx
        self.selected_roi = self.rois_by_frame[self.current_frame][prev_idx]
        self.roi_selected.emit(self.selected_roi)