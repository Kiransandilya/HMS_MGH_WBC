# interface/components/progress.py

from PyQt6.QtWidgets import QProgressBar, QLabel
from PyQt6.QtCore import Qt

class ProgressIndicator:
   def __init__(self, parent):
       self.progress_bar = QProgressBar(parent)
       self.status_label = QLabel(parent)
       self.setup_ui()

   def setup_ui(self):
       self.progress_bar.setAlignment(Qt.AlignmentFlag.AlignCenter)
       self.progress_bar.hide()
       self.status_label.hide()

   def show_loading(self, message="Loading..."):
       self.status_label.setText(message)
       self.progress_bar.setRange(0, 0)  # Infinite progress
       self.progress_bar.show()
       self.status_label.show()

   def hide(self):
       self.progress_bar.hide()
       self.status_label.hide()