# interface/components/frame_navigator.py

from PyQt6.QtWidgets import (QWidget, QHBoxLayout, QSlider, QPushButton, QLabel, QSpinBox)
from PyQt6.QtCore import Qt, QTimer

class FrameNavigator(QWidget):
   def __init__(self):
       super().__init__()
       self.timer = QTimer()
       self.fps = 30
       self.setup_ui()
       self.setup_connections()

   def setup_ui(self):
       layout = QHBoxLayout()
       
       self.frame_counter = QLabel("Frame: 0/0")
       
       self.prev_btn = QPushButton("←")
       self.play_btn = QPushButton("Play")
       self.next_btn = QPushButton("→")
       
       self.slider = QSlider(Qt.Orientation.Horizontal)
       
       self.fps_spin = QSpinBox()
       self.fps_spin.setRange(1, 120)
       self.fps_spin.setValue(30)
       
       layout.addWidget(self.frame_counter)
       layout.addWidget(self.prev_btn)
       layout.addWidget(self.play_btn)
       layout.addWidget(self.next_btn)
       layout.addWidget(self.slider, stretch=1)
       layout.addWidget(QLabel("FPS:"))
       layout.addWidget(self.fps_spin)
       
       self.setLayout(layout)

   def setup_connections(self):
       self.timer.timeout.connect(self.next_frame)
       self.play_btn.clicked.connect(self.toggle_play)
       self.prev_btn.clicked.connect(self.prev_frame)
       self.next_btn.clicked.connect(self.next_frame)
       self.fps_spin.valueChanged.connect(self.update_fps)
       self.slider.valueChanged.connect(self.update_counter)

   def update_counter(self, value):
       self.frame_counter.setText(f"Frame: {value}/{self.slider.maximum()}")

   def toggle_play(self):
       if self.timer.isActive():
           self.timer.stop()
           self.play_btn.setText("Play")
       else:
           self.timer.start(1000 // self.fps)
           self.play_btn.setText("Pause")

   def next_frame(self):
       self.slider.setValue(self.slider.value() + 1)
       if self.slider.value() >= self.slider.maximum():
           self.timer.stop()
           self.play_btn.setText("Play")

   def prev_frame(self):
       self.slider.setValue(self.slider.value() - 1)

   def update_fps(self, value):
       self.fps = value
       if self.timer.isActive():
           self.timer.setInterval(1000 // self.fps)