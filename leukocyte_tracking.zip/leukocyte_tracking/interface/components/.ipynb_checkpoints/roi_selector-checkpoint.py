# interface/components/roi_selector.py
from PyQt6.QtWidgets import QRubberBand, QWidget, QLabel
from PyQt6.QtCore import QRect, QPoint, QSize, Qt
from PyQt6.QtGui import QPainter, QPen, QColor

class ROISelector:
    def __init__(self, parent):
        self.active = False
        self.parent = parent
        self.rubber_band = QRubberBand(QRubberBand.Shape.Rectangle, parent)
        self.start_pos = None
        self.current_rect = None
        self.current_handle = None  # Add this
        
        # Add coordinate display
        self.coord_label = QLabel(parent)
        self.coord_label.setStyleSheet("background-color: rgba(0, 0, 0, 0.7); color: white; padding: 5px;")
        self.coord_label.hide()
        
        # Initialize handles
        self.handles = []  # This was missing
        self.handle_size = 8
        self.setup_handles()

    def setup_handles(self):
        for _ in range(8):  # 4 corners + 4 sides
            handle = QWidget(self.parent)
            handle.setFixedSize(self.handle_size, self.handle_size)
            handle.setStyleSheet("background-color: white; border: 1px solid black;")
            handle.hide()
            self.handles.append(handle)

    def mousePressEvent(self, event):
        if not self.active:
            return
            
        if event.button() == Qt.MouseButton.LeftButton:
            # Check if clicking on a handle
            handle_idx = self.get_handle_at_pos(event.pos())
            if handle_idx is not None:
                self.current_handle = handle_idx
                return
                
            self.start_pos = event.pos()
            self.rubber_band.setGeometry(QRect(self.start_pos, QSize()))
            self.rubber_band.show()
            self.update_coord_display(event.pos())

    def mouseMoveEvent(self, event):
        if not self.active or not self.start_pos:
            return
            
        if self.current_handle is not None:
            # Adjust handle position
            self.adjust_roi_by_handle(event.pos())
        else:
            # Normal ROI drawing
            self.current_rect = QRect(self.start_pos, event.pos()).normalized()
            self.rubber_band.setGeometry(self.current_rect)
            self.update_coord_display(event.pos())

    def mouseReleaseEvent(self, event):
        if not self.active or event.button() != Qt.MouseButton.LeftButton:
            return None
            
        if self.current_handle is not None:
            self.current_handle = None
            return self.current_rect
            
        end_pos = event.pos()
        self.current_rect = QRect(self.start_pos, end_pos).normalized()
        self.rubber_band.hide()
        self.coord_label.hide()
        
        # Hide handles when releasing
        for handle in self.handles:
            handle.hide()
            
        return self.current_rect

    def get_handle_at_pos(self, pos):
        """Check if position is over a handle"""
        for idx, handle in enumerate(self.handles):
            if handle.isVisible() and handle.geometry().contains(pos):
                return idx
        return None

    def adjust_roi_by_handle(self, pos):
        """Adjust ROI based on handle movement"""
        if self.current_rect and self.current_handle is not None:
            rect = QRect(self.current_rect)  # Create a copy
            handle_idx = self.current_handle
            
            # Update rectangle based on handle position
            if handle_idx < 4:  # Corner handles
                if handle_idx == 0:  # Top-left
                    rect.setTopLeft(pos)
                elif handle_idx == 1:  # Top-right
                    rect.setTopRight(pos)
                elif handle_idx == 2:  # Bottom-right
                    rect.setBottomRight(pos)
                elif handle_idx == 3:  # Bottom-left
                    rect.setBottomLeft(pos)
            else:  # Side handles
                if handle_idx == 4:  # Top
                    rect.setTop(pos.y())
                elif handle_idx == 5:  # Right
                    rect.setRight(pos.x())
                elif handle_idx == 6:  # Bottom
                    rect.setBottom(pos.y())
                elif handle_idx == 7:  # Left
                    rect.setLeft(pos.x())
                    
            self.current_rect = rect.normalized()
            self.rubber_band.setGeometry(self.current_rect)
            self.update_coord_display(pos)
            self.update_handle_positions()

    def update_handle_positions(self):
        """Update handle positions based on current ROI"""
        if not self.current_rect:
            return
            
        positions = [
            self.current_rect.topLeft(),      # 0
            self.current_rect.topRight(),     # 1
            self.current_rect.bottomRight(),  # 2
            self.current_rect.bottomLeft(),   # 3
            QPoint(self.current_rect.center().x(), self.current_rect.top()),     # 4
            QPoint(self.current_rect.right(), self.current_rect.center().y()),   # 5
            QPoint(self.current_rect.center().x(), self.current_rect.bottom()),  # 6
            QPoint(self.current_rect.left(), self.current_rect.center().y())     # 7
        ]
        
        for handle, pos in zip(self.handles, positions):
            handle.move(pos.x() - self.handle_size // 2, pos.y() - self.handle_size // 2)
            handle.show()

    def get_image_coordinates(self, widget_rect):
        """Convert widget coordinates to actual image coordinates"""
        if not widget_rect:
            return None
            
        label = self.parent
        pixmap = label.pixmap()
        if not pixmap:
            return None
            
        image_size = pixmap.size()
        widget_size = label.size()
        
        width_ratio = image_size.width() / widget_size.width()
        height_ratio = image_size.height() / widget_size.height()
        
        if width_ratio > height_ratio:
            scale = width_ratio
            padding_x = 0
            padding_y = (widget_size.height() - (image_size.height() / scale)) / 2
        else:
            scale = height_ratio
            padding_x = (widget_size.width() - (image_size.width() / scale)) / 2
            padding_y = 0
            
        image_x = (widget_rect.x() - padding_x) * scale
        image_y = (widget_rect.y() - padding_y) * scale
        image_w = widget_rect.width() * scale
        image_h = widget_rect.height() * scale
        
        image_x = max(0, min(image_x, image_size.width() - 1))
        image_y = max(0, min(image_y, image_size.height() - 1))
        image_w = min(image_w, image_size.width() - image_x)
        image_h = min(image_h, image_size.height() - image_y)
        
        print(f"Widget coords: {widget_rect.x()}, {widget_rect.y()}, {widget_rect.width()}, {widget_rect.height()}")
        print(f"Image coords: {image_x}, {image_y}, {image_w}, {image_h}")
        
        return QRect(int(image_x), int(image_y), int(image_w), int(image_h))

    def update_coord_display(self, pos):
        """Update coordinate display showing both widget and image coordinates"""
        if self.current_rect:
            image_rect = self.get_image_coordinates(self.current_rect)
            if image_rect:
                text = f"Widget: X:{self.current_rect.x()}, Y:{self.current_rect.y()}\n"
                text += f"Image: X:{image_rect.x()}, Y:{image_rect.y()}\n"
                text += f"Size: W:{image_rect.width()}, H:{image_rect.height()}"
                
                self.coord_label.setText(text)
                self.coord_label.adjustSize()
                self.coord_label.move(pos + QPoint(10, 10))
                self.coord_label.show()