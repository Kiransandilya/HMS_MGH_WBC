# interface/components/preprocessing_controls.py

from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                         QSlider, QPushButton)
from PyQt6.QtCore import Qt
from PyQt6.QtCore import pyqtSignal

class PreprocessingControls(QWidget):
    parameters_changed = pyqtSignal()
    def __init__(self, pipeline):
       super().__init__()
       self.pipeline = pipeline
       self.setup_ui()

    def update_param(self, param, value):
        try:
            if self.pipeline.set_parameter(param, value):
                self.parameters_changed.emit()
        except Exception as e:
            print(f"Error updating {param}: {e}")

    def setup_ui(self):
       layout = QVBoxLayout()
       layout.addWidget(QLabel("Preprocessing Controls"))

       # Contrast
       contrast_layout = QHBoxLayout()
       contrast_layout.addWidget(QLabel("Contrast:"))
       self.contrast_slider = QSlider(Qt.Orientation.Horizontal)
       self.contrast_slider.setRange(0, 200)
       self.contrast_slider.setValue(100)
       self.contrast_slider.valueChanged.connect(
           lambda v: self.update_param('contrast', v/100))
       contrast_layout.addWidget(self.contrast_slider)
       layout.addLayout(contrast_layout)

       # Brightness
       brightness_layout = QHBoxLayout()
       brightness_layout.addWidget(QLabel("Brightness:"))
       self.brightness_slider = QSlider(Qt.Orientation.Horizontal)
       self.brightness_slider.setRange(0, 200)
       self.brightness_slider.setValue(100)
       self.brightness_slider.valueChanged.connect(
           lambda v: self.update_param('brightness', v/100))
       brightness_layout.addWidget(self.brightness_slider)
       layout.addLayout(brightness_layout)

       # Gaussian Blur
       gaussian_layout = QHBoxLayout()
       gaussian_layout.addWidget(QLabel("Gaussian Blur:"))
       self.gaussian_slider = QSlider(Qt.Orientation.Horizontal)
       self.gaussian_slider.setRange(0, 50)
       self.gaussian_slider.setValue(10)
       self.gaussian_slider.valueChanged.connect(
           lambda v: self.update_param('gaussian_sigma', v/10))
       gaussian_layout.addWidget(self.gaussian_slider)
       layout.addLayout(gaussian_layout)

       # Reset button
       reset_btn = QPushButton("Reset")
       reset_btn.clicked.connect(self.reset_params)
       layout.addWidget(reset_btn)

       self.setLayout(layout)



    def reset_params(self):
       self.contrast_slider.setValue(100)
       self.brightness_slider.setValue(100)
       self.gaussian_slider.setValue(10)