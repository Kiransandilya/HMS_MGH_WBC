# interface/visualization/confidence_display.py

from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QLabel, 
                         QProgressBar)
from PyQt6.QtCore import Qt

class ConfidenceDisplay(QWidget):
   def __init__(self):
       super().__init__()
       self.setup_ui()

   def setup_ui(self):
       layout = QVBoxLayout()
       self.progress_bars = {}
       
       label_names = {
           0: "CNN Agent",
           1: "Transformer Agent", 
           2: "LSTM Agent"
       }
       
       for i in range(3):
           label = QLabel(label_names[i])
           progress = QProgressBar()
           progress.setRange(0, 100)
           self.progress_bars[i] = progress
           
           agent_layout = QVBoxLayout()
           agent_layout.addWidget(label)
           agent_layout.addWidget(progress)
           layout.addLayout(agent_layout)
       
       self.setLayout(layout)

   def update_confidence(self, agent_id, confidence):
       self.progress_bars[agent_id].setValue(int(confidence * 100))