# interface/visualization/loss_display.py

from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel
from PyQt6.QtCore import Qt
import pyqtgraph as pg

class LossDisplay(QWidget):
   def __init__(self):
       super().__init__()
       self.setup_ui()
       self.losses = {0: [], 1: [], 2: []}

   def setup_ui(self):
       layout = QVBoxLayout()
       self.plot = pg.PlotWidget()
       self.plot.setTitle("Training Loss")
       self.plot.setLabel('left', 'Loss')
       self.plot.setLabel('bottom', 'Updates')
       layout.addWidget(self.plot)
       self.setLayout(layout)

   def update_loss(self, agent_id, loss):
       self.losses[agent_id].append(loss)
       self.plot.clear()
       colors = ['r', 'g', 'b']
       names = ['CNN', 'Transformer', 'LSTM']
       for id, losses in self.losses.items():
           self.plot.plot(losses, pen=colors[id], name=f"Agent {id}")