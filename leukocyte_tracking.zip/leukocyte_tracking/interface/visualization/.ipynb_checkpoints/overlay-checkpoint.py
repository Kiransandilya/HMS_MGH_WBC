# interface/visualization/overlay.py
from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import Qt, QRect
from PyQt6.QtGui import QPainter, QPen, QColor, QBrush

class ROIOverlay(QWidget):
    def __init__(self, parent):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.rois = {}  # frame_idx -> list of ROIs
        self.selected_roi = None
        self.current_frame = 0  # Add current frame tracking
        self.setStyleSheet("background: transparent;")

    def update_frame(self, frame_idx):
        """Update the current frame number"""
        self.current_frame = frame_idx
        self.update()  # Request repaint

    def paintEvent(self, event):
        if not self.isVisible():
            return

        painter = QPainter(self)
        try:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            
            if self.current_frame in self.rois:
                for roi_data in self.rois[self.current_frame]:
                    rect = roi_data['rect']
                    is_prediction = roi_data.get('predicted', False)
                    is_validated = roi_data.get('validated', False)
                    
                    # Set color based on type
                    if is_prediction:
                        if is_validated:
                            color = QColor(0, 255, 0, 128)  # Green for validated predictions
                        else:
                            color = QColor(0, 0, 255, 128)  # Blue for predictions
                    else:
                        color = QColor(255, 0, 0, 128)  # Red for manual selections
                    
                    painter.setPen(QPen(color.darker(), 2))
                    painter.setBrush(QBrush(color))
                    painter.drawRect(rect)
                    
                    # Draw confidence if it's a prediction
                    if is_prediction and 'confidence' in roi_data:
                        conf_text = f"{roi_data['confidence']:.2f}"
                        painter.drawText(rect.topLeft() + QPoint(5, -5), conf_text)
        finally:
            painter.end()  # Ensure painter is ended

    def add_roi(self, roi_data):
        """Add a new ROI for the specified frame"""
        frame = roi_data['frame']
        if frame not in self.rois:
            self.rois[frame] = []
        self.rois[frame].append(roi_data)
        self.update()

    def clear_rois(self):
        """Clear all ROIs for the current frame"""
        if self.current_frame in self.rois:
            self.rois[self.current_frame] = []
        self.update()

    def remove_roi(self, roi_index):
        """Remove a specific ROI from the current frame"""
        if self.current_frame in self.rois and 0 <= roi_index < len(self.rois[self.current_frame]):
            self.rois[self.current_frame].pop(roi_index)
            self.update()