# utils/gpu_utils.py

import torch

def get_device():
    if torch.cuda.is_available():
        return torch.device(f'cuda:{torch.cuda.current_device()}')
    return torch.device('cpu')

def get_gpu_memory():
    if torch.cuda.is_available():
        return torch.cuda.get_device_properties(0).total_memory
    return None