# utils/tiff_handler.py

import numpy as np
from tifffile import TiffFile
import torch
from utils.gpu_utils import get_device

class TiffHandler:
   def __init__(self, file_path):
       self.file_path = file_path
       self.device = get_device()
       self._load_tiff()

   def _load_tiff(self):
       with TiffFile(self.file_path) as tif:
           self.frames = tif.asarray()
       self.total_frames = self.frames.shape[0]
       
   def get_frame(self, index):
        try:
            frame = self.frames[index].astype(np.float32) / 255.0
            frame = torch.from_numpy(frame).to(self.device)
            if len(frame.shape) > 2:
                frame = frame.squeeze()
            return frame.unsqueeze(0)  # Return (1, H, W)
        except Exception as e:
            print(f"Error loading frame {index}: {e}")
            return None

   def get_frame_batch(self, start_idx, batch_size=4):
       end_idx = min(start_idx + batch_size, self.total_frames)
       batch = torch.from_numpy(self.frames[start_idx:end_idx]).to(self.device)
       return batch