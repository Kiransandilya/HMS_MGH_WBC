# preprocessing/pipeline.py

import torch
import torch.nn.functional as F
from .mab_optimizer import MABOptimizer
import torchvision.transforms.functional as TF

class PreprocessingPipeline:
   def __init__(self):
       self.mab = MABOptimizer()
       self.params = {
           'contrast': 1.0,
           'brightness': 1.0,
           'gaussian_sigma': 1.0
       }
       self.current_operation = 'original'

   def process(self, frame):
       # Ensure 4D: [batch, channel, height, width]
       if frame.dim() == 2:
           frame = frame.unsqueeze(0).unsqueeze(0)
       elif frame.dim() == 3:
           frame = frame.unsqueeze(0)

       processed = frame.clone()
       
       # Apply all active operations sequentially
       if self.params['contrast'] != 1.0:
           processed = self.enhance_contrast(processed)
       if self.params['brightness'] != 1.0:
           processed = self.adjust_brightness(processed)
       if self.params['gaussian_sigma'] != 1.0:
           processed = self.gaussian_blur(processed)

       return processed, self.current_operation

   def set_parameter(self, param, value):
        if param in self.params:
            old_value = self.params[param]
            self.params[param] = value
            return old_value != value  # Return True if value changed

   def adjust_brightness(self, frame):
       return torch.clamp(frame * self.params['brightness'], 0, 1)

   def enhance_contrast(self, frame):
       mean = frame.mean()
       return torch.clamp((frame - mean) * self.params['contrast'] + mean, 0, 1)

   def gaussian_blur(self, frame):
        if self.params['gaussian_sigma'] < 0.1:
            return frame
        kernel_size = max(3, int(2 * self.params['gaussian_sigma']))
        if kernel_size % 2 == 0:
            kernel_size += 1
        return TF.gaussian_blur(frame, kernel_size, self.params['gaussian_sigma'])