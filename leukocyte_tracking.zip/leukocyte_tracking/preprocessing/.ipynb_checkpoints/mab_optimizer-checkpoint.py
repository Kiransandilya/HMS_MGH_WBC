# preprocessing/mab_optimizer.py

from scipy.stats import beta
import numpy as np

class MABOptimizer:
    def __init__(self):
        self.operations = ['denoise', 'contrast', 'normalize']
        self.alpha = np.ones(len(self.operations))
        self.beta = np.ones(len(self.operations))

    def select_operation(self):
        samples = [beta.rvs(a, b) for a, b in zip(self.alpha, self.beta)]
        return self.operations[np.argmax(samples)]

    def update(self, operation_idx, reward):
        if reward > 0:
            self.alpha[operation_idx] += 1
        else:
            self.beta[operation_idx] += 1