# run.py

import sys
from PyQt6.QtWidgets import QApplication
from interface.main_window import LeukocyteTracker

def main():
    app = QApplication(sys.argv)
    window = LeukocyteTracker()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()