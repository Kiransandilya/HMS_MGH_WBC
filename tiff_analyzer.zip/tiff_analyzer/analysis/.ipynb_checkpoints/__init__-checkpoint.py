# tiff_analyzer/analysis/__init__.py

from typing import Dict, Any, Optional, List
import threading
from pathlib import Path
from ..utils.logger import logger, log_function
from ..utils.settings import settings
from ..utils.events import event_manager, EventType, Event
from ..core.state_manager import state_manager

class AnalysisManager:
    """Manages image analysis operations and components"""
    
    def __init__(self):
        self._initialized = False
        self._lock = threading.Lock()
        self._current_analysis: Optional[Dict] = None
        self._analysis_cache: Dict[str, Any] = {}
        self._roi_manager = None  # Will be initialized later
        self._feature_extractor = None
        self._wbc_analyzer = None
        self._measurements = None
        
        # Analysis parameters
        self._params = {
            'wbc': {
                'min_size': 100,  # Minimum WBC size in pixels
                'max_size': 1000,  # Maximum WBC size in pixels
                'intensity_threshold': 0.2,  # Intensity threshold for segmentation
                'contrast_enhancement': True,  # Whether to enhance contrast
                'feature_extraction_level': 'basic'  # basic, advanced, or complete
            },
            'roi': {
                'default_type': 'rectangle',
                'auto_detection': True,
                'detection_sensitivity': 0.7
            },
            'measurements': {
                'calibration_factor': 1.0,  # pixels to microns
                'unit': 'pixels'
            }
        }
    
    @log_function
    def initialize(self) -> bool:
        """Initialize analysis components"""
        if self._initialized:
            return True
            
        try:
            with self._lock:
                # Initialize components
                self._init_roi_manager()
                self._init_feature_extractor()
                self._init_wbc_analyzer()
                self._init_measurements()
                
                # Register event handlers
                self._setup_event_handlers()
                
                self._initialized = True
                logger.logger.info("Analysis system initialized")
                return True
                
        except Exception as e:
            logger.log_error(e, {"context": "Analysis initialization"})
            return False
    
    def _init_roi_manager(self) -> None:
        """Initialize ROI management"""
        from .roi import ROIManager
        self._roi_manager = ROIManager()
    
    def _init_feature_extractor(self) -> None:
        """Initialize feature extraction"""
        from .feature_extractor import FeatureExtractor
        self._feature_extractor = FeatureExtractor()
    
    def _init_wbc_analyzer(self) -> None:
        """Initialize WBC analysis"""
        from .wbc_analyzer import WBCAnalyzer
        self._wbc_analyzer = WBCAnalyzer()
    
    def _init_measurements(self) -> None:
        """Initialize measurements"""
        from .measurements import MeasurementManager
        self._measurements = MeasurementManager()
    
    def _setup_event_handlers(self) -> None:
        """Setup event handling"""
        event_manager.subscribe(EventType.ROI_CREATED, self._handle_roi_event)
        event_manager.subscribe(EventType.ANALYSIS_REQUESTED, self._handle_analysis_request)
    
    @log_function
    def start_analysis(self, frame: Any, analysis_type: str, 
                      params: Optional[Dict] = None) -> bool:
        """Start analysis on a frame"""
        try:
            if not self._initialized:
                logger.logger.error("Analysis system not initialized")
                return False
                
            with self._lock:
                # Merge provided parameters with defaults
                analysis_params = self._params[analysis_type].copy()
                if params:
                    analysis_params.update(params)
                
                # Create analysis context
                self._current_analysis = {
                    'type': analysis_type,
                    'frame': frame,
                    'params': analysis_params,
                    'results': {},
                    'status': 'running'
                }
                
                # Emit analysis start event
                event_manager.emit(Event(
                    EventType.ANALYSIS_STARTED,
                    data={'type': analysis_type}
                ))
                
                # Perform analysis based on type
                if analysis_type == 'wbc':
                    return self._analyze_wbc(frame, analysis_params)
                elif analysis_type == 'features':
                    return self._extract_features(frame, analysis_params)
                else:
                    logger.logger.error(f"Unknown analysis type: {analysis_type}")
                    return False
                    
        except Exception as e:
            logger.log_error(e, {
                "context": "Starting analysis",
                "type": analysis_type
            })
            return False
    
    def _analyze_wbc(self, frame: Any, params: Dict) -> bool:
        """Perform WBC analysis"""
        try:
            results = self._wbc_analyzer.analyze(frame, params)
            self._current_analysis['results'] = results
            self._current_analysis['status'] = 'completed'
            
            event_manager.emit(Event(
                EventType.ANALYSIS_COMPLETED,
                data={'type': 'wbc', 'results': results}
            ))
            return True
            
        except Exception as e:
            logger.log_error(e, {"context": "WBC analysis"})
            self._current_analysis['status'] = 'failed'
            return False
    
    def _extract_features(self, frame: Any, params: Dict) -> bool:
        """Extract features from frame"""
        try:
            features = self._feature_extractor.extract(frame, params)
            self._current_analysis['results'] = features
            self._current_analysis['status'] = 'completed'
            
            event_manager.emit(Event(
                EventType.ANALYSIS_COMPLETED,
                data={'type': 'features', 'results': features}
            ))
            return True
            
        except Exception as e:
            logger.log_error(e, {"context": "Feature extraction"})
            self._current_analysis['status'] = 'failed'
            return False
    
    def _handle_roi_event(self, event: Event) -> None:
        """Handle ROI-related events"""
        if not self._current_analysis:
            return
            
        try:
            roi_data = event.data
            if 'bounds' in roi_data:
                self._current_analysis['roi'] = roi_data
                self.analyze_roi(roi_data['bounds'])
                
        except Exception as e:
            logger.log_error(e, {"context": "ROI event handling"})
    
    def _handle_analysis_request(self, event: Event) -> None:
        """Handle analysis requests"""
        try:
            request_data = event.data
            self.start_analysis(
                request_data['frame'],
                request_data['type'],
                request_data.get('params')
            )
        except Exception as e:
            logger.log_error(e, {"context": "Analysis request handling"})
    
    def get_current_analysis(self) -> Optional[Dict]:
        """Get current analysis state"""
        return self._current_analysis
    
    def get_analysis_params(self, analysis_type: str) -> Dict:
        """Get analysis parameters"""
        return self._params.get(analysis_type, {}).copy()
    
    def set_analysis_params(self, analysis_type: str, params: Dict) -> None:
        """Set analysis parameters"""
        if analysis_type in self._params:
            self._params[analysis_type].update(params)
    
    def cleanup(self) -> None:
        """Clean up analysis system"""
        if not self._initialized:
            return
            
        try:
            # Clean up components
            if self._roi_manager:
                self._roi_manager.cleanup()
            if self._feature_extractor:
                self._feature_extractor.cleanup()
            if self._wbc_analyzer:
                self._wbc_analyzer.cleanup()
            if self._measurements:
                self._measurements.cleanup()
                
            self._initialized = False
            
        except Exception as e:
            logger.log_error(e, {"context": "Analysis cleanup"})

# Create global analysis manager instance
analysis_manager = AnalysisManager()

# Export components
__all__ = [
    'analysis_manager',
    'ROIManager',
    'FeatureExtractor',
    'WBCAnalyzer',
    'MeasurementManager'
]