# tiff_analyzer/analysis/feature_extractor.py

import numpy as np
from typing import Dict, List, Any, Optional, Tuple
import cv2
from dataclasses import dataclass
from scipy import ndimage
from skimage import feature, measure
import threading
from ..utils.logger import logger, log_function

@dataclass
class FeatureSet:
    """Container for extracted features"""
    # Shape features
    area: float
    perimeter: float
    circularity: float
    aspect_ratio: float
    solidity: float
    
    # Intensity features
    mean_intensity: float
    std_intensity: float
    min_intensity: float
    max_intensity: float
    
    # Texture features
    entropy: float
    energy: float
    contrast: float
    homogeneity: float
    
    # Gradient features
    gradient_magnitude_mean: float
    gradient_orientation_std: float
    
    # Custom WBC features
    nucleus_cytoplasm_ratio: Optional[float] = None
    granularity: Optional[float] = None
    boundary_irregularity: Optional[float] = None

class FeatureExtractor:
    """Extracts image features for analysis"""
    
    def __init__(self):
        self._lock = threading.Lock()
        self._feature_cache: Dict[str, FeatureSet] = {}
        
    @log_function
    def extract(self, image: np.ndarray, roi: Optional[np.ndarray] = None, 
                params: Optional[Dict] = None) -> FeatureSet:
        """Extract features from image or ROI"""
        try:
            # Convert to grayscale if needed
            if len(image.shape) > 2:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            else:
                gray = image.copy()
            
            # Apply ROI mask if provided
            if roi is not None:
                mask = roi.astype(bool)
                gray[~mask] = 0
            
            # Extract features
            shape_features = self._extract_shape_features(gray)
            intensity_features = self._extract_intensity_features(gray)
            texture_features = self._extract_texture_features(gray)
            gradient_features = self._extract_gradient_features(gray)
            wbc_features = self._extract_wbc_features(gray, params)
            
            # Combine all features
            feature_set = FeatureSet(
                **shape_features,
                **intensity_features,
                **texture_features,
                **gradient_features,
                **wbc_features
            )
            
            return feature_set
            
        except Exception as e:
            logger.log_error(e, {"context": "Feature extraction"})
            raise
    
    def _extract_shape_features(self, image: np.ndarray) -> Dict[str, float]:
        """Extract shape-based features"""
        try:
            # Get contours
            thresh = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
            contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            if not contours:
                return {
                    'area': 0.0,
                    'perimeter': 0.0,
                    'circularity': 0.0,
                    'aspect_ratio': 0.0,
                    'solidity': 0.0
                }
            
            # Get largest contour
            contour = max(contours, key=cv2.contourArea)
            
            # Calculate features
            area = cv2.contourArea(contour)
            perimeter = cv2.arcLength(contour, True)
            
            # Circularity: 4*pi*area/perimeter^2
            circularity = 4 * np.pi * area / (perimeter * perimeter) if perimeter > 0 else 0
            
            # Aspect ratio from bounding rectangle
            x, y, w, h = cv2.boundingRect(contour)
            aspect_ratio = float(w) / h if h > 0 else 0
            
            # Solidity: ratio of contour area to convex hull area
            hull = cv2.convexHull(contour)
            hull_area = cv2.contourArea(hull)
            solidity = float(area) / hull_area if hull_area > 0 else 0
            
            return {
                'area': area,
                'perimeter': perimeter,
                'circularity': circularity,
                'aspect_ratio': aspect_ratio,
                'solidity': solidity
            }
            
        except Exception as e:
            logger.log_error(e, {"context": "Shape feature extraction"})
            raise
    
    def _extract_intensity_features(self, image: np.ndarray) -> Dict[str, float]:
        """Extract intensity-based features"""
        try:
            # Calculate basic statistics
            mask = image > 0
            if not np.any(mask):
                return {
                    'mean_intensity': 0.0,
                    'std_intensity': 0.0,
                    'min_intensity': 0.0,
                    'max_intensity': 0.0
                }
            
            roi_pixels = image[mask]
            
            return {
                'mean_intensity': float(np.mean(roi_pixels)),
                'std_intensity': float(np.std(roi_pixels)),
                'min_intensity': float(np.min(roi_pixels)),
                'max_intensity': float(np.max(roi_pixels))
            }
            
        except Exception as e:
            logger.log_error(e, {"context": "Intensity feature extraction"})
            raise
    
    def _extract_texture_features(self, image: np.ndarray) -> Dict[str, float]:
        """Extract texture-based features using GLCM"""
        try:
            # Normalize image
            img_normalized = cv2.normalize(
                image, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
            
            # Calculate GLCM
            distances = [1]
            angles = [0, np.pi/4, np.pi/2, 3*np.pi/4]
            glcm = feature.graycomatrix(
                img_normalized, distances, angles, 256, symmetric=True, normed=True)
            
            # Calculate features from GLCM
            contrast = np.mean(feature.graycoprops(glcm, 'contrast'))
            energy = np.mean(feature.graycoprops(glcm, 'energy'))
            homogeneity = np.mean(feature.graycoprops(glcm, 'homogeneity'))
            
            # Calculate entropy
            hist = cv2.calcHist([img_normalized], [0], None, [256], [0, 256])
            hist = hist / hist.sum()
            entropy = -np.sum(hist * np.log2(hist + 1e-7))
            
            return {
                'entropy': float(entropy),
                'energy': float(energy),
                'contrast': float(contrast),
                'homogeneity': float(homogeneity)
            }
            
        except Exception as e:
            logger.log_error(e, {"context": "Texture feature extraction"})
            raise
    
    def _extract_gradient_features(self, image: np.ndarray) -> Dict[str, float]:
        """Extract gradient-based features"""
        try:
            # Calculate gradients
            sobelx = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=3)
            sobely = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=3)
            
            # Calculate magnitude and orientation
            magnitude = np.sqrt(sobelx**2 + sobely**2)
            orientation = np.arctan2(sobely, sobelx)
            
            return {
                'gradient_magnitude_mean': float(np.mean(magnitude)),
                'gradient_orientation_std': float(np.std(orientation))
            }
            
        except Exception as e:
            logger.log_error(e, {"context": "Gradient feature extraction"})
            raise
    
    def _extract_wbc_features(self, image: np.ndarray, 
                            params: Optional[Dict] = None) -> Dict[str, Optional[float]]:
        """Extract WBC-specific features"""
        try:
            # Default parameters
            default_params = {
                'nucleus_threshold': 0.6,
                'granularity_kernel_size': 5,
                'boundary_smoothing': 3
            }
            
            # Update with provided parameters
            if params:
                default_params.update(params)
            
            # Nucleus-cytoplasm ratio
            nucleus_mask = image > (default_params['nucleus_threshold'] * np.max(image))
            nucleus_area = np.sum(nucleus_mask)
            total_area = np.sum(image > 0)
            nucleus_cytoplasm_ratio = (
                nucleus_area / (total_area - nucleus_area)
                if total_area > nucleus_area else 0
            )
            
            # Granularity
            kernel = np.ones(
                (default_params['granularity_kernel_size'],
                 default_params['granularity_kernel_size']),
                np.uint8
            )
            opened = cv2.morphologyEx(image, cv2.MORPH_OPEN, kernel)
            granularity = np.mean(np.abs(image - opened))
            
            # Boundary irregularity
            smooth_contour = cv2.GaussianBlur(
                image,
                (default_params['boundary_smoothing'],
                 default_params['boundary_smoothing']),
                0
            )
            boundary_irregularity = np.mean(np.abs(image - smooth_contour))
            
            return {
                'nucleus_cytoplasm_ratio': float(nucleus_cytoplasm_ratio),
                'granularity': float(granularity),
                'boundary_irregularity': float(boundary_irregularity)
            }
            
        except Exception as e:
            logger.log_error(e, {"context": "WBC feature extraction"})
            return {
                'nucleus_cytoplasm_ratio': None,
                'granularity': None,
                'boundary_irregularity': None
            }
    
    def cache_features(self, key: str, features: FeatureSet) -> None:
        """Cache extracted features"""
        with self._lock:
            self._feature_cache[key] = features
    
    def get_cached_features(self, key: str) -> Optional[FeatureSet]:
        """Get cached features"""
        return self._feature_cache.get(key)
    
    def clear_cache(self) -> None:
        """Clear feature cache"""
        with self._lock:
            self._feature_cache.clear()
    
    def cleanup(self) -> None:
        """Clean up resources"""
        self.clear_cache()

# Create global feature extractor instance
feature_extractor = FeatureExtractor()

# Example usage
if __name__ == "__main__":
    # Create test image
    test_image = np.zeros((100, 100), dtype=np.uint8)
    cv2.circle(test_image, (50, 50), 20, 255, -1)
    
    # Extract features
    features = feature_extractor.extract(test_image)
    print("Extracted features:", features)