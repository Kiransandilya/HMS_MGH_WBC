# tiff_analyzer/analysis/wbc_analyzer.py

import numpy as np
from typing import Dict, List, Any, Optional, Tuple
import cv2
from dataclasses import dataclass
import threading
from ..utils.logger import logger, log_function
from .feature_extractor import feature_extractor, FeatureSet
from ..utils.events import event_manager, EventType, Event

@dataclass
class WBCAnalysisResult:
    """Container for WBC analysis results"""
    cell_type: str  # neutrophil, lymphocyte, monocyte, eosinophil, basophil
    confidence: float
    features: FeatureSet
    location: Tuple[int, int]  # center coordinates
    bbox: Tuple[int, int, int, int]  # x, y, w, h
    contour: np.ndarray
    metadata: Dict[str, Any]

class WBCAnalyzer:
    """Analyzes and classifies White Blood Cells"""
    
    def __init__(self):
        self._lock = threading.Lock()
        self.cell_types = [
            'neutrophil', 'lymphocyte', 'monocyte', 
            'eosinophil', 'basophil'
        ]
        
        # Classification thresholds and parameters
        self._params = {
            'detection': {
                'min_size': 100,
                'max_size': 1000,
                'nucleus_threshold': 0.6,
                'cytoplasm_threshold': 0.3
            },
            'classification': {
                'neutrophil': {
                    'n_c_ratio': (0.5, 0.7),
                    'granularity': (50, 150),
                    'circularity': (0.7, 0.9)
                },
                'lymphocyte': {
                    'n_c_ratio': (0.7, 0.9),
                    'granularity': (20, 60),
                    'circularity': (0.8, 1.0)
                },
                'monocyte': {
                    'n_c_ratio': (0.4, 0.6),
                    'granularity': (30, 80),
                    'circularity': (0.6, 0.8)
                },
                'eosinophil': {
                    'n_c_ratio': (0.5, 0.7),
                    'granularity': (150, 255),
                    'circularity': (0.7, 0.9)
                },
                'basophil': {
                    'n_c_ratio': (0.6, 0.8),
                    'granularity': (100, 200),
                    'circularity': (0.7, 0.9)
                }
            }
        }
    
    @log_function
    def analyze(self, image: np.ndarray, 
                params: Optional[Dict] = None) -> List[WBCAnalysisResult]:
        """Analyze image for WBCs"""
        try:
            # Update parameters if provided
            analysis_params = self._params.copy()
            if params:
                analysis_params.update(params)
            
            # Detect WBCs
            cells = self._detect_cells(image, analysis_params['detection'])
            
            # Analyze each detected cell
            results = []
            for cell in cells:
                roi = self._extract_cell_roi(image, cell['contour'])
                features = feature_extractor.extract(roi)
                
                # Classify cell
                cell_type, confidence = self._classify_cell(
                    features, 
                    analysis_params['classification']
                )
                
                # Create result
                result = WBCAnalysisResult(
                    cell_type=cell_type,
                    confidence=confidence,
                    features=features,
                    location=cell['center'],
                    bbox=cell['bbox'],
                    contour=cell['contour'],
                    metadata=cell['metadata']
                )
                results.append(result)
                
                # Emit analysis event
                event_manager.emit(Event(
                    EventType.WBC_ANALYZED,
                    data={
                        'cell_type': cell_type,
                        'confidence': confidence,
                        'location': cell['center']
                    }
                ))
            
            return results
            
        except Exception as e:
            logger.log_error(e, {"context": "WBC analysis"})
            return []
    
    def _detect_cells(self, image: np.ndarray, 
                     params: Dict) -> List[Dict[str, Any]]:
        """Detect individual WBCs in image"""
        try:
            # Convert to grayscale if needed
            if len(image.shape) > 2:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            else:
                gray = image.copy()
            
            # Create nucleus and cytoplasm masks
            nucleus_thresh = cv2.threshold(
                gray,
                int(params['nucleus_threshold'] * np.max(gray)),
                255,
                cv2.THRESH_BINARY
            )[1]
            
            cytoplasm_thresh = cv2.threshold(
                gray,
                int(params['cytoplasm_threshold'] * np.max(gray)),
                255,
                cv2.THRESH_BINARY
            )[1]
            
            # Find contours
            contours, _ = cv2.findContours(
                cytoplasm_thresh,
                cv2.RETR_EXTERNAL,
                cv2.CHAIN_APPROX_SIMPLE
            )
            
            cells = []
            for contour in contours:
                area = cv2.contourArea(contour)
                
                # Filter by size
                if not (params['min_size'] <= area <= params['max_size']):
                    continue
                
                # Calculate bounding box and center
                x, y, w, h = cv2.boundingRect(contour)
                center = (int(x + w/2), int(y + h/2))
                
                # Calculate nucleus area within cell
                mask = np.zeros_like(nucleus_thresh)
                cv2.drawContours(mask, [contour], -1, 255, -1)
                nucleus_area = cv2.countNonZero(
                    cv2.bitwise_and(nucleus_thresh, nucleus_thresh, mask=mask)
                )
                
                cells.append({
                    'contour': contour,
                    'center': center,
                    'bbox': (x, y, w, h),
                    'metadata': {
                        'area': area,
                        'nucleus_area': nucleus_area,
                        'nucleus_ratio': nucleus_area / area if area > 0 else 0
                    }
                })
            
            return cells
            
        except Exception as e:
            logger.log_error(e, {"context": "Cell detection"})
            return []
    
    def _extract_cell_roi(self, image: np.ndarray, 
                         contour: np.ndarray) -> np.ndarray:
        """Extract ROI for individual cell"""
        x, y, w, h = cv2.boundingRect(contour)
        roi = image[y:y+h, x:x+w].copy()
        
        # Create mask
        mask = np.zeros((h, w), dtype=np.uint8)
        shifted_contour = contour - np.array([x, y])
        cv2.drawContours(mask, [shifted_contour], -1, 255, -1)
        
        # Apply mask
        if len(roi.shape) > 2:
            mask = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
        roi = cv2.bitwise_and(roi, mask)
        
        return roi
    
    def _classify_cell(self, features: FeatureSet, 
                      params: Dict) -> Tuple[str, float]:
        """Classify cell type based on features"""
        try:
            scores = {}
            
            for cell_type in self.cell_types:
                cell_params = params[cell_type]
                score = 0.0
                
                # Check nucleus-cytoplasm ratio
                if (cell_params['n_c_ratio'][0] <= 
                    features.nucleus_cytoplasm_ratio <= 
                    cell_params['n_c_ratio'][1]):
                    score += 0.4
                
                # Check granularity
                if (cell_params['granularity'][0] <= 
                    features.granularity <= 
                    cell_params['granularity'][1]):
                    score += 0.3
                
                # Check circularity
                if (cell_params['circularity'][0] <= 
                    features.circularity <= 
                    cell_params['circularity'][1]):
                    score += 0.3
                
                scores[cell_type] = score
            
            # Get best match
            best_type = max(scores.items(), key=lambda x: x[1])
            return best_type[0], best_type[1]
            
        except Exception as e:
            logger.log_error(e, {"context": "Cell classification"})
            return "unknown", 0.0
    
    def set_parameters(self, params: Dict) -> None:
        """Update analysis parameters"""
        with self._lock:
            self._params.update(params)
    
    def get_parameters(self) -> Dict:
        """Get current parameters"""
        return self._params.copy()
    
    @log_function
    def validate_results(self, results: List[WBCAnalysisResult], 
                        ground_truth: Optional[Dict] = None) -> Dict[str, float]:
        """Validate analysis results against ground truth"""
        metrics = {
            'total_cells': len(results),
            'avg_confidence': np.mean([r.confidence for r in results]),
            'type_distribution': {
                cell_type: len([r for r in results if r.cell_type == cell_type])
                for cell_type in self.cell_types
            }
        }
        
        if ground_truth:
            metrics['accuracy'] = sum(
                1 for r in results
                if r.cell_type == ground_truth.get(
                    f"{r.location[0]}_{r.location[1]}", ""
                )
            ) / len(results) if results else 0
        
        return metrics
    
    def cleanup(self) -> None:
        """Clean up resources"""
        pass

# Create global WBC analyzer instance
wbc_analyzer = WBCAnalyzer()

# Example usage
if __name__ == "__main__":
    # Create test image
    test_image = np.zeros((200, 200), dtype=np.uint8)
    cv2.circle(test_image, (100, 100), 30, 255, -1)
    cv2.circle(test_image, (100, 100), 15, 128, -1)
    
    # Analyze image
    results = wbc_analyzer.analyze(test_image)
    print(f"Found {len(results)} WBCs")
    for result in results:
        print(f"Cell type: {result.cell_type} (confidence: {result.confidence:.2f})")