# tiff_analyzer/analysis/roi.py

import numpy as np
from typing import Dict, List, Tuple, Optional, Any
import cv2
from dataclasses import dataclass
import threading
from ..utils.logger import logger, log_function
from ..utils.events import event_manager, EventType, Event

@dataclass
class ROI:
    """Represents a Region of Interest"""
    id: str
    type: str  # rectangle, ellipse, polygon
    frame: int
    coordinates: np.ndarray  # Nx2 array for polygon, 4 values for rectangle, 5 for ellipse
    metadata: Dict[str, Any]
    
    def get_mask(self, image_shape: Tuple[int, int]) -> np.ndarray:
        """Generate binary mask for the ROI"""
        mask = np.zeros(image_shape, dtype=np.uint8)
        
        if self.type == 'rectangle':
            x1, y1, x2, y2 = self.coordinates
            cv2.rectangle(mask, (int(x1), int(y1)), (int(x2), int(y2)), 1, -1)
            
        elif self.type == 'ellipse':
            center, axes, angle = self.coordinates
            cv2.ellipse(mask, 
                       (int(center[0]), int(center[1])),
                       (int(axes[0]), int(axes[1])),
                       angle, 0, 360, 1, -1)
            
        elif self.type == 'polygon':
            pts = self.coordinates.reshape((-1, 1, 2)).astype(np.int32)
            cv2.fillPoly(mask, [pts], 1)
            
        return mask.astype(bool)
    
    def contains_point(self, point: Tuple[float, float]) -> bool:
        """Check if point is inside ROI"""
        if self.type == 'rectangle':
            x1, y1, x2, y2 = self.coordinates
            return x1 <= point[0] <= x2 and y1 <= point[1] <= y2
            
        elif self.type == 'ellipse':
            center, axes, angle = self.coordinates
            # Transform point to ellipse coordinate system
            cos_angle = np.cos(np.radians(-angle))
            sin_angle = np.sin(np.radians(-angle))
            dx = point[0] - center[0]
            dy = point[1] - center[1]
            x = cos_angle * dx - sin_angle * dy
            y = sin_angle * dx + cos_angle * dy
            return (x/axes[0])**2 + (y/axes[1])**2 <= 1
            
        elif self.type == 'polygon':
            return cv2.pointPolygonTest(
                self.coordinates.astype(np.float32),
                point,
                False
            ) >= 0
            
        return False

class ROIManager:
    """Manages Regions of Interest"""
    
    def __init__(self):
        self._rois: Dict[str, ROI] = {}
        self._active_roi: Optional[str] = None
        self._lock = threading.Lock()
        self._roi_counter = 0
        
    @log_function
    def create_roi(self, roi_type: str, frame: int, 
                  coordinates: np.ndarray, metadata: Dict = None) -> str:
        """Create new ROI"""
        try:
            with self._lock:
                roi_id = f"roi_{self._roi_counter}"
                self._roi_counter += 1
                
                roi = ROI(
                    id=roi_id,
                    type=roi_type,
                    frame=frame,
                    coordinates=np.array(coordinates),
                    metadata=metadata or {}
                )
                
                self._rois[roi_id] = roi
                self._active_roi = roi_id
                
                # Emit ROI creation event
                event_manager.emit(Event(
                    EventType.ROI_CREATED,
                    data={
                        'id': roi_id,
                        'type': roi_type,
                        'frame': frame,
                        'coordinates': coordinates.tolist()
                    }
                ))
                
                return roi_id
                
        except Exception as e:
            logger.log_error(e, {
                "context": "ROI creation",
                "type": roi_type
            })
            return ""
    
    @log_function
    def update_roi(self, roi_id: str, coordinates: np.ndarray) -> bool:
        """Update ROI coordinates"""
        try:
            with self._lock:
                if roi_id not in self._rois:
                    return False
                    
                roi = self._rois[roi_id]
                roi.coordinates = np.array(coordinates)
                
                # Emit ROI update event
                event_manager.emit(Event(
                    EventType.ROI_MODIFIED,
                    data={
                        'id': roi_id,
                        'coordinates': coordinates.tolist()
                    }
                ))
                
                return True
                
        except Exception as e:
            logger.log_error(e, {
                "context": "ROI update",
                "roi_id": roi_id
            })
            return False
    
    @log_function
    def delete_roi(self, roi_id: str) -> bool:
        """Delete ROI"""
        try:
            with self._lock:
                if roi_id not in self._rois:
                    return False
                    
                del self._rois[roi_id]
                if self._active_roi == roi_id:
                    self._active_roi = None
                    
                # Emit ROI deletion event
                event_manager.emit(Event(
                    EventType.ROI_DELETED,
                    data={'id': roi_id}
                ))
                
                return True
                
        except Exception as e:
            logger.log_error(e, {
                "context": "ROI deletion",
                "roi_id": roi_id
            })
            return False
    
    def get_roi(self, roi_id: str) -> Optional[ROI]:
        """Get ROI by ID"""
        return self._rois.get(roi_id)
    
    def get_frame_rois(self, frame: int) -> List[ROI]:
        """Get all ROIs for a specific frame"""
        return [roi for roi in self._rois.values() if roi.frame == frame]
    
    def get_active_roi(self) -> Optional[ROI]:
        """Get currently active ROI"""
        return self._rois.get(self._active_roi)
    
    @log_function
    def set_active_roi(self, roi_id: str) -> bool:
        """Set active ROI"""
        if roi_id in self._rois:
            self._active_roi = roi_id
            return True
        return False
    
    @log_function
    def analyze_roi(self, roi_id: str, image: np.ndarray) -> Dict[str, Any]:
        """Analyze ROI content"""
        try:
            roi = self.get_roi(roi_id)
            if roi is None:
                return {}
                
            # Get ROI mask and apply to image
            mask = roi.get_mask(image.shape[:2])
            roi_content = image[mask]
            
            # Perform basic analysis
            analysis = {
                'mean_intensity': np.mean(roi_content),
                'std_intensity': np.std(roi_content),
                'min_intensity': np.min(roi_content),
                'max_intensity': np.max(roi_content),
                'area_pixels': np.sum(mask),
                'perimeter_pixels': cv2.arcLength(
                    roi.coordinates.astype(np.float32),
                    True
                ) if roi.type == 'polygon' else None
            }
            
            # Update ROI metadata with analysis
            roi.metadata.update({'analysis': analysis})
            
            return analysis
            
        except Exception as e:
            logger.log_error(e, {
                "context": "ROI analysis",
                "roi_id": roi_id
            })
            return {}
    
    @log_function
    def detect_rois(self, image: np.ndarray, 
                   detection_params: Dict[str, Any]) -> List[str]:
        """Automatically detect ROIs in image"""
        try:
            # Convert to grayscale if needed
            if len(image.shape) > 2:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            else:
                gray = image
                
            # Apply threshold
            thresh = cv2.threshold(
                gray,
                detection_params.get('threshold', 127),
                255,
                cv2.THRESH_BINARY | cv2.THRESH_OTSU
            )[1]
            
            # Find contours
            contours, _ = cv2.findContours(
                thresh,
                cv2.RETR_EXTERNAL,
                cv2.CHAIN_APPROX_SIMPLE
            )
            
            # Filter and create ROIs
            roi_ids = []
            min_area = detection_params.get('min_area', 100)
            
            for contour in contours:
                area = cv2.contourArea(contour)
                if area < min_area:
                    continue
                    
                roi_id = self.create_roi(
                    'polygon',
                    detection_params.get('frame', 0),
                    contour.squeeze(),
                    {'detected': True, 'area': area}
                )
                
                if roi_id:
                    roi_ids.append(roi_id)
            
            return roi_ids
            
        except Exception as e:
            logger.log_error(e, {"context": "ROI detection"})
            return []
    
    def export_rois(self) -> List[Dict[str, Any]]:
        """Export ROI data for saving"""
        return [{
            'id': roi.id,
            'type': roi.type,
            'frame': roi.frame,
            'coordinates': roi.coordinates.tolist(),
            'metadata': roi.metadata
        } for roi in self._rois.values()]
    
    @log_function
    def import_rois(self, roi_data: List[Dict[str, Any]]) -> bool:
        """Import ROI data"""
        try:
            with self._lock:
                self._rois.clear()
                self._roi_counter = 0
                
                for data in roi_data:
                    roi = ROI(
                        id=data['id'],
                        type=data['type'],
                        frame=data['frame'],
                        coordinates=np.array(data['coordinates']),
                        metadata=data['metadata']
                    )
                    self._rois[roi.id] = roi
                    
                    # Update counter
                    counter = int(roi.id.split('_')[1])
                    self._roi_counter = max(self._roi_counter, counter + 1)
                
                return True
                
        except Exception as e:
            logger.log_error(e, {"context": "ROI import"})
            return False
    
    def cleanup(self) -> None:
        """Clean up ROI manager"""
        with self._lock:
            self._rois.clear()
            self._active_roi = None
            self._roi_counter = 0

# Create global ROI manager instance
roi_manager = ROIManager()

# Example usage
if __name__ == "__main__":
    # Create test ROI
    coords = np.array([[0, 0], [100, 0], [100, 100], [0, 100]])
    roi_id = roi_manager.create_roi('polygon', 0, coords)
    
    # Test ROI detection
    test_image = np.zeros((200, 200), dtype=np.uint8)
    cv2.rectangle(test_image, (50, 50), (150, 150), 255, -1)
    detected_rois = roi_manager.detect_rois(test_image, {'threshold': 127})