# tiff_analyzer/analysis/measurements.py

import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
import cv2
from dataclasses import dataclass
import threading
from ..utils.logger import logger, log_function
from ..utils.events import event_manager, EventType, Event

@dataclass
class Measurement:
    """Container for measurement data"""
    type: str  # distance, area, intensity, angle
    value: float
    unit: str
    points: List[Tuple[float, float]]
    metadata: Dict[str, Any]

class MeasurementManager:
    """Manages measurements and calculations"""
    
    def __init__(self):
        self._lock = threading.Lock()
        self._measurements: Dict[str, List[Measurement]] = {}
        self._calibration = {
            'pixels_per_micron': 1.0,
            'unit': 'pixels'
        }
        self._measurement_counter = 0
    
    @log_function
    def add_measurement(self, image: np.ndarray, measurement_type: str,
                       points: List[Tuple[float, float]], 
                       metadata: Optional[Dict] = None) -> str:
        """Add new measurement"""
        try:
            # Generate measurement ID
            measurement_id = f"m_{self._measurement_counter}"
            self._measurement_counter += 1
            
            # Calculate measurement based on type
            if measurement_type == 'distance':
                value = self._measure_distance(points)
                unit = 'microns' if self._calibration['unit'] == 'microns' else 'pixels'
            elif measurement_type == 'area':
                value = self._measure_area(points)
                unit = 'sq_microns' if self._calibration['unit'] == 'microns' else 'sq_pixels'
            elif measurement_type == 'intensity':
                value = self._measure_intensity(image, points)
                unit = 'intensity'
            elif measurement_type == 'angle':
                value = self._measure_angle(points)
                unit = 'degrees'
            else:
                raise ValueError(f"Unknown measurement type: {measurement_type}")
            
            # Create measurement object
            measurement = Measurement(
                type=measurement_type,
                value=value,
                unit=unit,
                points=points,
                metadata=metadata or {}
            )
            
            # Store measurement
            with self._lock:
                if measurement_id not in self._measurements:
                    self._measurements[measurement_id] = []
                self._measurements[measurement_id].append(measurement)
            
            # Emit measurement event
            event_manager.emit(Event(
                EventType.MEASUREMENT_ADDED,
                data={
                    'id': measurement_id,
                    'type': measurement_type,
                    'value': value,
                    'unit': unit
                }
            ))
            
            return measurement_id
            
        except Exception as e:
            logger.log_error(e, {"context": "Adding measurement"})
            return ""
    
    def _measure_distance(self, points: List[Tuple[float, float]]) -> float:
        """Calculate distance between points"""
        if len(points) != 2:
            raise ValueError("Distance measurement requires exactly 2 points")
            
        p1, p2 = points
        distance = np.sqrt((p2[0] - p1[0])**2 + (p2[1] - p1[1])**2)
        
        if self._calibration['unit'] == 'microns':
            distance /= self._calibration['pixels_per_micron']
            
        return float(distance)
    
    def _measure_area(self, points: List[Tuple[float, float]]) -> float:
        """Calculate area of polygon"""
        if len(points) < 3:
            raise ValueError("Area measurement requires at least 3 points")
            
        # Convert points to numpy array
        points_array = np.array(points, dtype=np.int32)
        
        # Calculate area
        area = cv2.contourArea(points_array.reshape((-1, 1, 2)))
        
        if self._calibration['unit'] == 'microns':
            area /= (self._calibration['pixels_per_micron'] ** 2)
            
        return float(area)
    
    def _measure_intensity(self, image: np.ndarray, 
                         points: List[Tuple[float, float]]) -> float:
        """Calculate average intensity in region"""
        # Convert to grayscale if needed
        if len(image.shape) > 2:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
        
        # Create mask
        mask = np.zeros(gray.shape, dtype=np.uint8)
        points_array = np.array(points, dtype=np.int32)
        
        if len(points) == 1:  # Single point
            cv2.circle(mask, (int(points[0][0]), int(points[0][1])), 1, 255, -1)
        elif len(points) == 2:  # Line
            cv2.line(mask, 
                    (int(points[0][0]), int(points[0][1])),
                    (int(points[1][0]), int(points[1][1])), 255, 1)
        else:  # Polygon
            cv2.fillPoly(mask, [points_array], 255)
        
        # Calculate average intensity
        masked_image = cv2.bitwise_and(gray, gray, mask=mask)
        non_zero_pixels = cv2.countNonZero(mask)
        
        if non_zero_pixels > 0:
            return float(np.sum(masked_image) / non_zero_pixels)
        return 0.0
    
    def _measure_angle(self, points: List[Tuple[float, float]]) -> float:
        """Calculate angle between three points"""
        if len(points) != 3:
            raise ValueError("Angle measurement requires exactly 3 points")
            
        p1, p2, p3 = points
        
        # Calculate vectors
        v1 = np.array([p1[0] - p2[0], p1[1] - p2[1]])
        v2 = np.array([p3[0] - p2[0], p3[1] - p2[1]])
        
        # Calculate angle
        cos_angle = np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2))
        angle = np.arccos(np.clip(cos_angle, -1.0, 1.0))
        
        return float(np.degrees(angle))
    
    @log_function
    def set_calibration(self, pixels_per_micron: float, unit: str = 'microns') -> None:
        """Set calibration for measurements"""
        with self._lock:
            self._calibration['pixels_per_micron'] = pixels_per_micron
            self._calibration['unit'] = unit
    
    def get_calibration(self) -> Dict[str, Any]:
        """Get current calibration"""
        return self._calibration.copy()
    
    def get_measurement(self, measurement_id: str) -> List[Measurement]:
        """Get measurements by ID"""
        return self._measurements.get(measurement_id, [])
    
    def get_measurements_by_type(self, measurement_type: str) -> List[Measurement]:
        """Get all measurements of specific type"""
        measurements = []
        for m_list in self._measurements.values():
            measurements.extend([m for m in m_list if m.type == measurement_type])
        return measurements
    
    @log_function
    def delete_measurement(self, measurement_id: str) -> bool:
        """Delete measurement by ID"""
        try:
            with self._lock:
                if measurement_id in self._measurements:
                    del self._measurements[measurement_id]
                    event_manager.emit(Event(
                        EventType.MEASUREMENT_DELETED,
                        data={'id': measurement_id}
                    ))
                    return True
                return False
        except Exception as e:
            logger.log_error(e, {
                "context": "Deleting measurement",
                "id": measurement_id
            })
            return False
    
    @log_function
    def analyze_measurements(self, measurement_type: str) -> Dict[str, float]:
        """Analyze measurements of specific type"""
        try:
            measurements = self.get_measurements_by_type(measurement_type)
            if not measurements:
                return {}
            
            values = [m.value for m in measurements]
            
            return {
                'count': len(values),
                'mean': float(np.mean(values)),
                'std': float(np.std(values)),
                'min': float(np.min(values)),
                'max': float(np.max(values)),
                'unit': measurements[0].unit
            }
            
        except Exception as e:
            logger.log_error(e, {
                "context": "Analyzing measurements",
                "type": measurement_type
            })
            return {}
    
    def export_measurements(self) -> Dict[str, List[Dict[str, Any]]]:
        """Export all measurements"""
        export_data = {}
        for measurement_id, measurements in self._measurements.items():
            export_data[measurement_id] = [
                {
                    'type': m.type,
                    'value': m.value,
                    'unit': m.unit,
                    'points': m.points,
                    'metadata': m.metadata
                }
                for m in measurements
            ]
        return export_data
    
    @log_function
    def import_measurements(self, data: Dict[str, List[Dict[str, Any]]]) -> bool:
        """Import measurements"""
        try:
            with self._lock:
                self._measurements.clear()
                
                for measurement_id, measurements in data.items():
                    self._measurements[measurement_id] = [
                        Measurement(
                            type=m['type'],
                            value=m['value'],
                            unit=m['unit'],
                            points=m['points'],
                            metadata=m['metadata']
                        )
                        for m in measurements
                    ]
                
                # Update counter
                self._measurement_counter = max(
                    (int(mid.split('_')[1]) for mid in self._measurements.keys()),
                    default=0
                ) + 1
                
                return True
                
        except Exception as e:
            logger.log_error(e, {"context": "Importing measurements"})
            return False
    
    def cleanup(self) -> None:
        """Clean up measurement manager"""
        with self._lock:
            self._measurements.clear()
            self._measurement_counter = 0

# Create global measurement manager instance
measurement_manager = MeasurementManager()

# Example usage
if __name__ == "__main__":
    # Create test image
    test_image = np.zeros((200, 200), dtype=np.uint8)
    cv2.circle(test_image, (100, 100), 30, 255, -1)
    
    # Add distance measurement
    points = [(50, 50), (150, 150)]
    measurement_id = measurement_manager.add_measurement(
        test_image, 'distance', points
    )
    print(f"Distance: {measurement_manager.get_measurement(measurement_id)[0].value}")