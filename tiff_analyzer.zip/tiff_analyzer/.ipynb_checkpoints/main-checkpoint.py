# tiff_analyzer/main.py

import sys
import tkinter as tk
from pathlib import Path
import threading

from .utils.logger import logger
from .utils.settings import settings
from .utils.events import event_manager, EventType, Event
from .core import core_manager
from .ui import ui_manager

class TIFFAnalyzer:
    """Main application class"""
    
    def __init__(self):
        # Create root window first
        self.root = tk.Tk()
        self.root.title("TIFF Stack Analyzer")
        self._initialize_app()
    
    def _initialize_app(self) -> None:
        """Initialize application components"""
        try:
            # Initialize core components first
            if not core_manager.initialize():
                self._show_error("Failed to initialize core components")
                sys.exit(1)
            
            # Initialize UI with root window
            if not ui_manager.initialize(self.root):
                self._show_error("Failed to initialize UI")
                sys.exit(1)
            
            # Set up event handlers
            self._setup_event_handlers()
            
            # Configure window
            self._configure_window()
            
            # Register cleanup
            self.root.protocol("WM_DELETE_WINDOW", self._on_closing)
            
            logger.logger.info("Application initialized successfully")
            
        except Exception as e:
            logger.log_error(e, {"context": "Application initialization"})
            self._show_error(f"Initialization error: {str(e)}")
            sys.exit(1)
    
    def _configure_window(self) -> None:
        """Configure main window"""
        # Load window size from settings
        width = settings.get('display', 'window_width', 1200)
        height = settings.get('display', 'window_height', 800)
        
        # Center window on screen
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        x = (screen_width - width) // 2
        y = (screen_height - height) // 2
        
        self.root.geometry(f"{width}x{height}+{x}+{y}")
        
        # Configure grid weights for responsive layout
        self.root.grid_columnconfigure(0, weight=1)
        self.root.grid_rowconfigure(0, weight=1)

        # Make sure window is visible
        self.root.lift()
        self.root.attributes('-topmost', True)
        self.root.after_idle(self.root.attributes, '-topmost', False)
    
    def _setup_event_handlers(self) -> None:
        """Setup application event handlers"""
        event_manager.subscribe(EventType.ERROR_OCCURRED, self._handle_error)
        event_manager.subscribe(EventType.STATE_CHANGED, self._handle_state_change)
    
    def _handle_error(self, event: Event) -> None:
        """Handle error events"""
        error_data = event.data
        self._show_error(error_data.get('message', 'An error occurred'))
    
    def _handle_state_change(self, event: Event) -> None:
        """Handle state change events"""
        if 'quit' in event.data:
            self.quit()
    
    def _show_error(self, message: str) -> None:
        """Show error dialog"""
        from tkinter import messagebox
        messagebox.showerror("Error", message, parent=self.root)
    
    def _on_closing(self) -> None:
        """Handle application closing"""
        try:
            # Save settings
            settings.save_settings()
            
            # Clean up components
            core_manager.cleanup()
            ui_manager.cleanup()
            
            # Destroy root window
            self.root.destroy()
            
        except Exception as e:
            logger.log_error(e, {"context": "Application cleanup"})
    
    def run(self) -> None:
        """Run the application"""
        try:
            # Check for auto-load session
            if settings.get('general', 'load_last_session', False):
                self._load_last_session()
            
            # Update the UI before starting mainloop
            self.root.update_idletasks()
            
            # Start main loop
            self.root.mainloop()
            
        except Exception as e:
            logger.log_error(e, {"context": "Application runtime"})
            self._show_error("Runtime error occurred")
    
    def _load_last_session(self) -> None:
        """Load last session if available"""
        try:
            from .data import data_manager
            last_session = data_manager.get_last_session()
            if last_session:
                data_manager.load_session(last_session)
        except Exception as e:
            logger.log_error(e, {"context": "Loading last session"})
    
    def quit(self) -> None:
        """Quit application"""
        if self.root:
            self.root.quit()

def main():
    """Application entry point"""
    try:
        # Create and run application
        app = TIFFAnalyzer()
        app.run()
        
    except Exception as e:
        # Log error and show message
        if hasattr(logger, 'logger'):
            logger.log_error(e, {"context": "Application main"})
        print(f"Fatal error: {str(e)}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()