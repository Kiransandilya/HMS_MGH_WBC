# tiff_analyzer/__init__.py

import logging
from pathlib import Path

# Setup version
__version__ = '1.0.0'

# Setup base paths
ROOT_DIR = Path(__file__).parent
DATA_DIR = ROOT_DIR / 'data'
LOGS_DIR = ROOT_DIR / 'logs'

# Create necessary directories
DATA_DIR.mkdir(exist_ok=True)
LOGS_DIR.mkdir(exist_ok=True)

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOGS_DIR / 'tiff_analyzer.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

# Feature availability tracking
class FeatureManager:
    _features = {}
    
    @classmethod
    def register_feature(cls, feature_name, available=True):
        """Register a feature and its availability"""
        cls._features[feature_name] = available
        logger.info(f"Feature registered: {feature_name} (Available: {available})")
    
    @classmethod
    def is_feature_available(cls, feature_name):
        """Check if a feature is available"""
        return cls._features.get(feature_name, False)
    
    @classmethod
    def disable_feature(cls, feature_name):
        """Disable a feature"""
        cls._features[feature_name] = False
        logger.warning(f"Feature disabled: {feature_name}")
    
    @classmethod
    def get_available_features(cls):
        """Get list of available features"""
        return [k for k, v in cls._features.items() if v]

# Exception classes for graceful error handling
class TiffAnalyzerError(Exception):
    """Base exception class for TiffAnalyzer"""
    pass

class FeatureNotAvailableError(TiffAnalyzerError):
    """Raised when a feature is not available"""
    pass

class ImageLoadError(TiffAnalyzerError):
    """Raised when there's an error loading images"""
    pass

class AnalysisError(TiffAnalyzerError):
    """Raised when there's an error in analysis"""
    pass

# Feature registration decorator
def register_feature(feature_name):
    """Decorator to register and handle feature availability"""
    def decorator(func):
        def wrapper(*args, **kwargs):
            if not FeatureManager.is_feature_available(feature_name):
                logger.warning(f"Attempted to use unavailable feature: {feature_name}")
                raise FeatureNotAvailableError(f"Feature {feature_name} is not available")
            try:
                return func(*args, **kwargs)
            except Exception as e:
                logger.error(f"Error in feature {feature_name}: {str(e)}")
                FeatureManager.disable_feature(feature_name)
                raise
        FeatureManager.register_feature(feature_name)
        return wrapper
    return decorator

# Initialize core features
def initialize_core_features():
    """Initialize and register core features"""
    try:
        import tifffile
        FeatureManager.register_feature('tiff_support')
    except ImportError:
        logger.error("tifffile not found. TIFF support will be disabled.")
        FeatureManager.register_feature('tiff_support', False)

    try:
        import numpy as np
        FeatureManager.register_feature('numpy_support')
    except ImportError:
        logger.error("numpy not found. Advanced analysis features will be disabled.")
        FeatureManager.register_feature('numpy_support', False)

# Run initialization
initialize_core_features()