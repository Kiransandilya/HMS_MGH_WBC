# tiff_analyzer/data/__init__.py

from typing import Dict, Any, Optional
from pathlib import Path
import threading
from ..utils.logger import logger, log_function
from ..utils.settings import settings
from ..utils.events import event_manager, EventType, Event

class DataManager:
    """Manages data operations, sessions, and exports"""
    
    def __init__(self):
        self._initialized = False
        self._lock = threading.Lock()
        self._data_dir = Path(settings.get('general', 'data_directory', 
                                         Path.home() / '.tiff_analyzer' / 'data'))
        self._current_session = None
        self._export_formats = {
            'image': ['tiff', 'png', 'jpg'],
            'data': ['csv', 'json', 'xlsx']
        }
    
    @log_function
    def initialize(self) -> bool:
        """Initialize data management system"""
        if self._initialized:
            return True
            
        try:
            with self._lock:
                # Create necessary directories
                self._ensure_directories()
                
                # Initialize components
                self._init_session_manager()
                self._init_export_manager()
                
                self._initialized = True
                logger.logger.info("Data management system initialized")
                return True
                
        except Exception as e:
            logger.log_error(e, {"context": "Data initialization"})
            return False
    
    def _ensure_directories(self) -> None:
        """Ensure required directories exist"""
        directories = [
            self._data_dir,
            self._data_dir / 'sessions',
            self._data_dir / 'exports',
            self._data_dir / 'cache'
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
    
    def _init_session_manager(self) -> None:
        """Initialize session management"""
        from .session import session_manager
        self._session_manager = session_manager
        
        # Register session events
        event_manager.subscribe(
            EventType.STATE_CHANGED,
            self._handle_state_change
        )
    
    def _init_export_manager(self) -> None:
        """Initialize export management"""
        from .export import export_manager
        self._export_manager = export_manager
    
    @log_function
    def create_session(self, name: Optional[str] = None) -> bool:
        """Create new session"""
        try:
            if self._session_manager.create_session(name):
                event_manager.emit(Event(
                    EventType.SESSION_CREATED,
                    data={'name': name}
                ))
                return True
            return False
        except Exception as e:
            logger.log_error(e, {"context": "Creating session"})
            return False
    
    @log_function
    def load_session(self, session_id: str) -> bool:
        """Load existing session"""
        try:
            if self._session_manager.load_session(session_id):
                event_manager.emit(Event(
                    EventType.SESSION_LOADED,
                    data={'session_id': session_id}
                ))
                return True
            return False
        except Exception as e:
            logger.log_error(e, {"context": "Loading session"})
            return False
    
    @log_function
    def save_session(self) -> bool:
        """Save current session"""
        try:
            if self._session_manager.save_current_session():
                event_manager.emit(Event(EventType.SESSION_SAVED))
                return True
            return False
        except Exception as e:
            logger.log_error(e, {"context": "Saving session"})
            return False
    
    @log_function
    def export_data(self, data: Any, format: str, path: Optional[Path] = None) -> bool:
        """Export data in specified format"""
        try:
            if self._export_manager.export_data(data, format, path):
                event_manager.emit(Event(
                    EventType.DATA_EXPORTED,
                    data={'format': format, 'path': str(path)}
                ))
                return True
            return False
        except Exception as e:
            logger.log_error(e, {"context": "Exporting data"})
            return False
    
    def _handle_state_change(self, event: Event) -> None:
        """Handle application state changes"""
        if settings.get('general', 'auto_save', True):
            self.save_session()
    
    @property
    def current_session(self) -> Optional[str]:
        """Get current session ID"""
        return self._session_manager.current_session_id
    
    @property
    def available_sessions(self) -> list:
        """Get list of available sessions"""
        return self._session_manager.get_available_sessions()
    
    @property
    def export_formats(self) -> Dict[str, list]:
        """Get available export formats"""
        return self._export_formats.copy()
    
    def get_data_path(self, category: str) -> Path:
        """Get path for specific data category"""
        category_path = self._data_dir / category
        category_path.mkdir(exist_ok=True)
        return category_path
    
    def cleanup(self) -> None:
        """Clean up data management system"""
        if not self._initialized:
            return
            
        try:
            # Save current session
            self.save_session()
            
            # Clean up components
            self._session_manager.cleanup()
            self._export_manager.cleanup()
            
            self._initialized = False
            
        except Exception as e:
            logger.log_error(e, {"context": "Data cleanup"})

# Create global data manager instance
data_manager = DataManager()

# Initialize data management system
data_manager.initialize()

# Export components
__all__ = [
    'data_manager',
    'session_manager',
    'export_manager'
]