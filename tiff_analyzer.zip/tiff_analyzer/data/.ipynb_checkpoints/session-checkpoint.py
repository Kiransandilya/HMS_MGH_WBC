# tiff_analyzer/data/session.py

from typing import Dict, Any, Optional, List
import json
import time
from pathlib import Path
from datetime import datetime
import threading
from ..utils.logger import logger, log_function
from ..utils.settings import settings
from ..core.state_manager import state_manager

class Session:
    """Represents a single analysis session"""
    
    def __init__(self, session_id: str = None):
        self.id = session_id or self._generate_session_id()
        self.created_at = datetime.now().isoformat()
        self.last_modified = self.created_at
        self.data: Dict[str, Any] = {
            'metadata': {
                'id': self.id,
                'created_at': self.created_at,
                'last_modified': self.last_modified,
                'version': '1.0'
            },
            'state': {},
            'analysis': {},
            'marked_frames': [],
            'roi_data': [],
            'annotations': {}
        }
    
    def _generate_session_id(self) -> str:
        """Generate unique session ID"""
        timestamp = int(time.time() * 1000)
        return f"session_{timestamp}"
    
    def update_state(self, state_data: Dict[str, Any]) -> None:
        """Update session state"""
        self.data['state'] = state_data
        self.last_modified = datetime.now().isoformat()
        self.data['metadata']['last_modified'] = self.last_modified
    
    def add_analysis(self, analysis_data: Dict[str, Any]) -> None:
        """Add analysis results"""
        self.data['analysis'].update(analysis_data)
        self.last_modified = datetime.now().isoformat()
        self.data['metadata']['last_modified'] = self.last_modified
    
    def mark_frame(self, frame_number: int) -> None:
        """Mark a frame"""
        if frame_number not in self.data['marked_frames']:
            self.data['marked_frames'].append(frame_number)
            self.data['marked_frames'].sort()
    
    def add_roi(self, roi_data: Dict[str, Any]) -> None:
        """Add ROI data"""
        self.data['roi_data'].append(roi_data)
    
    def add_annotation(self, frame: int, annotation: str) -> None:
        """Add frame annotation"""
        if str(frame) not in self.data['annotations']:
            self.data['annotations'][str(frame)] = []
        self.data['annotations'][str(frame)].append({
            'text': annotation,
            'timestamp': datetime.now().isoformat()
        })

class SessionManager:
    """Manages analysis sessions"""
    
    def __init__(self):
        self._sessions_dir = Path(settings.get('general', 'data_directory')) / 'sessions'
        self._sessions_dir.mkdir(parents=True, exist_ok=True)
        self._current_session: Optional[Session] = None
        self._lock = threading.Lock()
        self._auto_save = settings.get('general', 'auto_save', True)
        self._auto_save_interval = settings.get('general', 'auto_save_interval', 300)  # 5 minutes
        self._setup_auto_save()
    
    def _setup_auto_save(self) -> None:
        """Setup auto-save functionality"""
        if self._auto_save:
            def auto_save():
                while self._auto_save:
                    time.sleep(self._auto_save_interval)
                    if self._current_session:
                        self.save_current_session()
            
            threading.Thread(target=auto_save, daemon=True).start()
    
    @log_function
    def create_session(self, name: Optional[str] = None) -> bool:
        """Create new session"""
        try:
            with self._lock:
                self._current_session = Session(name)
                # Get initial state
                current_state = state_manager.get_state()
                self._current_session.update_state(current_state)
                return True
        except Exception as e:
            logger.log_error(e, {"context": "Creating session"})
            return False
    
    @log_function
    def save_current_session(self) -> bool:
        """Save current session to file"""
        if not self._current_session:
            return False
            
        try:
            with self._lock:
                # Update session state
                current_state = state_manager.get_state()
                self._current_session.update_state(current_state)
                
                # Save to file
                session_file = self._sessions_dir / f"{self._current_session.id}.json"
                with open(session_file, 'w') as f:
                    json.dump(self._current_session.data, f, indent=4)
                return True
        except Exception as e:
            logger.log_error(e, {"context": "Saving session"})
            return False
    
    @log_function
    def load_session(self, session_id: str) -> bool:
        """Load session from file"""
        session_file = self._sessions_dir / f"{session_id}.json"
        
        if not session_file.exists():
            logger.logger.error(f"Session file not found: {session_id}")
            return False
            
        try:
            with self._lock:
                with open(session_file, 'r') as f:
                    session_data = json.load(f)
                
                # Create new session with loaded data
                self._current_session = Session(session_id)
                self._current_session.data = session_data
                
                # Restore application state
                if 'state' in session_data:
                    state_manager.restore_state(session_data['state'])
                
                return True
        except Exception as e:
            logger.log_error(e, {"context": "Loading session"})
            return False
    
    @log_function
    def delete_session(self, session_id: str) -> bool:
        """Delete session file"""
        try:
            session_file = self._sessions_dir / f"{session_id}.json"
            if session_file.exists():
                session_file.unlink()
                return True
            return False
        except Exception as e:
            logger.log_error(e, {"context": "Deleting session"})
            return False
    
    def get_available_sessions(self) -> List[Dict[str, Any]]:
        """Get list of available sessions"""
        sessions = []
        try:
            for session_file in self._sessions_dir.glob('*.json'):
                try:
                    with open(session_file, 'r') as f:
                        data = json.load(f)
                        sessions.append({
                            'id': data['metadata']['id'],
                            'created_at': data['metadata']['created_at'],
                            'last_modified': data['metadata']['last_modified']
                        })
                except Exception as e:
                    logger.log_error(e, {
                        "context": "Reading session file",
                        "file": str(session_file)
                    })
        except Exception as e:
            logger.log_error(e, {"context": "Listing sessions"})
        
        return sorted(sessions, key=lambda x: x['last_modified'], reverse=True)
    
    def get_session_metadata(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get session metadata"""
        session_file = self._sessions_dir / f"{session_id}.json"
        try:
            if session_file.exists():
                with open(session_file, 'r') as f:
                    data = json.load(f)
                    return data['metadata']
            return None
        except Exception as e:
            logger.log_error(e, {"context": "Getting session metadata"})
            return None
    
    @property
    def current_session_id(self) -> Optional[str]:
        """Get current session ID"""
        return self._current_session.id if self._current_session else None
    
    def cleanup(self) -> None:
        """Clean up session manager"""
        if self._current_session:
            self.save_current_session()
        self._auto_save = False

# Create global session manager instance
session_manager = SessionManager()

# Example usage
if __name__ == "__main__":
    # Create new session
    session_manager.create_session()
    
    # Save some data
    if session_manager._current_session:
        session_manager._current_session.mark_frame(1)
        session_manager._current_session.add_annotation(1, "Test annotation")
        
    # Save session
    session_manager.save_current_session()