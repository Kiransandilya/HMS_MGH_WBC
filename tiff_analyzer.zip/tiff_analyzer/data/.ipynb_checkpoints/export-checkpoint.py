# tiff_analyzer/data/export.py

from typing import Dict, Any, Optional, Union, List
import json
import csv
import numpy as np
from pathlib import Path
import threading
from datetime import datetime
import pandas as pd
from ..utils.logger import logger, log_function
from ..utils.settings import settings

class DataExporter:
    """Base class for data exporters"""
    def export(self, data: Any, path: Path) -> bool:
        raise NotImplementedError

class ImageExporter(DataExporter):
    """Handles image and stack exports"""
    
    @log_function
    def export(self, data: np.ndarray, path: Path) -> bool:
        """Export image data"""
        try:
            import tifffile
            
            # Handle single frame vs stack
            if len(data.shape) == 2:  # Single frame
                tifffile.imwrite(path, data)
            else:  # Stack
                tifffile.imwrite(path, data, imagej=True)
            return True
            
        except Exception as e:
            logger.log_error(e, {
                "context": "Exporting image",
                "path": str(path)
            })
            return False
    
    @log_function
    def export_marked_frames(self, stack: np.ndarray, marked_frames: List[int], 
                           output_dir: Path) -> bool:
        """Export marked frames"""
        try:
            output_dir.mkdir(parents=True, exist_ok=True)
            
            for frame_num in marked_frames:
                if 0 <= frame_num < len(stack):
                    frame_path = output_dir / f"frame_{frame_num:04d}.tif"
                    if not self.export(stack[frame_num], frame_path):
                        return False
            return True
            
        except Exception as e:
            logger.log_error(e, {
                "context": "Exporting marked frames",
                "output_dir": str(output_dir)
            })
            return False

class AnalysisExporter(DataExporter):
    """Handles analysis data exports"""
    
    @log_function
    def export(self, data: Dict[str, Any], path: Path) -> bool:
        """Export analysis data"""
        try:
            # Determine format from extension
            format_ = path.suffix.lower()[1:]
            
            if format_ == 'json':
                return self._export_json(data, path)
            elif format_ == 'csv':
                return self._export_csv(data, path)
            elif format_ in ['xlsx', 'xls']:
                return self._export_excel(data, path)
            else:
                logger.logger.error(f"Unsupported export format: {format_}")
                return False
                
        except Exception as e:
            logger.log_error(e, {
                "context": "Exporting analysis",
                "path": str(path)
            })
            return False
    
    def _export_json(self, data: Dict[str, Any], path: Path) -> bool:
        """Export data as JSON"""
        try:
            with open(path, 'w') as f:
                json.dump(data, f, indent=4, default=self._json_serializer)
            return True
        except Exception as e:
            logger.log_error(e, {"context": "JSON export"})
            return False
    
    def _export_csv(self, data: Dict[str, Any], path: Path) -> bool:
        """Export data as CSV"""
        try:
            # Convert data to DataFrame
            df = self._convert_to_dataframe(data)
            df.to_csv(path, index=False)
            return True
        except Exception as e:
            logger.log_error(e, {"context": "CSV export"})
            return False
    
    def _export_excel(self, data: Dict[str, Any], path: Path) -> bool:
        """Export data as Excel"""
        try:
            writer = pd.ExcelWriter(path, engine='xlsxwriter')
            
            # Export each data category to separate sheet
            for category, category_data in data.items():
                df = self._convert_to_dataframe({category: category_data})
                df.to_excel(writer, sheet_name=category, index=False)
            
            writer.save()
            return True
        except Exception as e:
            logger.log_error(e, {"context": "Excel export"})
            return False
    
    def _convert_to_dataframe(self, data: Dict[str, Any]) -> pd.DataFrame:
        """Convert data to pandas DataFrame"""
        # Flatten nested dictionaries
        flat_data = self._flatten_dict(data)
        return pd.DataFrame([flat_data])
    
    def _flatten_dict(self, d: Dict[str, Any], parent_key: str = '', 
                     sep: str = '_') -> Dict[str, Any]:
        """Flatten nested dictionary"""
        items = []
        for k, v in d.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            if isinstance(v, dict):
                items.extend(self._flatten_dict(v, new_key, sep).items())
            else:
                items.append((new_key, v))
        return dict(items)
    
    def _json_serializer(self, obj: Any) -> str:
        """JSON serializer for objects not serializable by default json code"""
        if isinstance(obj, (datetime, np.datetime64)):
            return obj.isoformat()
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.floating):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        raise TypeError(f"Type {type(obj)} not serializable")

class ROIExporter(DataExporter):
    """Handles ROI data exports"""
    
    @log_function
    def export(self, data: List[Dict[str, Any]], path: Path) -> bool:
        """Export ROI data"""
        try:
            format_ = path.suffix.lower()[1:]
            
            if format_ == 'json':
                return self._export_json(data, path)
            elif format_ == 'csv':
                return self._export_csv(data, path)
            else:
                logger.logger.error(f"Unsupported ROI export format: {format_}")
                return False
                
        except Exception as e:
            logger.log_error(e, {
                "context": "Exporting ROIs",
                "path": str(path)
            })
            return False
    
    def _export_json(self, data: List[Dict[str, Any]], path: Path) -> bool:
        """Export ROIs as JSON"""
        try:
            with open(path, 'w') as f:
                json.dump({
                    'rois': data,
                    'metadata': {
                        'exported_at': datetime.now().isoformat(),
                        'count': len(data)
                    }
                }, f, indent=4)
            return True
        except Exception as e:
            logger.log_error(e, {"context": "ROI JSON export"})
            return False
    
    def _export_csv(self, data: List[Dict[str, Any]], path: Path) -> bool:
        """Export ROIs as CSV"""
        try:
            # Get all unique keys
            keys = set()
            for roi in data:
                keys.update(roi.keys())
            
            with open(path, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=sorted(keys))
                writer.writeheader()
                writer.writerows(data)
            return True
        except Exception as e:
            logger.log_error(e, {"context": "ROI CSV export"})
            return False

class ExportManager:
    """Manages data exports"""
    
    def __init__(self):
        self._lock = threading.Lock()
        self._exporters = {
            'image': ImageExporter(),
            'analysis': AnalysisExporter(),
            'roi': ROIExporter()
        }
        self._export_dir = Path(settings.get('general', 'export_directory', 
                                           Path.home() / 'tiff_analyzer_exports'))
        self._export_dir.mkdir(parents=True, exist_ok=True)
    
    @log_function
    def export_data(self, data: Any, export_type: str, path: Optional[Path] = None) -> bool:
        """Export data using appropriate exporter"""
        try:
            with self._lock:
                if export_type not in self._exporters:
                    logger.logger.error(f"Unknown export type: {export_type}")
                    return False
                
                # Generate default path if none provided
                if path is None:
                    path = self._generate_export_path(export_type)
                
                return self._exporters[export_type].export(data, path)
                
        except Exception as e:
            logger.log_error(e, {
                "context": "Data export",
                "type": export_type
            })
            return False
    
    def _generate_export_path(self, export_type: str) -> Path:
        """Generate default export path"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        if export_type == 'image':
            return self._export_dir / f"export_{timestamp}.tif"
        elif export_type == 'analysis':
            return self._export_dir / f"analysis_{timestamp}.xlsx"
        elif export_type == 'roi':
            return self._export_dir / f"roi_{timestamp}.json"
        else:
            return self._export_dir / f"export_{timestamp}.dat"
    
    def get_export_path(self) -> Path:
        """Get export directory path"""
        return self._export_dir
    
    def cleanup(self) -> None:
        """Clean up export manager"""
        pass  # Add cleanup if needed

# Create global export manager instance
export_manager = ExportManager()

# Example usage
if __name__ == "__main__":
    # Test data export
    test_data = {
        'analysis': {
            'result1': 42,
            'result2': 'test'
        }
    }
    export_manager.export_data(test_data, 'analysis')