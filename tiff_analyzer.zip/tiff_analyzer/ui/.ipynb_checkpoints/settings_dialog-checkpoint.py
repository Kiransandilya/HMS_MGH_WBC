# tiff_analyzer/utils/settings.py

import tkinter as tk
from tkinter import ttk, colorchooser
from typing import Dict, Any, Optional
from ..utils.logger import logger, log_function
from ..utils.config import config_manager
from ..core.state_manager import state_manager

class SettingsDialog:
    """Application settings dialog with categorized settings"""
    
    def __init__(self, parent: tk.Tk):
        self.parent = parent
        self.dialog = tk.Toplevel(parent)
        self.dialog.title("Settings")
        self.dialog.geometry("800x600")
        self.dialog.transient(parent)
        self.dialog.grab_set()
        
        # Variables to store settings
        self._settings_vars: Dict[str, Dict[str, tk.Variable]] = {
            'general': {},
            'display': {},
            'playback': {},
            'analysis': {},
            'export': {},
            'advanced': {}
        }
        
        self._create_dialog()
        self._load_current_settings()
    
    def _create_dialog(self) -> None:
        """Create settings dialog interface"""
        # Main container
        main_frame = ttk.Frame(self.dialog, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create notebook for categories
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Create settings pages
        self._create_general_settings()
        self._create_display_settings()
        self._create_playback_settings()
        self._create_analysis_settings()
        self._create_export_settings()
        self._create_advanced_settings()
        
        # Buttons frame
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(10, 0))
        
        ttk.Button(
            button_frame,
            text="Apply",
            command=self._apply_settings
        ).pack(side=tk.RIGHT, padx=5)
        
        ttk.Button(
            button_frame,
            text="OK",
            command=self._save_and_close
        ).pack(side=tk.RIGHT, padx=5)
        
        ttk.Button(
            button_frame,
            text="Cancel",
            command=self.dialog.destroy
        ).pack(side=tk.RIGHT, padx=5)
        
        ttk.Button(
            button_frame,
            text="Reset to Defaults",
            command=self._reset_to_defaults
        ).pack(side=tk.LEFT, padx=5)
    
    def _create_general_settings(self) -> None:
        """Create general settings page"""
        frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(frame, text="General")
        
        # Startup behavior
        startup_frame = ttk.LabelFrame(frame, text="Startup", padding="5")
        startup_frame.pack(fill=tk.X, pady=5)
        
        self._settings_vars['general']['load_last_session'] = tk.BooleanVar()
        ttk.Checkbutton(
            startup_frame,
            text="Load last session on startup",
            variable=self._settings_vars['general']['load_last_session']
        ).pack(anchor='w')
        
        self._settings_vars['general']['check_updates'] = tk.BooleanVar()
        ttk.Checkbutton(
            startup_frame,
            text="Check for updates on startup",
            variable=self._settings_vars['general']['check_updates']
        ).pack(anchor='w')
        
        # File handling
        files_frame = ttk.LabelFrame(frame, text="File Handling", padding="5")
        files_frame.pack(fill=tk.X, pady=5)
        
        self._settings_vars['general']['auto_save'] = tk.BooleanVar()
        ttk.Checkbutton(
            files_frame,
            text="Auto-save analysis results",
            variable=self._settings_vars['general']['auto_save']
        ).pack(anchor='w')
        
        # Recent files limit
        ttk.Label(
            files_frame,
            text="Number of recent files:"
        ).pack(anchor='w')
        
        self._settings_vars['general']['recent_files_limit'] = tk.StringVar()
        ttk.Spinbox(
            files_frame,
            from_=0,
            to=20,
            width=5,
            textvariable=self._settings_vars['general']['recent_files_limit']
        ).pack(anchor='w')
    
    def _create_display_settings(self) -> None:
        """Create display settings page"""
        frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(frame, text="Display")
        
        # Theme settings
        theme_frame = ttk.LabelFrame(frame, text="Theme", padding="5")
        theme_frame.pack(fill=tk.X, pady=5)
        
        self._settings_vars['display']['theme'] = tk.StringVar()
        ttk.Radiobutton(
            theme_frame,
            text="Light Theme",
            value="light",
            variable=self._settings_vars['display']['theme']
        ).pack(anchor='w')
        
        ttk.Radiobutton(
            theme_frame,
            text="Dark Theme",
            value="dark",
            variable=self._settings_vars['display']['theme']
        ).pack(anchor='w')
        
        # View settings
        view_frame = ttk.LabelFrame(frame, text="View", padding="5")
        view_frame.pack(fill=tk.X, pady=5)
        
        self._settings_vars['display']['default_view'] = tk.StringVar()
        ttk.Label(view_frame, text="Default View:").pack(anchor='w')
        ttk.OptionMenu(
            view_frame,
            self._settings_vars['display']['default_view'],
            "side_by_side",
            "side_by_side",
            "overlay",
            "top_bottom"
        ).pack(anchor='w')
        
        # Image display
        image_frame = ttk.LabelFrame(frame, text="Image Display", padding="5")
        image_frame.pack(fill=tk.X, pady=5)
        
        self._settings_vars['display']['interpolation'] = tk.BooleanVar()
        ttk.Checkbutton(
            image_frame,
            text="Use interpolation",
            variable=self._settings_vars['display']['interpolation']
        ).pack(anchor='w')
        
        self._settings_vars['display']['auto_contrast'] = tk.BooleanVar()
        ttk.Checkbutton(
            image_frame,
            text="Auto-contrast on load",
            variable=self._settings_vars['display']['auto_contrast']
        ).pack(anchor='w')
    
    def _create_playback_settings(self) -> None:
        """Create playback settings page"""
        frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(frame, text="Playback")
        
        # Playback controls
        playback_frame = ttk.LabelFrame(frame, text="Playback Controls", padding="5")
        playback_frame.pack(fill=tk.X, pady=5)
        
        # Default FPS
        ttk.Label(
            playback_frame,
            text="Default FPS:"
        ).pack(anchor='w')
        
        self._settings_vars['playback']['default_fps'] = tk.StringVar()
        ttk.Spinbox(
            playback_frame,
            from_=1,
            to=60,
            width=5,
            textvariable=self._settings_vars['playback']['default_fps']
        ).pack(anchor='w')
        
        # Loop playback
        self._settings_vars['playback']['loop'] = tk.BooleanVar()
        ttk.Checkbutton(
            playback_frame,
            text="Loop playback by default",
            variable=self._settings_vars['playback']['loop']
        ).pack(anchor='w')
        
        # Frame interpolation
        self._settings_vars['playback']['interpolation'] = tk.BooleanVar()
        ttk.Checkbutton(
            playback_frame,
            text="Enable frame interpolation",
            variable=self._settings_vars['playback']['interpolation']
        ).pack(anchor='w')
    
    def _create_analysis_settings(self) -> None:
        """Create analysis settings page"""
        frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(frame, text="Analysis")
        
        # ROI settings
        roi_frame = ttk.LabelFrame(frame, text="ROI Settings", padding="5")
        roi_frame.pack(fill=tk.X, pady=5)
        
        self._settings_vars['analysis']['default_roi'] = tk.StringVar()
        ttk.Label(roi_frame, text="Default ROI Tool:").pack(anchor='w')
        ttk.OptionMenu(
            roi_frame,
            self._settings_vars['analysis']['default_roi'],
            "rectangle",
            "rectangle",
            "ellipse",
            "polygon"
        ).pack(anchor='w')
        
        # WBC Analysis
        wbc_frame = ttk.LabelFrame(frame, text="WBC Analysis", padding="5")
        wbc_frame.pack(fill=tk.X, pady=5)
        
        self._settings_vars['analysis']['auto_detection'] = tk.BooleanVar()
        ttk.Checkbutton(
            wbc_frame,
            text="Enable automatic WBC detection",
            variable=self._settings_vars['analysis']['auto_detection']
        ).pack(anchor='w')
        
        self._settings_vars['analysis']['feature_extraction'] = tk.StringVar()
        ttk.Label(wbc_frame, text="Feature Extraction Level:").pack(anchor='w')
        ttk.OptionMenu(
            wbc_frame,
            self._settings_vars['analysis']['feature_extraction'],
            "basic",
            "basic",
            "advanced",
            "complete"
        ).pack(anchor='w')
    
    def _create_export_settings(self) -> None:
        """Create export settings page"""
        frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(frame, text="Export")
        
        # Export format settings
        format_frame = ttk.LabelFrame(frame, text="Export Formats", padding="5")
        format_frame.pack(fill=tk.X, pady=5)
        
        self._settings_vars['export']['image_format'] = tk.StringVar()
        ttk.Label(format_frame, text="Image Format:").pack(anchor='w')
        ttk.OptionMenu(
            format_frame,
            self._settings_vars['export']['image_format'],
            "TIFF",
            "TIFF",
            "PNG",
            "JPEG"
        ).pack(anchor='w')
        
        self._settings_vars['export']['data_format'] = tk.StringVar()
        ttk.Label(format_frame, text="Data Format:").pack(anchor='w')
        ttk.OptionMenu(
            format_frame,
            self._settings_vars['export']['data_format'],
            "CSV",
            "CSV",
            "Excel",
            "JSON"
        ).pack(anchor='w')
    
    def _create_advanced_settings(self) -> None:
        """Create advanced settings page"""
        frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(frame, text="Advanced")
        
        # Performance settings
        perf_frame = ttk.LabelFrame(frame, text="Performance", padding="5")
        perf_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(
            perf_frame,
            text="Cache Size (MB):"
        ).pack(anchor='w')
        
        self._settings_vars['advanced']['cache_size'] = tk.StringVar()
        ttk.Entry(
            perf_frame,
            textvariable=self._settings_vars['advanced']['cache_size'],
            width=10
        ).pack(anchor='w')
        
        # Debug settings
        debug_frame = ttk.LabelFrame(frame, text="Debug", padding="5")
        debug_frame.pack(fill=tk.X, pady=5)
        
        self._settings_vars['advanced']['debug_mode'] = tk.BooleanVar()
        ttk.Checkbutton(
            debug_frame,
            text="Enable debug mode",
            variable=self._settings_vars['advanced']['debug_mode']
        ).pack(anchor='w')
    
    @log_function
    def _load_current_settings(self) -> None:
        """Load current settings into dialog"""
        for category in self._settings_vars:
            settings = config_manager.get_config_value(category, None)
            if settings:
                for key, var in self._settings_vars[category].items():
                    if key in settings:
                        var.set(settings[key])
    
    @log_function
    def _apply_settings(self) -> None:
        """Apply current settings"""
        try:
            # Collect settings from variables
            new_settings = {}
            for category, vars in self._settings_vars.items():
                new_settings[category] = {
                    key: var.get() for key, var in vars.items()
                }
            
            # Update config
            for category, settings in new_settings.items():
                config_manager.set_config_value(category, None, settings)
            
            # Update application state
            state_manager.update_state(settings_updated=True)
            
        except Exception as e:
            logger.log_error(e, {"context": "Applying settings"})
            self._show_error("Error applying settings")
    
    def _save_and_close(self) -> None:
        """Save settings and close dialog"""
        self._apply_settings()
        self.dialog.destroy()
    
    @log_function
    def _reset_to_defaults(self) -> None:
        """Reset settings to defaults"""
        if self._show_confirm("Reset all settings to defaults?"):
            config_manager.reset_to_defaults()
            self._load_current_settings()
    
    def _show_error(self, message: str) -> None:
        """Show error message"""
        tk.messagebox.showerror("Error", message, parent=self.dialog)
    
    def _show_confirm(self, message: str) -> bool:
        """Show confirmation dialog"""
        return tk.messagebox.askyesno("Confirm", message, parent=self.dialog)

# Function to show settings dialog
@log_function
def show_settings_dialog(parent: tk.Tk) -> None:
    """Show settings dialog"""
    SettingsDialog(parent)