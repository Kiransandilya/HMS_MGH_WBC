# tiff_analyzer/ui/toolbar.py

import tkinter as tk
from tkinter import ttk
from typing import Dict, Callable, Optional, Any
from pathlib import Path
from ..utils.logger import logger, log_function
from ..core.state_manager import state_manager, ViewMode, AnalysisMode
from ..utils.config import config_manager

class Toolbar:
    """Application toolbar with all control buttons and tools"""
    
    def __init__(self, parent: ttk.Frame):
        self.parent = parent
        self._buttons: Dict[str, ttk.Button] = {}
        self._tools: Dict[str, ttk.Frame] = {}
        self._current_tool: Optional[str] = None
        self._tooltips: Dict[str, str] = {}
        
        self._create_toolbar()
        self._create_tool_panels()
        self._setup_tooltips()
        self._setup_state_handling()
    
    def _create_toolbar(self) -> None:
        """Create main toolbar buttons and controls"""
        # File operations frame
        file_frame = ttk.LabelFrame(self.parent, text="File")
        file_frame.pack(side=tk.LEFT, padx=5, pady=2, fill=tk.Y)
        
        self._buttons['open1'] = ttk.Button(
            file_frame, text="Open Stack 1", 
            command=lambda: self._trigger_action('open1')
        )
        self._buttons['open2'] = ttk.Button(
            file_frame, text="Open Stack 2",
            command=lambda: self._trigger_action('open2')
        )
        self._buttons['save'] = ttk.Button(
            file_frame, text="Save Analysis",
            command=lambda: self._trigger_action('save')
        )
        
        for btn in ['open1', 'open2', 'save']:
            self._buttons[btn].pack(side=tk.LEFT, padx=2)
        
        # View controls frame
        view_frame = ttk.LabelFrame(self.parent, text="View")
        view_frame.pack(side=tk.LEFT, padx=5, pady=2, fill=tk.Y)
        
        self._create_view_controls(view_frame)
        
        # Tools frame
        tools_frame = ttk.LabelFrame(self.parent, text="Tools")
        tools_frame.pack(side=tk.LEFT, padx=5, pady=2, fill=tk.Y)
        
        self._create_tool_buttons(tools_frame)
        
        # Analysis frame
        analysis_frame = ttk.LabelFrame(self.parent, text="Analysis")
        analysis_frame.pack(side=tk.LEFT, padx=5, pady=2, fill=tk.Y)
        
        self._create_analysis_controls(analysis_frame)
        
        # Settings frame
        settings_frame = ttk.LabelFrame(self.parent, text="Settings")
        settings_frame.pack(side=tk.RIGHT, padx=5, pady=2, fill=tk.Y)
        
        self._create_settings_controls(settings_frame)
    
    def _create_view_controls(self, parent: ttk.Frame) -> None:
        """Create view mode controls"""
        # View mode selection
        self._buttons['side_by_side'] = ttk.Button(
            parent, text="Side by Side",
            command=lambda: self._set_view_mode(ViewMode.SIDE_BY_SIDE)
        )
        self._buttons['overlay'] = ttk.Button(
            parent, text="Overlay",
            command=lambda: self._set_view_mode(ViewMode.OVERLAY)
        )
        self._buttons['top_bottom'] = ttk.Button(
            parent, text="Top/Bottom",
            command=lambda: self._set_view_mode(ViewMode.TOP_BOTTOM)
        )
        
        for btn in ['side_by_side', 'overlay', 'top_bottom']:
            self._buttons[btn].pack(side=tk.LEFT, padx=2)
        
        # Sync views checkbox
        self._sync_var = tk.BooleanVar(value=True)
        self._buttons['sync'] = ttk.Checkbutton(
            parent, text="Sync Views",
            variable=self._sync_var,
            command=self._toggle_sync
        )
        self._buttons['sync'].pack(side=tk.LEFT, padx=2)
    
    def _create_tool_buttons(self, parent: ttk.Frame) -> None:
        """Create tool selection buttons"""
        tools = [
            ('zoom', 'Zoom'),
            ('pan', 'Pan'),
            ('roi_rect', 'Rectangle ROI'),
            ('roi_ellipse', 'Ellipse ROI'),
            ('measure', 'Measure'),
            ('mark', 'Mark Frames')
        ]
        
        for tool_id, text in tools:
            self._buttons[tool_id] = ttk.Button(
                parent, text=text,
                command=lambda t=tool_id: self._select_tool(t)
            )
            self._buttons[tool_id].pack(side=tk.LEFT, padx=2)
    
    def _create_analysis_controls(self, parent: ttk.Frame) -> None:
        """Create analysis controls"""
        analysis_modes = [
            ('feature_extract', 'Extract Features'),
            ('wbc_analysis', 'WBC Analysis'),
            ('compare', 'Compare Stacks')
        ]
        
        for mode_id, text in analysis_modes:
            self._buttons[mode_id] = ttk.Button(
                parent, text=text,
                command=lambda m=mode_id: self._set_analysis_mode(m)
            )
            self._buttons[mode_id].pack(side=tk.LEFT, padx=2)
    
    def _create_settings_controls(self, parent: ttk.Frame) -> None:
        """Create settings controls"""
        # Theme toggle
        self._theme_var = tk.StringVar(value='dark')
        self._buttons['theme'] = ttk.Button(
            parent, text="Toggle Theme",
            command=self._toggle_theme
        )
        self._buttons['theme'].pack(side=tk.LEFT, padx=2)
        
        # Settings button
        self._buttons['settings'] = ttk.Button(
            parent, text="Settings",
            command=self._show_settings
        )
        self._buttons['settings'].pack(side=tk.LEFT, padx=2)
    
    def _create_tool_panels(self) -> None:
        """Create tool-specific control panels"""
        # Create tool panels frame
        self._tool_panels_frame = ttk.Frame(self.parent)
        self._tool_panels_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=5)
        
        # Create individual tool panels
        self._create_zoom_panel()
        self._create_roi_panel()
        self._create_measure_panel()
        self._create_analysis_panel()
    
    def _setup_tooltips(self) -> None:
        """Setup tooltips for buttons"""
        self._tooltips = {
            'open1': "Open first TIFF stack",
            'open2': "Open second TIFF stack",
            'save': "Save analysis results",
            'zoom': "Zoom tool (Z)",
            'pan': "Pan tool (P)",
            'roi_rect': "Rectangle ROI tool (R)",
            'roi_ellipse': "Ellipse ROI tool (E)",
            'measure': "Measurement tool (M)",
            'mark': "Mark frames tool (K)",
            'theme': "Toggle dark/light theme",
            'settings': "Open settings dialog"
        }
        
        for btn_id, tooltip in self._tooltips.items():
            if btn_id in self._buttons:
                self._create_tooltip(self._buttons[btn_id], tooltip)


        # Add these methods to the Toolbar class in toolbar.py
    
    def _create_zoom_panel(self) -> None:
        """Create zoom control panel"""
        panel = ttk.Frame(self._tool_panels_frame)
        self._tools['zoom'] = panel
        
        # Zoom controls
        zoom_frame = ttk.Frame(panel)
        zoom_frame.pack(fill=tk.X, padx=5)
        
        ttk.Label(zoom_frame, text="Zoom Level:").pack(side=tk.LEFT)
        
        zoom_scale = ttk.Scale(
            zoom_frame,
            from_=0.1,
            to=5.0,
            orient=tk.HORIZONTAL,
            length=200,
            command=self._on_zoom_change
        )
        zoom_scale.set(1.0)
        zoom_scale.pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            zoom_frame,
            text="Reset",
            command=self._reset_zoom
        ).pack(side=tk.LEFT)
    
    def _create_roi_panel(self) -> None:
        """Create ROI control panel"""
        panel = ttk.Frame(self._tool_panels_frame)
        self._tools['roi_rect'] = panel
        self._tools['roi_ellipse'] = panel
        
        # ROI controls
        roi_frame = ttk.Frame(panel)
        roi_frame.pack(fill=tk.X, padx=5)
        
        ttk.Button(
            roi_frame,
            text="Clear ROI",
            command=self._clear_roi
        ).pack(side=tk.LEFT)
        
        ttk.Button(
            roi_frame,
            text="Analyze ROI",
            command=self._analyze_roi
        ).pack(side=tk.LEFT, padx=5)
    
    def _create_measure_panel(self) -> None:
        """Create measurement control panel"""
        panel = ttk.Frame(self._tool_panels_frame)
        self._tools['measure'] = panel
        
        # Measurement controls
        measure_frame = ttk.Frame(panel)
        measure_frame.pack(fill=tk.X, padx=5)
        
        ttk.Label(measure_frame, text="Measurement Type:").pack(side=tk.LEFT)
        
        measure_type = ttk.Combobox(
            measure_frame,
            values=["Distance", "Area", "Angle"],
            width=10,
            state="readonly"
        )
        measure_type.set("Distance")
        measure_type.pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            measure_frame,
            text="Clear",
            command=self._clear_measurement
        ).pack(side=tk.LEFT)
    
    def _create_analysis_panel(self) -> None:
        """Create analysis control panel"""
        panel = ttk.Frame(self._tool_panels_frame)
        self._tools['feature_extract'] = panel
        self._tools['wbc_analysis'] = panel
        
        # Analysis controls
        analysis_frame = ttk.Frame(panel)
        analysis_frame.pack(fill=tk.X, padx=5)
        
        ttk.Button(
            analysis_frame,
            text="Start Analysis",
            command=self._start_analysis
        ).pack(side=tk.LEFT)
        
        ttk.Button(
            analysis_frame,
            text="Export Results",
            command=self._export_analysis
        ).pack(side=tk.LEFT, padx=5)

    # Add these callback methods
    def _on_zoom_change(self, value: str) -> None:
        """Handle zoom level change"""
        try:
            zoom_level = float(value)
            state_manager.update_state(zoom_level=zoom_level)
        except ValueError:
            pass
    
    def _reset_zoom(self) -> None:
        """Reset zoom level"""
        state_manager.update_state(zoom_level=1.0)
    
    def _clear_roi(self) -> None:
        """Clear current ROI"""
        state_manager.update_state(roi=None)
    
    def _analyze_roi(self) -> None:
        """Analyze current ROI"""
        state_manager.update_state(action='analyze_roi')
    
    def _clear_measurement(self) -> None:
        """Clear current measurement"""
        state_manager.update_state(measurement=None)
    
    def _start_analysis(self) -> None:
        """Start analysis process"""
        state_manager.update_state(action='start_analysis')
    
    def _export_analysis(self) -> None:
        """Export analysis results"""
        state_manager.update_state(action='export_analysis')
        
    def _create_tooltip(self, widget: tk.Widget, text: str) -> None:
        """Create tooltip for widget"""
        def show_tooltip(event):
            tooltip = tk.Toplevel()
            tooltip.wm_overrideredirect(True)
            tooltip.wm_geometry(f"+{event.x_root+10}+{event.y_root+10}")
            
            label = ttk.Label(tooltip, text=text, relief='solid', padding=2)
            label.pack()
            
            def hide_tooltip():
                tooltip.destroy()
            
            widget.tooltip = tooltip
            widget.after(2000, hide_tooltip)
        
        def hide_tooltip(event):
            if hasattr(widget, 'tooltip'):
                widget.tooltip.destroy()
                del widget.tooltip
        
        widget.bind('<Enter>', show_tooltip)
        widget.bind('<Leave>', hide_tooltip)
    
    @log_function
    def _trigger_action(self, action: str) -> None:
        """Trigger toolbar action"""
        state_manager.update_state(toolbar_action=action)
    
    @log_function
    def _set_view_mode(self, mode: ViewMode) -> None:
        """Set view mode"""
        state_manager.update_state(view_mode=mode)
    
    @log_function
    def _select_tool(self, tool: str) -> None:
        """Select active tool"""
        if self._current_tool == tool:
            self._current_tool = None
        else:
            self._current_tool = tool
        
        # Update tool panels visibility
        self._update_tool_panels()
        
        # Update state
        state_manager.update_state(active_tool=self._current_tool)
    
    def _update_tool_panels(self) -> None:
        """Update visibility of tool panels"""
        for panel_name, panel in self._tools.items():
            if panel_name == self._current_tool:
                panel.pack(side=tk.TOP, fill=tk.X, padx=5, pady=2)
            else:
                panel.pack_forget()
    
    @log_function
    def _toggle_sync(self) -> None:
        """Toggle view synchronization"""
        state_manager.update_state(sync_views=self._sync_var.get())
    
    @log_function
    def _toggle_theme(self) -> None:
        """Toggle application theme"""
        current_theme = self._theme_var.get()
        new_theme = 'light' if current_theme == 'dark' else 'dark'
        self._theme_var.set(new_theme)
        state_manager.update_state(theme=new_theme)
    
    def _show_settings(self) -> None:
        """Show settings dialog"""
        # This will be implemented in settings.py
        pass
    
    def update_state(self, state: Any) -> None:
        """Update toolbar state based on application state"""
        # Update button states
        self._update_button_states(state)
        
        # Update tool selection
        if state.active_tool != self._current_tool:
            self._select_tool(state.active_tool)
    
    def _update_button_states(self, state: Any) -> None:
        """Update button states based on application state"""
        # Update view mode buttons
        for btn in ['side_by_side', 'overlay', 'top_bottom']:
            if btn in self._buttons:
                self._buttons[btn].state(['!pressed'])
        
        if state.view_mode == ViewMode.SIDE_BY_SIDE:
            self._buttons['side_by_side'].state(['pressed'])
        elif state.view_mode == ViewMode.OVERLAY:
            self._buttons['overlay'].state(['pressed'])
        elif state.view_mode == ViewMode.TOP_BOTTOM:
            self._buttons['top_bottom'].state(['pressed'])
        
        # Update sync button
        self._sync_var.set(state.sync_views)
        
        # Update theme button
        self._theme_var.set(state.theme)

# Example usage
if __name__ == "__main__":
    root = tk.Tk()
    frame = ttk.Frame(root)
    frame.pack(fill=tk.BOTH, expand=True)
    toolbar = Toolbar(frame)
    root.mainloop()