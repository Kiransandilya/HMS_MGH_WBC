# tiff_analyzer/ui/controls.py

import tkinter as tk
from tkinter import ttk
from typing import Dict, Optional, Any, Callable
from ..utils.logger import logger, log_function
from ..core.state_manager import state_manager, PlaybackState
from ..core.animation import animation_manager
from ..utils.config import config_manager

class Controls:
    """Playback and analysis controls panel"""
    
    def __init__(self, parent: ttk.Frame):
        self.parent = parent
        self._controls: Dict[str, tk.Widget] = {}
        self._play_state = PlaybackState.STOPPED
        
        self._create_layout()
        self._setup_state_handling()
        self._setup_keyboard_shortcuts()
    
    def _create_layout(self) -> None:
        """Create controls layout"""
        # Main controls container with grid layout
        self.controls_frame = ttk.Frame(self.parent)
        self.controls_frame.pack(fill=tk.X, padx=5, pady=2)
        
        # Create control sections
        self._create_playback_controls()
        self._create_frame_controls()
        self._create_view_controls()
        self._create_marking_controls()
    
    def _create_playback_controls(self) -> None:
        """Create playback control buttons"""
        playback_frame = ttk.LabelFrame(self.controls_frame, text="Playback")
        playback_frame.pack(side=tk.LEFT, padx=5, fill=tk.Y)
        
        # Play/Pause button
        self._controls['play'] = ttk.Button(
            playback_frame,
            text="Play",
            command=self._toggle_playback,
            width=8
        )
        self._controls['play'].pack(side=tk.LEFT, padx=2)
        
        # Stop button
        self._controls['stop'] = ttk.Button(
            playback_frame,
            text="Stop",
            command=self._stop_playback,
            width=8
        )
        self._controls['stop'].pack(side=tk.LEFT, padx=2)
        
        # FPS control
        fps_frame = ttk.Frame(playback_frame)
        fps_frame.pack(side=tk.LEFT, padx=5)
        
        ttk.Label(fps_frame, text="FPS:").pack(side=tk.LEFT)
        
        self._fps_var = tk.StringVar(value="10")
        self._controls['fps'] = ttk.Spinbox(
            fps_frame,
            from_=1,
            to=60,
            width=5,
            textvariable=self._fps_var,
            command=self._update_fps
        )
        self._controls['fps'].pack(side=tk.LEFT, padx=2)
        
        # Loop playback checkbox
        self._loop_var = tk.BooleanVar(value=True)
        self._controls['loop'] = ttk.Checkbutton(
            playback_frame,
            text="Loop",
            variable=self._loop_var,
            command=self._toggle_loop
        )
        self._controls['loop'].pack(side=tk.LEFT, padx=5)
    
    def _create_frame_controls(self) -> None:
        """Create frame navigation controls"""
        frame_frame = ttk.LabelFrame(self.controls_frame, text="Frame")
        frame_frame.pack(side=tk.LEFT, padx=5, fill=tk.Y)
        
        # Frame slider
        self._frame_var = tk.IntVar(value=0)
        self._controls['frame_slider'] = ttk.Scale(
            frame_frame,
            from_=0,
            to=100,
            orient=tk.HORIZONTAL,
            variable=self._frame_var,
            command=self._on_frame_change,
            length=200
        )
        self._controls['frame_slider'].pack(side=tk.LEFT, padx=5)
        
        # Frame entry
        frame_entry_frame = ttk.Frame(frame_frame)
        frame_entry_frame.pack(side=tk.LEFT, padx=5)
        
        self._frame_entry_var = tk.StringVar(value="0")
        self._controls['frame_entry'] = ttk.Entry(
            frame_entry_frame,
            textvariable=self._frame_entry_var,
            width=6
        )
        self._controls['frame_entry'].pack(side=tk.LEFT)
        ttk.Label(frame_entry_frame, text="/0").pack(side=tk.LEFT)
        
        # Frame navigation buttons
        nav_frame = ttk.Frame(frame_frame)
        nav_frame.pack(side=tk.LEFT, padx=5)
        
        self._controls['prev_frame'] = ttk.Button(
            nav_frame,
            text="◀",
            command=self._previous_frame,
            width=3
        )
        self._controls['prev_frame'].pack(side=tk.LEFT, padx=1)
        
        self._controls['next_frame'] = ttk.Button(
            nav_frame,
            text="▶",
            command=self._next_frame,
            width=3
        )
        self._controls['next_frame'].pack(side=tk.LEFT, padx=1)
    
    def _create_view_controls(self) -> None:
        """Create view adjustment controls"""
        view_frame = ttk.LabelFrame(self.controls_frame, text="View")
        view_frame.pack(side=tk.LEFT, padx=5, fill=tk.Y)
        
        # Overlay opacity control (when in overlay mode)
        opacity_frame = ttk.Frame(view_frame)
        opacity_frame.pack(side=tk.LEFT, padx=5)
        
        ttk.Label(opacity_frame, text="Opacity:").pack(side=tk.LEFT)
        
        self._opacity_var = tk.DoubleVar(value=0.5)
        self._controls['opacity'] = ttk.Scale(
            opacity_frame,
            from_=0,
            to=1,
            orient=tk.HORIZONTAL,
            variable=self._opacity_var,
            command=self._update_opacity,
            length=100
        )
        self._controls['opacity'].pack(side=tk.LEFT)
        
        # Contrast controls
        contrast_frame = ttk.Frame(view_frame)
        contrast_frame.pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            contrast_frame,
            text="Auto Contrast",
            command=self._auto_contrast
        ).pack(side=tk.LEFT)
        
        ttk.Button(
            contrast_frame,
            text="Reset View",
            command=self._reset_view
        ).pack(side=tk.LEFT, padx=5)
    
    def _create_marking_controls(self) -> None:
        """Create frame marking controls"""
        marking_frame = ttk.LabelFrame(self.controls_frame, text="Marking")
        marking_frame.pack(side=tk.LEFT, padx=5, fill=tk.Y)
        
        # Mark current frame button
        self._controls['mark'] = ttk.Button(
            marking_frame,
            text="Mark Frame (M)",
            command=self._mark_frame
        )
        self._controls['mark'].pack(side=tk.LEFT, padx=2)
        
        # Navigate marked frames
        nav_marked_frame = ttk.Frame(marking_frame)
        nav_marked_frame.pack(side=tk.LEFT, padx=5)
        
        self._controls['prev_marked'] = ttk.Button(
            nav_marked_frame,
            text="◀ Marked",
            command=lambda: self._navigate_marked('prev'),
            width=8
        )
        self._controls['prev_marked'].pack(side=tk.LEFT, padx=1)
        
        self._controls['next_marked'] = ttk.Button(
            nav_marked_frame,
            text="Marked ▶",
            command=lambda: self._navigate_marked('next'),
            width=8
        )
        self._controls['next_marked'].pack(side=tk.LEFT, padx=1)
        
        # Export marked frames button
        self._controls['export_marked'] = ttk.Button(
            marking_frame,
            text="Export Marked",
            command=self._export_marked_frames
        )
        self._controls['export_marked'].pack(side=tk.LEFT, padx=5)
    
    def _setup_state_handling(self) -> None:
        """Setup state change handlers"""
        state_manager.add_observer('controls', self._handle_state_change)
    
    def _setup_keyboard_shortcuts(self) -> None:
        """Setup keyboard shortcuts"""
        self.parent.bind('<space>', lambda e: self._toggle_playback())
        self.parent.bind('<Left>', lambda e: self._previous_frame())
        self.parent.bind('<Right>', lambda e: self._next_frame())
        self.parent.bind('m', lambda e: self._mark_frame())
    
    @log_function
    def _toggle_playback(self) -> None:
        """Toggle playback state"""
        if self._play_state == PlaybackState.PLAYING:
            animation_manager.pause_playback()
            self._controls['play'].configure(text="Play")
            self._play_state = PlaybackState.PAUSED
        else:
            animation_manager.start_playback()
            self._controls['play'].configure(text="Pause")
            self._play_state = PlaybackState.PLAYING
    
    @log_function
    def _stop_playback(self) -> None:
        """Stop playback"""
        animation_manager.stop_playback()
        self._controls['play'].configure(text="Play")
        self._play_state = PlaybackState.STOPPED
    
    @log_function
    def _update_fps(self) -> None:
        """Update playback FPS"""
        try:
            fps = float(self._fps_var.get())
            fps = max(1, min(fps, 60))  # Limit between 1-60
            animation_manager.fps = fps
        except ValueError:
            self._fps_var.set("10")  # Reset to default if invalid
    
    @log_function
    def _toggle_loop(self) -> None:
        """Toggle loop playback"""
        animation_manager.set_loop_playback(self._loop_var.get())
    
    @log_function
    def _on_frame_change(self, value: str) -> None:
        """Handle frame slider change"""
        try:
            frame = int(float(value))
            self._frame_entry_var.set(str(frame))
            if self._play_state != PlaybackState.PLAYING:
                animation_manager.seek_to_frame(frame)
        except ValueError:
            pass
    
    @log_function
    def _previous_frame(self) -> None:
        """Go to previous frame"""
        if self._play_state == PlaybackState.PLAYING:
            self._toggle_playback()
        animation_manager.previous_frame()
    
    @log_function
    def _next_frame(self) -> None:
        """Go to next frame"""
        if self._play_state == PlaybackState.PLAYING:
            self._toggle_playback()
        animation_manager.next_frame()
    
    @log_function
    def _mark_frame(self) -> None:
        """Mark current frame"""
        animation_manager.mark_frame()
        self._update_marking_buttons()
    
    def _update_marking_buttons(self) -> None:
        """Update marking navigation buttons state"""
        marked_frames = animation_manager.get_marked_frames()
        current_frame = self._frame_var.get()
        
        # Enable/disable navigation buttons based on marked frames
        has_prev = any(f < current_frame for f in marked_frames)
        has_next = any(f > current_frame for f in marked_frames)
        
        self._controls['prev_marked'].state(
            ['!disabled'] if has_prev else ['disabled']
        )
        self._controls['next_marked'].state(
            ['!disabled'] if has_next else ['disabled']
        )
    
    @log_function
    def _navigate_marked(self, direction: str) -> None:
        """Navigate to next/previous marked frame"""
        animation_manager.jump_to_marked_frame(direction)
    
    @log_function
    def _export_marked_frames(self) -> None:
        """Export marked frames"""
        marked_frames = animation_manager.get_marked_frames()
        if not marked_frames:
            return
            
        from tkinter import filedialog
        export_path = filedialog.askdirectory(
            title="Select Export Directory"
        )
        if export_path:
            state_manager.update_state(
                action="export_marked",
                frames=marked_frames,
                path=export_path
            )
    
    @log_function
    def _update_opacity(self, *args) -> None:
        """Update overlay opacity"""
        opacity = self._opacity_var.get()
        state_manager.update_state(overlay_opacity=opacity)
    
    @log_function
    def _auto_contrast(self) -> None:
        """Apply auto contrast"""
        state_manager.update_state(action="auto_contrast")
    
    @log_function
    def _reset_view(self) -> None:
        """Reset view to default"""
        state_manager.update_state(action="reset_view")
    
    def _handle_state_change(self, state: Any) -> None:
        """Handle application state changes"""
        # Update frame range
        if hasattr(state, 'total_frames'):
            max_frames = max(0, state.total_frames - 1)
            self._controls['frame_slider'].configure(to=max_frames)
            self._frame_entry_var.set(str(state.current_frame))
        
        # Update playback state
        if hasattr(state, 'playback_state'):
            if state.playback_state != self._play_state:
                self._play_state = state.playback_state
                self._controls['play'].configure(
                    text="Pause" if self._play_state == PlaybackState.PLAYING else "Play"
                )
        
        # Update marking buttons
        self._update_marking_buttons()
        
        # Update opacity control visibility
        if hasattr(state, 'view_mode'):
            if state.view_mode == ViewMode.OVERLAY:
                self._controls['opacity'].pack(side=tk.LEFT)
            else:
                self._controls['opacity'].pack_forget()
    
    def get_state(self) -> Dict[str, Any]:
        """Get current controls state"""
        return {
            'fps': self._fps_var.get(),
            'loop': self._loop_var.get(),
            'frame': self._frame_var.get(),
            'opacity': self._opacity_var.get()
        }
    
    def restore_state(self, state: Dict[str, Any]) -> None:
        """Restore controls state"""
        if 'fps' in state:
            self._fps_var.set(state['fps'])
        if 'loop' in state:
            self._loop_var.set(state['loop'])
        if 'frame' in state:
            self._frame_var.set(state['frame'])
        if 'opacity' in state:
            self._opacity_var.set(state['opacity'])

# Create test window if run directly
if __name__ == "__main__":
    root = tk.Tk()
    frame = ttk.Frame(root)
    frame.pack(fill=tk.BOTH, expand=True)
    controls = Controls(frame)
    root.mainloop()