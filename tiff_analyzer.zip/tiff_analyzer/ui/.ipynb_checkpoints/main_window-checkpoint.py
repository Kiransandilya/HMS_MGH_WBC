# tiff_analyzer/ui/main_window.py

import tkinter as tk
from tkinter import ttk
import platform
from typing import Optional, Dict, Any
from ..utils.logger import logger, log_function
from ..utils.config import config_manager
from ..core.state_manager import state_manager, ViewMode

class MainWindow:
    """Main application window with layout management"""
    
    def __init__(self, root: tk.Tk):
        self.root = root
        self._frames: Dict[str, ttk.Frame] = {}
        self._configure_root()
        self._create_layout()
        self._setup_state_handling()
        
    def _configure_root(self) -> None:
        """Configure root window properties"""
        # Get screen dimensions
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        
        # Set default window size (80% of screen)
        width = int(screen_width * 0.8)
        height = int(screen_height * 0.8)
        x = (screen_width - width) // 2
        y = (screen_height - height) // 2
        
        # Configure window
        self.root.geometry(f"{width}x{height}+{x}+{y}")
        self.root.minsize(800, 600)
        
        # Platform-specific configurations
        if platform.system() == "Windows":
            self.root.state('zoomed')  # Start maximized on Windows
        elif platform.system() == "Darwin":  # macOS
            self.root.createcommand('tk::mac::ReopenApplication', self.root.lift)
            
        # Configure grid weights
        self.root.grid_columnconfigure(0, weight=1)
        self.root.grid_rowconfigure(1, weight=1)
    
    def _create_layout(self) -> None:
        """Create main window layout"""
        # Create frames
        self._create_toolbar_frame()
        self._create_main_frame()
        self._create_controls_frame()
        self._create_status_frame()
        
        # Configure main frame for view modes
        self._setup_view_modes()
    
    def _create_toolbar_frame(self) -> None:
        """Create toolbar frame"""
        self._frames['toolbar'] = ttk.Frame(self.root)
        self._frames['toolbar'].grid(row=0, column=0, sticky="ew", padx=5, pady=2)
    
    def _create_main_frame(self) -> None:
        """Create main content frame"""
        self._frames['main'] = ttk.Frame(self.root)
        self._frames['main'].grid(row=1, column=0, sticky="nsew", padx=5)
        
        # Configure grid weights
        self._frames['main'].grid_columnconfigure(0, weight=1)
        self._frames['main'].grid_rowconfigure(0, weight=1)
        
        # Create view frames
        self._frames['side_by_side'] = ttk.Frame(self._frames['main'])
        self._frames['overlay'] = ttk.Frame(self._frames['main'])
        self._frames['top_bottom'] = ttk.Frame(self._frames['main'])
        
        # Configure view frames
        for frame in ['side_by_side', 'overlay', 'top_bottom']:
            self._frames[frame].grid(row=0, column=0, sticky="nsew")
            self._frames[frame].grid_columnconfigure(0, weight=1)
            self._frames[frame].grid_rowconfigure(0, weight=1)
    
    def _create_controls_frame(self) -> None:
        """Create controls frame"""
        self._frames['controls'] = ttk.Frame(self.root)
        self._frames['controls'].grid(row=2, column=0, sticky="ew", padx=5, pady=2)
    
    def _create_status_frame(self) -> None:
        """Create status bar frame"""
        self._frames['status'] = ttk.Frame(self.root)
        self._frames['status'].grid(row=3, column=0, sticky="ew", padx=5, pady=2)
        
        # Create status labels
        self._status_labels = {
            'state': ttk.Label(self._frames['status'], text="Ready"),
            'frame': ttk.Label(self._frames['status'], text="Frame: 0/0"),
            'zoom': ttk.Label(self._frames['status'], text="Zoom: 100%"),
            'memory': ttk.Label(self._frames['status'], text="Memory: 0 MB")
        }
        
        # Pack status labels
        for i, label in enumerate(self._status_labels.values()):
            label.pack(side=tk.LEFT, padx=10)
    
    def _setup_view_modes(self) -> None:
        """Setup different view mode layouts"""
        # Side by side layout
        self._frames['left_view'] = ttk.Frame(self._frames['side_by_side'])
        self._frames['right_view'] = ttk.Frame(self._frames['side_by_side'])
        self._frames['left_view'].grid(row=0, column=0, sticky="nsew", padx=(0, 2))
        self._frames['right_view'].grid(row=0, column=1, sticky="nsew", padx=(2, 0))
        self._frames['side_by_side'].grid_columnconfigure(0, weight=1)
        self._frames['side_by_side'].grid_columnconfigure(1, weight=1)
        
        # Top bottom layout
        self._frames['top_view'] = ttk.Frame(self._frames['top_bottom'])
        self._frames['bottom_view'] = ttk.Frame(self._frames['top_bottom'])
        self._frames['top_view'].grid(row=0, column=0, sticky="nsew", pady=(0, 2))
        self._frames['bottom_view'].grid(row=1, column=0, sticky="nsew", pady=(2, 0))
        self._frames['top_bottom'].grid_rowconfigure(0, weight=1)
        self._frames['top_bottom'].grid_rowconfigure(1, weight=1)
        
        # Overlay layout
        self._frames['overlay_view'] = ttk.Frame(self._frames['overlay'])
        self._frames['overlay_view'].grid(row=0, column=0, sticky="nsew")
    
    def _setup_state_handling(self) -> None:
        """Setup state change handlers"""
        state_manager.add_observer('main_window', self._handle_state_change)
    
    @log_function
    def _handle_state_change(self, state: Any) -> None:
        """Handle application state changes"""
        # Update view mode
        self.set_view_mode(state.view_mode)
        
        # Update status bar
        self._update_status_bar(state)
    
    @log_function
    def set_view_mode(self, mode: ViewMode) -> None:
        """Switch between view modes"""
        # Hide all view frames
        for frame in ['side_by_side', 'overlay', 'top_bottom']:
            self._frames[frame].grid_remove()
        
        # Show selected view frame
        if mode == ViewMode.SIDE_BY_SIDE:
            self._frames['side_by_side'].grid()
        elif mode == ViewMode.OVERLAY:
            self._frames['overlay'].grid()
        elif mode == ViewMode.TOP_BOTTOM:
            self._frames['top_bottom'].grid()
    
    def _update_status_bar(self, state: Any) -> None:
        """Update status bar information"""
        # Update frame counter
        self._status_labels['frame'].config(
            text=f"Frame: {state.current_frame + 1}/{state.total_frames}"
        )
        
        # Update zoom level
        zoom_level = state.zoom_level.get(state.active_stack, 1.0)
        self._status_labels['zoom'].config(
            text=f"Zoom: {zoom_level:.0%}"
        )
    
    @property
    def toolbar_frame(self) -> ttk.Frame:
        """Get toolbar frame"""
        return self._frames['toolbar']
    
    @property
    def controls_frame(self) -> ttk.Frame:
        """Get controls frame"""
        return self._frames['controls']
    
    @property
    def main_frame(self) -> ttk.Frame:
        """Get main content frame"""
        return self._frames['main']
    
    def get_view_frame(self, name: str) -> Optional[ttk.Frame]:
        """Get specific view frame"""
        return self._frames.get(name)
    
    @log_function
    def get_state(self) -> Dict[str, Any]:
        """Get current window state"""
        return {
            'geometry': self.root.geometry(),
            'state': self.root.state(),
            'view_mode': state_manager.get_state().view_mode
        }
    
    @log_function
    def restore_state(self, state: Dict[str, Any]) -> None:
        """Restore window state"""
        if 'geometry' in state:
            self.root.geometry(state['geometry'])
        if 'state' in state:
            self.root.state(state['state'])
        if 'view_mode' in state:
            self.set_view_mode(state['view_mode'])

# Example usage
if __name__ == "__main__":
    root = tk.Tk()
    main_window = MainWindow(root)
    root.mainloop()