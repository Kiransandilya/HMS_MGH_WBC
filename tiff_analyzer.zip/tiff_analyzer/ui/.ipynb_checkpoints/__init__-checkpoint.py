# tiff_analyzer/ui/__init__.py

import tkinter as tk
from typing import Optional, Dict, Any
from ..utils.logger import logger, log_function
from ..utils.config import config_manager
from ..core import core_manager

class UIManager:
    """Manages all UI components and their initialization"""
    
    def __init__(self):
        self._initialized = False
        self._root: Optional[tk.Tk] = None
        self._components: Dict[str, Any] = {}
        self._current_theme = config_manager.get_config_value('view', 'theme')
    
    @log_function
    def initialize(self, root: Optional[tk.Tk] = None) -> bool:
        """Initialize UI components"""
        try:
            if self._initialized:
                return True
            
            # Ensure core components are initialized
            if not core_manager._initialized:
                core_manager.initialize()
            
            # Create or use provided root window
            self._root = root if root is not None else tk.Tk()
            self._root.title("TIFF Stack Analyzer")
            
            # Initialize UI components
            self._init_components()
            
            # Set up event bindings
            self._setup_bindings()
            
            # Apply initial theme
            self.apply_theme(self._current_theme)
            
            self._initialized = True
            return True
            
        except Exception as e:
            logger.log_error(e, {"context": "UI initialization"})
            return False
    
    @log_function
    def _init_components(self) -> None:
        """Initialize individual UI components"""
        from .main_window import MainWindow
        from .toolbar import Toolbar
        from .controls import Controls
        
        # Create main window
        self._components['main_window'] = MainWindow(self._root)
        
        # Create toolbar
        self._components['toolbar'] = Toolbar(
            self._components['main_window'].toolbar_frame
        )
        
        # Create controls
        self._components['controls'] = Controls(
            self._components['main_window'].controls_frame
        )
    
    def _setup_bindings(self) -> None:
        """Set up event bindings"""
        from .shortcuts import setup_shortcuts
        
        # Set up keyboard shortcuts
        setup_shortcuts(self._root)
        
        # Window close handling
        self._root.protocol("WM_DELETE_WINDOW", self.shutdown)
    
    @log_function
    def apply_theme(self, theme_name: str) -> None:
        """Apply theme to all UI components"""
        try:
            from .themes import apply_theme
            
            apply_theme(self._root, theme_name)
            self._current_theme = theme_name
            
            # Update all components
            for component in self._components.values():
                if hasattr(component, 'update_theme'):
                    component.update_theme(theme_name)
                    
        except Exception as e:
            logger.log_error(e, {"context": "Theme application"})
    
    @log_function
    def shutdown(self) -> None:
        """Shutdown UI components"""
        try:
            # Save UI state if configured
            if config_manager.get_config_value('ui', 'save_state'):
                self._save_ui_state()
            
            # Shutdown core components
            core_manager.shutdown()
            
            # Destroy root window
            if self._root:
                self._root.destroy()
                
            self._initialized = False
            
        except Exception as e:
            logger.log_error(e, {"context": "UI shutdown"})
            raise
    
    def _save_ui_state(self) -> None:
        """Save UI state"""
        ui_state = {
            'theme': self._current_theme,
            'window_geometry': self._root.geometry(),
            'components': {}
        }
        
        # Collect state from components
        for name, component in self._components.items():
            if hasattr(component, 'get_state'):
                ui_state['components'][name] = component.get_state()
        
        config_manager.set_config_value('ui', 'saved_state', ui_state)
    
    def get_component(self, name: str) -> Optional[Any]:
        """Get UI component by name"""
        return self._components.get(name)
    
    @property
    def root(self) -> Optional[tk.Tk]:
        """Get root window"""
        return self._root

# Create global UI manager instance
ui_manager = UIManager()

# Export components
__all__ = ['ui_manager']