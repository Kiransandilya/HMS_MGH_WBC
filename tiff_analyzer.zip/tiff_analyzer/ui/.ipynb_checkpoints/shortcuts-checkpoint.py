# tiff_analyzer/ui/shortcuts.py

import tkinter as tk
from typing import Dict, Callable, Optional, Any
from ..utils.logger import logger, log_function
from ..core.state_manager import state_manager
from ..core.animation import animation_manager
from ..utils.config import config_manager

class ShortcutManager:
    """Manages application keyboard shortcuts and hotkeys"""
    
    def __init__(self):
        self._shortcuts: Dict[str, Dict[str, Any]] = {}
        self._active = True
        self._modifier_keys = {
            'Control': False,
            'Alt': False,
            'Shift': False
        }
        self._load_shortcuts()
    
    def _load_shortcuts(self) -> None:
        """Load default shortcuts and any custom configurations"""
        # Default shortcuts configuration
        self._shortcuts = {
            # Playback controls
            'space': {
                'action': 'toggle_playback',
                'description': 'Play/Pause',
                'category': 'Playback'
            },
            'Left': {
                'action': 'previous_frame',
                'description': 'Previous frame',
                'category': 'Navigation'
            },
            'Right': {
                'action': 'next_frame',
                'description': 'Previous frame',
                'category': 'Navigation'
            },
            
            # Frame marking
            'm': {
                'action': 'mark_frame',
                'description': 'Mark current frame',
                'category': 'Marking'
            },
            'Control-m': {
                'action': 'start_continuous_marking',
                'description': 'Start continuous marking',
                'category': 'Marking'
            },
            
            # Navigation
            'Control-Left': {
                'action': 'previous_marked_frame',
                'description': 'Go to previous marked frame',
                'category': 'Navigation'
            },
            'Control-Right': {
                'action': 'next_marked_frame',
                'description': 'Go to next marked frame',
                'category': 'Navigation'
            },
            
            # Tools
            'z': {
                'action': 'activate_zoom',
                'description': 'Activate zoom tool',
                'category': 'Tools'
            },
            'p': {
                'action': 'activate_pan',
                'description': 'Activate pan tool',
                'category': 'Tools'
            },
            'r': {
                'action': 'activate_roi',
                'description': 'Activate ROI tool',
                'category': 'Tools'
            },
            
            # View controls
            'f': {
                'action': 'toggle_fullscreen',
                'description': 'Toggle fullscreen',
                'category': 'View'
            },
            'Control-0': {
                'action': 'reset_zoom',
                'description': 'Reset zoom',
                'category': 'View'
            },
            'Control-r': {
                'action': 'reset_view',
                'description': 'Reset view',
                'category': 'View'
            },
            
            # File operations
            'Control-s': {
                'action': 'save_analysis',
                'description': 'Save analysis',
                'category': 'File'
            },
            'Control-o': {
                'action': 'open_stack',
                'description': 'Open stack',
                'category': 'File'
            },
            
            # Application controls
            'Control-q': {
                'action': 'quit_application',
                'description': 'Quit application',
                'category': 'Application'
            },
            'F1': {
                'action': 'show_help',
                'description': 'Show help',
                'category': 'Help'
            }
        }
        
        # Load custom shortcuts from config
        custom_shortcuts = config_manager.get_config_value('shortcuts', 'custom')
        if custom_shortcuts:
            self._shortcuts.update(custom_shortcuts)
    
    @log_function
    def bind_shortcuts(self, root: tk.Tk) -> None:
        """Bind all shortcuts to root window"""
        for shortcut, info in self._shortcuts.items():
            root.bind(f'<{shortcut}>', lambda e, a=info['action']: self._handle_shortcut(e, a))
        
        # Bind modifier key events
        root.bind('<KeyPress>', self._on_key_press)
        root.bind('<KeyRelease>', self._on_key_release)
    
    def _on_key_press(self, event: tk.Event) -> None:
        """Handle modifier key press"""
        if event.keysym in self._modifier_keys:
            self._modifier_keys[event.keysym] = True
    
    def _on_key_release(self, event: tk.Event) -> None:
        """Handle modifier key release"""
        if event.keysym in self._modifier_keys:
            self._modifier_keys[event.keysym] = False
            
        # Handle continuous marking release
        if event.keysym == 'm' and self._modifier_keys['Control']:
            self._handle_shortcut(event, 'stop_continuous_marking')
    
    @log_function
    def _handle_shortcut(self, event: tk.Event, action: str) -> None:
        """Handle shortcut action"""
        if not self._active:
            return
            
        try:
            if action == 'toggle_playback':
                state_manager.update_state(action='toggle_playback')
            
            elif action == 'previous_frame':
                animation_manager.previous_frame()
            
            elif action == 'next_frame':
                animation_manager.next_frame()
            
            elif action == 'mark_frame':
                animation_manager.mark_frame()
            
            elif action == 'start_continuous_marking':
                animation_manager.start_continuous_marking()
            
            elif action == 'stop_continuous_marking':
                animation_manager.stop_continuous_marking()
            
            elif action == 'previous_marked_frame':
                animation_manager.jump_to_marked_frame('prev')
            
            elif action == 'next_marked_frame':
                animation_manager.jump_to_marked_frame('next')
            
            elif action.startswith('activate_'):
                tool = action.split('_')[1]
                state_manager.update_state(active_tool=tool)
            
            elif action == 'toggle_fullscreen':
                self._toggle_fullscreen(event.widget.winfo_toplevel())
            
            elif action == 'reset_zoom':
                state_manager.update_state(action='reset_zoom')
            
            elif action == 'reset_view':
                state_manager.update_state(action='reset_view')
            
            elif action == 'save_analysis':
                state_manager.update_state(action='save_analysis')
            
            elif action == 'open_stack':
                state_manager.update_state(action='open_stack')
            
            elif action == 'quit_application':
                state_manager.update_state(action='quit')
            
            elif action == 'show_help':
                self.show_shortcuts_help()
                
        except Exception as e:
            logger.log_error(e, {
                "context": f"Handling shortcut action '{action}'",
                "event": str(event)
            })
    
    def _toggle_fullscreen(self, window: tk.Tk) -> None:
        """Toggle fullscreen state"""
        state = window.attributes('-fullscreen')
        window.attributes('-fullscreen', not state)
    
    @log_function
    def show_shortcuts_help(self) -> None:
        """Show shortcuts help dialog"""
        help_window = tk.Toplevel()
        help_window.title("Keyboard Shortcuts")
        help_window.geometry("600x400")
        
        # Create categories
        categories = {}
        for shortcut, info in self._shortcuts.items():
            category = info['category']
            if category not in categories:
                categories[category] = []
            categories[category].append((shortcut, info['description']))
        
        # Create notebook for categories
        notebook = ttk.Notebook(help_window)
        notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Create page for each category
        for category, shortcuts in categories.items():
            frame = ttk.Frame(notebook)
            notebook.add(frame, text=category)
            
            # Add shortcuts to frame
            for i, (shortcut, description) in enumerate(shortcuts):
                ttk.Label(frame, text=shortcut).grid(row=i, column=0, padx=5, pady=2, sticky='w')
                ttk.Label(frame, text=description).grid(row=i, column=1, padx=5, pady=2, sticky='w')
    
    @log_function
    def register_custom_shortcut(self, shortcut: str, action: str, 
                               description: str, category: str) -> bool:
        """Register a custom shortcut"""
        try:
            self._shortcuts[shortcut] = {
                'action': action,
                'description': description,
                'category': category
            }
            self._save_custom_shortcuts()
            return True
        except Exception as e:
            logger.log_error(e, {"context": f"Registering custom shortcut '{shortcut}'"})
            return False
    
    def _save_custom_shortcuts(self) -> None:
        """Save custom shortcuts to config"""
        custom_shortcuts = {
            k: v for k, v in self._shortcuts.items()
            if k not in self._get_default_shortcuts()
        }
        config_manager.set_config_value('shortcuts', 'custom', custom_shortcuts)
    
    def _get_default_shortcuts(self) -> Dict[str, Dict[str, Any]]:
        """Get default shortcuts"""
        # Implementation would return the default shortcuts dictionary
        pass
    
    def enable(self) -> None:
        """Enable shortcuts"""
        self._active = True
    
    def disable(self) -> None:
        """Disable shortcuts"""
        self._active = False
    
    def get_shortcuts(self) -> Dict[str, Dict[str, Any]]:
        """Get all registered shortcuts"""
        return self._shortcuts.copy()

# Create global shortcut manager instance
shortcut_manager = ShortcutManager()

# Function to setup shortcuts for root window
def setup_shortcuts(root: tk.Tk) -> None:
    """Setup shortcuts for application"""
    shortcut_manager.bind_shortcuts(root)