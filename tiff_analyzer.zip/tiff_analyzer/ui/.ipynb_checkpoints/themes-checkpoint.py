# tiff_analyzer/ui/themes.py

import tkinter as tk
from tkinter import ttk
from typing import Dict, Any, Optional
from ..utils.logger import logger, log_function
from ..utils.config import config_manager

class ThemeManager:
    """Manages application themes and styling"""
    
    # Define theme colors
    THEMES = {
        'dark': {
            'bg': '#2b2b2b',
            'fg': '#ffffff',
            'button_bg': '#3d3d3d',
            'button_fg': '#ffffff',
            'accent': '#007acc',
            'success': '#28a745',
            'warning': '#ffc107',
            'error': '#dc3545',
            'frame_bg': '#363636',
            'entry_bg': '#404040',
            'entry_fg': '#ffffff',
            'disabled_bg': '#404040',
            'disabled_fg': '#808080',
            'slider_bg': '#505050',
            'slider_fg': '#007acc',
            'selected_bg': '#007acc',
            'selected_fg': '#ffffff',
            'plot_bg': '#2b2b2b',
            'plot_fg': '#ffffff',
            'grid_color': '#404040'
        },
        'light': {
            'bg': '#ffffff',
            'fg': '#000000',
            'button_bg': '#f0f0f0',
            'button_fg': '#000000',
            'accent': '#007acc',
            'success': '#28a745',
            'warning': '#ffc107',
            'error': '#dc3545',
            'frame_bg': '#f5f5f5',
            'entry_bg': '#ffffff',
            'entry_fg': '#000000',
            'disabled_bg': '#e0e0e0',
            'disabled_fg': '#808080',
            'slider_bg': '#d0d0d0',
            'slider_fg': '#007acc',
            'selected_bg': '#007acc',
            'selected_fg': '#ffffff',
            'plot_bg': '#ffffff',
            'plot_fg': '#000000',
            'grid_color': '#e0e0e0'
        }
    }
    
    def __init__(self):
        self._current_theme = 'dark'
        self._custom_themes: Dict[str, Dict[str, str]] = {}
        self._style = ttk.Style()
        self._load_custom_themes()
    
    @log_function
    def initialize(self) -> None:
        """Initialize theme system"""
        # Load saved theme preference
        saved_theme = config_manager.get_config_value('view', 'theme')
        if saved_theme in self.get_available_themes():
            self._current_theme = saved_theme
        
        # Apply initial theme
        self.apply_theme(self._current_theme)
    
    @log_function
    def apply_theme(self, theme_name: str) -> bool:
        """Apply specified theme to application"""
        if theme_name not in self.get_available_themes():
            logger.logger.error(f"Theme '{theme_name}' not found")
            return False
        
        try:
            # Get theme colors
            colors = self._get_theme_colors(theme_name)
            
            # Configure ttk styles
            self._configure_ttk_styles(colors)
            
            # Configure root window
            self._configure_root_window(colors)
            
            # Update current theme
            self._current_theme = theme_name
            config_manager.set_config_value('view', 'theme', theme_name)
            
            return True
            
        except Exception as e:
            logger.log_error(e, {"context": f"Applying theme '{theme_name}'"})
            return False
    
    def _configure_ttk_styles(self, colors: Dict[str, str]) -> None:
        """Configure ttk widget styles"""
        style = self._style
        
        # Configure common elements
        style.configure('.',
            background=colors['bg'],
            foreground=colors['fg'],
            fieldbackground=colors['entry_bg'],
            troughcolor=colors['slider_bg'],
            selectbackground=colors['selected_bg'],
            selectforeground=colors['selected_fg']
        )
        
        # TButton
        style.configure('TButton',
            background=colors['button_bg'],
            foreground=colors['button_fg'],
            padding=5
        )
        style.map('TButton',
            background=[('active', colors['accent'])],
            foreground=[('active', colors['selected_fg'])]
        )
        
        # TFrame
        style.configure('TFrame',
            background=colors['frame_bg']
        )
        
        # TLabel
        style.configure('TLabel',
            background=colors['bg'],
            foreground=colors['fg']
        )
        
        # TEntry
        style.configure('TEntry',
            fieldbackground=colors['entry_bg'],
            foreground=colors['entry_fg'],
            insertcolor=colors['fg']
        )
        
        # TScale (Slider)
        style.configure('TScale',
            troughcolor=colors['slider_bg'],
            slidercolor=colors['slider_fg']
        )
        
        # TProgressbar
        style.configure('TProgressbar',
            troughcolor=colors['slider_bg'],
            background=colors['accent']
        )
        
        # TNotebook
        style.configure('TNotebook',
            background=colors['bg'],
            tabmargins=[2, 5, 2, 0]
        )
        style.configure('TNotebook.Tab',
            background=colors['button_bg'],
            foreground=colors['button_fg'],
            padding=[10, 2]
        )
        style.map('TNotebook.Tab',
            background=[('selected', colors['accent'])],
            foreground=[('selected', colors['selected_fg'])]
        )
        
        # Custom styles
        style.configure('Success.TButton',
            background=colors['success']
        )
        style.configure('Warning.TButton',
            background=colors['warning']
        )
        style.configure('Error.TButton',
            background=colors['error']
        )
    
    def _configure_root_window(self, colors: Dict[str, str]) -> None:
        """Configure root window colors"""
        try:
            root = self._get_root_window()
            if root:
                root.configure(bg=colors['bg'])
                
                # Configure standard tk widgets that might be used
                root.option_add('*Background', colors['bg'])
                root.option_add('*Foreground', colors['fg'])
                root.option_add('*selectBackground', colors['selected_bg'])
                root.option_add('*selectForeground', colors['selected_fg'])
                
        except Exception as e:
            logger.log_error(e, {"context": "Configuring root window"})
    
    def _get_root_window(self) -> Optional[tk.Tk]:
        """Get root window instance"""
        for widget in tk.Tk.winfo_all(tk._default_root):
            if isinstance(widget, tk.Tk):
                return widget
        return None
    
    def _get_theme_colors(self, theme_name: str) -> Dict[str, str]:
        """Get colors for specified theme"""
        if theme_name in self._custom_themes:
            return self._custom_themes[theme_name]
        return self.THEMES[theme_name]
    
    @log_function
    def register_custom_theme(self, name: str, colors: Dict[str, str]) -> bool:
        """Register a custom theme"""
        try:
            # Validate required colors
            required_colors = set(self.THEMES['dark'].keys())
            if not required_colors.issubset(set(colors.keys())):
                missing = required_colors - set(colors.keys())
                logger.logger.error(f"Missing required colors: {missing}")
                return False
            
            self._custom_themes[name] = colors
            self._save_custom_themes()
            return True
            
        except Exception as e:
            logger.log_error(e, {"context": f"Registering custom theme '{name}'"})
            return False
    
    def _load_custom_themes(self) -> None:
        """Load custom themes from config"""
        custom_themes = config_manager.get_config_value('themes', 'custom_themes')
        if custom_themes:
            self._custom_themes = custom_themes
    
    def _save_custom_themes(self) -> None:
        """Save custom themes to config"""
        config_manager.set_config_value('themes', 'custom_themes', self._custom_themes)
    
    def get_available_themes(self) -> list:
        """Get list of available themes"""
        return list(self.THEMES.keys()) + list(self._custom_themes.keys())
    
    def get_current_theme(self) -> str:
        """Get current theme name"""
        return self._current_theme
    
    def get_theme_colors(self, theme_name: Optional[str] = None) -> Dict[str, str]:
        """Get colors for current or specified theme"""
        theme = theme_name or self._current_theme
        return self._get_theme_colors(theme)

# Create global theme manager instance
theme_manager = ThemeManager()

# Initialize theme system
theme_manager.initialize()