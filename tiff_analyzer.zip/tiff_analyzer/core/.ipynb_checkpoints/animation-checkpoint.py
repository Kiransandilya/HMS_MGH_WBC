# tiff_analyzer/core/animation.py

import time
from typing import Optional, Dict, Callable
import threading
from ..utils.logger import logger, log_function
from ..core.state_manager import state_manager, PlaybackState
from ..core.visualization import visualization_manager
from ..utils.config import config_manager



class AnimationManager:
    """Manages animation and playback of TIFF stacks"""
    
    def __init__(self):
        self._animation_thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._pause_event = threading.Event()
        self._frame_callbacks: Dict[str, Callable] = {}
        self._current_frame = 0
        self._fps = config_manager.get_config_value('playback', 'default_fps')
        self._loop_playback = config_manager.get_config_value('playback', 'loop_playback')
        self._marked_frames = set()
        self._long_mark_active = False
        
    @property
    def fps(self) -> float:
        """Get current FPS"""
        return self._fps
    
    @fps.setter
    def fps(self, value: float) -> None:
        """Set FPS value"""
        self._fps = max(0.1, min(value, 60.0))  # Limit FPS between 0.1 and 60
    
    @log_function
    def start_playback(self) -> bool:
        """Start or resume playback"""
        try:
            if not self._animation_thread or not self._animation_thread.is_alive():
                self._stop_event.clear()
                self._pause_event.clear()
                self._animation_thread = threading.Thread(target=self._animation_loop)
                self._animation_thread.daemon = True
                self._animation_thread.start()
                state_manager.update_state(playback_state=PlaybackState.PLAYING)
                return True
            else:
                self._pause_event.clear()
                state_manager.update_state(playback_state=PlaybackState.PLAYING)
                return True
        except Exception as e:
            logger.log_error(e, {"context": "Starting playback"})
            return False
            
    @log_function
    def configure(self, fps: Optional[float] = None, loop: Optional[bool] = None) -> None:
        """
        Configure animation playback settings
        
        Args:
            fps (float, optional): Frames per second for playback
            loop (bool, optional): Whether to loop playback
        """
        try:
            if fps is not None:
                self.fps = fps
            
            if loop is not None:
                self.set_loop_playback(loop)
        except Exception as e:
            logger.log_error(e, {"context": "Configuring animation"})
            
    @log_function
    def pause_playback(self) -> None:
        """Pause playback"""
        self._pause_event.set()
        state_manager.update_state(playback_state=PlaybackState.PAUSED)
    
    @log_function
    def stop_playback(self) -> None:
        """Stop playback"""
        self._stop_event.set()
        self._pause_event.clear()
        state_manager.update_state(playback_state=PlaybackState.STOPPED)
        if self._animation_thread and self._animation_thread.is_alive():
            self._animation_thread.join()
    
    def _animation_loop(self) -> None:
        """Main animation loop"""
        try:
            while not self._stop_event.is_set():
                if self._pause_event.is_set():
                    time.sleep(0.1)  # Reduce CPU usage while paused
                    continue
                
                start_time = time.time()
                
                # Update frame
                self._update_frame()
                
                # Calculate sleep time to maintain FPS
                elapsed = time.time() - start_time
                sleep_time = max(0, (1.0 / self._fps) - elapsed)
                time.sleep(sleep_time)
                
        except Exception as e:
            logger.log_error(e, {"context": "Animation loop"})
            self.stop_playback()
    
    def _update_frame(self) -> None:
        """Update current frame and trigger visualization"""
        with self._lock:
            # Get frame counts
            state = state_manager.get_state()
            max_frames = state_manager.get_state().total_frames
            
            if max_frames == 0:
                return
            
            # Update frame counter
            self._current_frame += 1
            if self._current_frame >= max_frames:
                if self._loop_playback:
                    self._current_frame = 0
                else:
                    self.stop_playback()
                    return
            
            # Update state and visualization
            state_manager.update_state(current_frame=self._current_frame)
            visualization_manager.update_display(self._current_frame)
            
            # Process callbacks
            for callback in self._frame_callbacks.values():
                try:
                    callback(self._current_frame)
                except Exception as e:
                    logger.log_error(e, {"context": "Frame callback"})
    
    @log_function
    def register_frame_callback(self, callback_id: str, callback: Callable) -> None:
        """Register callback for frame updates"""
        self._frame_callbacks[callback_id] = callback
    
    @log_function
    def unregister_frame_callback(self, callback_id: str) -> None:
        """Unregister frame callback"""
        if callback_id in self._frame_callbacks:
            del self._frame_callbacks[callback_id]
    
    @log_function
    def seek_to_frame(self, frame_number: int) -> None:
        """Seek to specific frame"""
        with self._lock:
            max_frames = state_manager.get_state().total_frames
            self._current_frame = max(0, min(frame_number, max_frames - 1))
            state_manager.update_state(current_frame=self._current_frame)
            visualization_manager.update_display(self._current_frame)
    
    @log_function
    def mark_frame(self, frame_number: Optional[int] = None) -> None:
        """Mark current or specified frame"""
        frame = frame_number if frame_number is not None else self._current_frame
        self._marked_frames.add(frame)
        state_manager.update_state(marked_frames=list(self._marked_frames))
    
    @log_function
    def start_continuous_marking(self) -> None:
        """Start continuous frame marking"""
        self._long_mark_active = True
    
    @log_function
    def stop_continuous_marking(self) -> None:
        """Stop continuous frame marking"""
        self._long_mark_active = False
    
    @log_function
    def get_marked_frames(self) -> list:
        """Get list of marked frames"""
        return sorted(list(self._marked_frames))
    
    @log_function
    def clear_marked_frames(self) -> None:
        """Clear all marked frames"""
        self._marked_frames.clear()
        state_manager.update_state(marked_frames=[])
    
    @log_function
    def set_loop_playback(self, enable: bool) -> None:
        """Enable or disable loop playback"""
        self._loop_playback = enable
    
    @log_function
    def next_frame(self) -> None:
        """Move to next frame"""
        with self._lock:
            max_frames = state_manager.get_state().total_frames
            if self._current_frame < max_frames - 1:
                self._current_frame += 1
                state_manager.update_state(current_frame=self._current_frame)
                visualization_manager.update_display(self._current_frame)
    
    @log_function
    def previous_frame(self) -> None:
        """Move to previous frame"""
        with self._lock:
            if self._current_frame > 0:
                self._current_frame -= 1
                state_manager.update_state(current_frame=self._current_frame)
                visualization_manager.update_display(self._current_frame)

    def on_state_change(self, state_change_event):
        """
        Handle state change events
        
        Args:
            state_change_event (Event): State change event object
        """
        try:
            # Example implementation - you might want to customize this
            if state_change_event.type == EventType.STATE_CHANGED:
                # Check if the state change affects playback
                state_data = state_change_event.data
                
                # Example: Adjust playback based on state
                if 'playback_state' in state_data:
                    playback_state = state_data['playback_state']
                    
                    if playback_state == PlaybackState.PLAYING:
                        self.start_playback()
                    elif playback_state == PlaybackState.PAUSED:
                        self.pause_playback()
                    elif playback_state == PlaybackState.STOPPED:
                        self.stop_playback()
        except Exception as e:
            logger.log_error(e, {"context": "Animation state change handling"})
    
    @log_function
    def jump_to_marked_frame(self, direction: str = 'next') -> None:
        """Jump to next or previous marked frame"""
        marked_frames = self.get_marked_frames()
        if not marked_frames:
            return
            
        if direction == 'next':
            next_marked = next(
                (f for f in marked_frames if f > self._current_frame),
                marked_frames[0]
            )
            self.seek_to_frame(next_marked)
        else:
            prev_marked = next(
                (f for f in reversed(marked_frames) if f < self._current_frame),
                marked_frames[-1]
            )
            self.seek_to_frame(prev_marked)

# Create global animation manager instance
animation_manager = AnimationManager()

# Example usage:
if __name__ == "__main__":
    def frame_callback(frame_num):
        print(f"Frame: {frame_num}")
    
    animation_manager.register_frame_callback("test", frame_callback)
    animation_manager.start_playback()
    time.sleep(5)
    animation_manager.stop_playback()