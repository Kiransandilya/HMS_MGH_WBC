# tiff_analyzer/core/state_manager.py

from enum import Enum, auto
from typing import Dict, Any, Optional, List, Callable
from dataclasses import dataclass, field
import threading
from ..utils.logger import logger, log_function
from ..utils.config import config_manager

class ViewMode(Enum):
    SIDE_BY_SIDE = "side_by_side"
    OVERLAY = "overlay"
    TOP_BOTTOM = "top_bottom"
    GRID = "grid"

class PlaybackState(Enum):
    STOPPED = auto()
    PLAYING = auto()
    PAUSED = auto()

class AnalysisMode(Enum):
    NONE = "none"
    ROI_SELECTION = "roi_selection"
    MEASUREMENT = "measurement"
    FEATURE_EXTRACTION = "feature_extraction"
    WBC_ANALYSIS = "wbc_analysis"

@dataclass
class ApplicationState:
    """Represents the complete state of the application"""
    # View state
    view_mode: ViewMode = ViewMode.SIDE_BY_SIDE
    dark_mode: bool = True
    sync_views: bool = True
    zoom_level: Dict[str, float] = field(default_factory=lambda: {"stack1": 1.0, "stack2": 1.0})
    
    # Playback state
    playback_state: PlaybackState = PlaybackState.STOPPED
    current_frame: int = 0
    fps: int = 10
    
    # Analysis state
    analysis_mode: AnalysisMode = AnalysisMode.NONE
    selected_rois: List[Dict] = field(default_factory=list)
    marked_frames: List[int] = field(default_factory=list)
    
    # Data state
    stack1_loaded: bool = False
    stack2_loaded: bool = False
    stack1_path: Optional[str] = None
    stack2_path: Optional[str] = None

class StateManager:
    """Manages the application state and state transitions"""
    
    def __init__(self):
        self._state = ApplicationState()
        self._state_lock = threading.Lock()
        self._observers: Dict[str, List[Callable]] = {}
        self._history: List[ApplicationState] = []
        self._history_position = -1
        self._max_history = 50
        
    @log_function
    def get_state(self) -> ApplicationState:
        """Get current application state"""
        with self._state_lock:
            return self._state
    
    @log_function
    def update_state(self, **kwargs) -> None:
        """Update state with new values"""
        with self._state_lock:
            old_state = self._state
            
            # Create new state with updates
            new_state_dict = {
                field: getattr(self._state, field) 
                for field in self._state.__dataclass_fields__
            }
            new_state_dict.update(kwargs)
            
            self._state = ApplicationState(**new_state_dict)
            
            # Add to history
            self._add_to_history(old_state)
            
            # Notify observers
            self._notify_observers(old_state, self._state)


    # Add these methods to your StateManager class in state_manager.py

    @log_function
    def restore_state(self, state_data: Optional[Dict[str, Any]]) -> bool:
        """Restore application state from saved data"""
        try:
            if not state_data:
                logger.logger.debug("No state data to restore")
                return False

            with self._state_lock:
                # Convert enum strings back to enum values
                if 'view_mode' in state_data:
                    state_data['view_mode'] = ViewMode(state_data['view_mode'])
                if 'playback_state' in state_data:
                    state_data['playback_state'] = PlaybackState[state_data['playback_state']]
                if 'analysis_mode' in state_data:
                    state_data['analysis_mode'] = AnalysisMode(state_data['analysis_mode'])

                # Create new state with restored values
                new_state_dict = {
                    field: getattr(self._state, field) 
                    for field in self._state.__dataclass_fields__
                }
                new_state_dict.update(state_data)
                
                old_state = self._state
                self._state = ApplicationState(**new_state_dict)
                
                # Notify observers
                self._notify_observers(old_state, self._state)
                
                logger.logger.info("Application state restored successfully")
                return True
                
        except Exception as e:
            logger.log_error(e, {
                "context": "State restoration",
                "state_data": state_data
            })
            return False
    
    def save_state(self) -> Dict[str, Any]:
        """Save current application state"""
        with self._state_lock:
            try:
                # Convert state to dictionary
                state_dict = {
                    field: getattr(self._state, field)
                    for field in self._state.__dataclass_fields__
                }
                
                # Convert enum values to strings for serialization
                state_dict['view_mode'] = state_dict['view_mode'].value
                state_dict['playback_state'] = state_dict['playback_state'].name
                state_dict['analysis_mode'] = state_dict['analysis_mode'].value
                
                return state_dict
                
            except Exception as e:
                logger.log_error(e, {"context": "State saving"})
                return {}
    
    def _add_to_history(self, state: ApplicationState) -> None:
        """Add state to history"""
        self._history_position += 1
        if self._history_position < len(self._history):
            self._history = self._history[:self._history_position]
        
        self._history.append(state)
        
        # Maintain maximum history size
        if len(self._history) > self._max_history:
            self._history.pop(0)
            self._history_position -= 1
    
    @log_function
    def undo(self) -> bool:
        """Restore previous state"""
        with self._state_lock:
            if self._history_position > 0:
                self._history_position -= 1
                self._state = self._history[self._history_position]
                self._notify_observers(None, self._state)
                return True
            return False
    
    @log_function
    def redo(self) -> bool:
        """Restore next state"""
        with self._state_lock:
            if self._history_position < len(self._history) - 1:
                self._history_position += 1
                self._state = self._history[self._history_position]
                self._notify_observers(None, self._state)
                return True
            return False
    
    def add_observer(self, observer_id: str, callback: Callable[[ApplicationState], None]) -> None:
        """Add state observer"""
        if observer_id not in self._observers:
            self._observers[observer_id] = []
        self._observers[observer_id].append(callback)
    
    def remove_observer(self, observer_id: str) -> None:
        """Remove state observer"""
        if observer_id in self._observers:
            del self._observers[observer_id]
    
    def _notify_observers(self, old_state: Optional[ApplicationState], 
                         new_state: ApplicationState) -> None:
        """Notify all observers of state change"""
        for observer_list in self._observers.values():
            for callback in observer_list:
                try:
                    callback(new_state)
                except Exception as e:
                    logger.log_error(e, {
                        "context": "Observer notification",
                        "old_state": old_state,
                        "new_state": new_state
                    })
    
    # State validation methods
    def can_play(self) -> bool:
        """Check if playback can start"""
        return (self._state.stack1_loaded or self._state.stack2_loaded) and \
               self._state.playback_state != PlaybackState.PLAYING
    
    def can_analyze(self) -> bool:
        """Check if analysis can be performed"""
        return self._state.stack1_loaded or self._state.stack2_loaded
    
    def can_sync_views(self) -> bool:
        """Check if views can be synchronized"""
        return self._state.stack1_loaded and self._state.stack2_loaded
    
    # State transition methods
    @log_function
    def start_playback(self) -> bool:
        """Start playback if possible"""
        if self.can_play():
            self.update_state(playback_state=PlaybackState.PLAYING)
            return True
        return False
    
    @log_function
    def pause_playback(self) -> None:
        """Pause playback"""
        self.update_state(playback_state=PlaybackState.PAUSED)
    
    @log_function
    def stop_playback(self) -> None:
        """Stop playback"""
        self.update_state(
            playback_state=PlaybackState.STOPPED,
            current_frame=0
        )
    
    @log_function
    def mark_frame(self) -> None:
        """Mark current frame"""
        if self._state.current_frame not in self._state.marked_frames:
            marked_frames = self._state.marked_frames.copy()
            marked_frames.append(self._state.current_frame)
            self.update_state(marked_frames=marked_frames)
    
    @log_function
    def toggle_sync_views(self) -> None:
        """Toggle view synchronization"""
        self.update_state(sync_views=not self._state.sync_views)
    
    @log_function
    def set_analysis_mode(self, mode: AnalysisMode) -> None:
        """Set analysis mode"""
        if self.can_analyze():
            self.update_state(analysis_mode=mode)

# Create global state manager instance
state_manager = StateManager()

# Example usage:
if __name__ == "__main__":
    # Test state management
    def state_changed(new_state: ApplicationState):
        print(f"State changed: {new_state}")
    
    state_manager.add_observer("test", state_changed)
    state_manager.update_state(current_frame=5)
    state_manager.start_playback()
    state_manager.mark_frame()