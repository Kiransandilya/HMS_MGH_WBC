# tiff_analyzer/core/visualization.py

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.axes import Axes
from matplotlib.widgets import RectangleSelector, EllipseSelector
from typing import Optional, Dict, Tuple, List, Callable
import threading
from ..utils.logger import logger, log_function
from ..core.state_manager import state_manager, ViewMode
from ..core.image_loader import image_loader
from ..utils.config import config_manager

class VisualizationManager:
    """Manages visualization of TIFF stacks including overlays and ROI"""
    
    def __init__(self):
        self.fig: Optional[Figure] = None
        self.axes: Dict[str, Axes] = {}
        self._lock = threading.Lock()
        self._roi_selectors: Dict[str, List] = {}
        self._overlay_alpha = config_manager.get_config_value('view', 'overlay_alpha')
        self._current_frame = 0
        self._contrast_limits: Dict[str, Tuple[float, float]] = {}
        
    @log_function
    def initialize_display(self, fig: Figure) -> None:
        """Initialize the display with a matplotlib figure"""
        self.fig = fig
        self.fig.canvas.mpl_connect('button_press_event', self._on_click)
        self.fig.canvas.mpl_connect('key_press_event', self._on_key_press)
        self._setup_axes()

    def configure_display(self, dark_mode: bool = True, overlay_alpha: float = 0.5) -> None:
        """Configure display settings"""
        try:
            # Set matplotlib style first
            if dark_mode:
                plt.style.use('dark_background')
            else:
                plt.style.use('default')
                
            self._overlay_alpha = overlay_alpha
            
            # Only attempt to set figure properties if figure exists
            if self.fig is not None:
                self.fig.patch.set_facecolor('#2b2b2b' if dark_mode else 'white')
                
                # Check if canvas exists before trying to draw
                if hasattr(self.fig, 'canvas'):
                    self.fig.canvas.draw()
                    
        except Exception as e:
            logger.log_error(e, {"context": "Configuring display"})
        
    def _setup_axes(self) -> None:
        """Setup axes based on current view mode"""
        view_mode = state_manager.get_state().view_mode
        self.fig.clear()
        
        if view_mode == ViewMode.SIDE_BY_SIDE:
            self.axes['left'] = self.fig.add_subplot(121)
            self.axes['right'] = self.fig.add_subplot(122)
        elif view_mode == ViewMode.OVERLAY:
            self.axes['main'] = self.fig.add_subplot(111)
        elif view_mode == ViewMode.TOP_BOTTOM:
            self.axes['top'] = self.fig.add_subplot(211)
            self.axes['bottom'] = self.fig.add_subplot(212)
        
        for ax in self.axes.values():
            ax.set_xticks([])
            ax.set_yticks([])

    @log_function
    def set_theme(self, dark_mode: bool) -> None:
        """Set visualization theme"""
        try:
            if dark_mode:
                plt.style.use('dark_background')
                self.fig.patch.set_facecolor('#2b2b2b')
            else:
                plt.style.use('default')
                self.fig.patch.set_facecolor('white')
            
            if hasattr(self, 'canvas'):
                self.canvas.draw()
        except Exception as e:
            logger.log_error(e, {"context": "Setting theme"})
    
    @log_function
    def update_display(self, frame_index: Optional[int] = None) -> None:
        """Update the display with current frame"""
        if frame_index is not None:
            self._current_frame = frame_index
            
        try:
            view_mode = state_manager.get_state().view_mode
            
            if view_mode == ViewMode.SIDE_BY_SIDE:
                self._update_side_by_side()
            elif view_mode == ViewMode.OVERLAY:
                self._update_overlay()
            elif view_mode == ViewMode.TOP_BOTTOM:
                self._update_top_bottom()
                
            self.fig.canvas.draw_idle()
            
        except Exception as e:
            logger.log_error(e, {"context": "Updating display"})
    
    def _update_side_by_side(self) -> None:
        """Update side-by-side view"""
        with self._lock:
            # Clear axes
            self.axes['left'].clear()
            self.axes['right'].clear()
            
            # Display frames
            if image_loader.is_stack_loaded("stack1"):
                frame1 = image_loader.get_frame("stack1", self._current_frame)
                if frame1 is not None:
                    self._display_frame(self.axes['left'], frame1, "stack1")
                    
            if image_loader.is_stack_loaded("stack2"):
                frame2 = image_loader.get_frame("stack2", self._current_frame)
                if frame2 is not None:
                    self._display_frame(self.axes['right'], frame2, "stack2")
    
    def _update_overlay(self) -> None:
        """Update overlay view"""
        with self._lock:
            self.axes['main'].clear()
            
            if image_loader.is_stack_loaded("stack1"):
                frame1 = image_loader.get_frame("stack1", self._current_frame)
                if frame1 is not None:
                    self.axes['main'].imshow(frame1, cmap='gray')
                    
            if image_loader.is_stack_loaded("stack2"):
                frame2 = image_loader.get_frame("stack2", self._current_frame)
                if frame2 is not None:
                    self.axes['main'].imshow(frame2, cmap='gray', alpha=self._overlay_alpha)
    
    def _update_top_bottom(self) -> None:
        """Update top-bottom view"""
        with self._lock:
            self.axes['top'].clear()
            self.axes['bottom'].clear()
            
            if image_loader.is_stack_loaded("stack1"):
                frame1 = image_loader.get_frame("stack1", self._current_frame)
                if frame1 is not None:
                    self._display_frame(self.axes['top'], frame1, "stack1")
                    
            if image_loader.is_stack_loaded("stack2"):
                frame2 = image_loader.get_frame("stack2", self._current_frame)
                if frame2 is not None:
                    self._display_frame(self.axes['bottom'], frame2, "stack2")
    
    def _display_frame(self, ax: Axes, frame: np.ndarray, stack_id: str) -> None:
        """Display a single frame with current settings"""
        # Apply contrast limits if set
        vmin, vmax = self._contrast_limits.get(stack_id, (None, None))
        ax.imshow(frame, cmap='gray', vmin=vmin, vmax=vmax)
        
        # Add ROI overlays if any
        if stack_id in self._roi_selectors:
            for roi in self._roi_selectors[stack_id]:
                roi.draw()
    
    @log_function
    def add_roi(self, stack_id: str, roi_type: str = 'rectangle') -> None:
        """Add ROI selector to specified stack"""
        if stack_id not in self._roi_selectors:
            self._roi_selectors[stack_id] = []
            
        ax = self._get_stack_axis(stack_id)
        if ax is None:
            return
            
        if roi_type == 'rectangle':
            selector = RectangleSelector(
                ax, self._roi_callback,
                useblit=True,
                props=dict(facecolor='red', edgecolor='red', alpha=0.3)
            )
        elif roi_type == 'ellipse':
            selector = EllipseSelector(
                ax, self._roi_callback,
                useblit=True,
                props=dict(facecolor='red', edgecolor='red', alpha=0.3)
            )
            
        self._roi_selectors[stack_id].append(selector)
    
    def _roi_callback(self, eclick, erelease) -> None:
        """Handle ROI selection"""
        x1, y1 = eclick.xdata, eclick.ydata
        x2, y2 = erelease.xdata, erelease.ydata
        state_manager.update_state(
            selected_roi={'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2}
        )
    
    def _get_stack_axis(self, stack_id: str) -> Optional[Axes]:
        """Get the appropriate axis for a stack"""
        view_mode = state_manager.get_state().view_mode
        
        if view_mode == ViewMode.SIDE_BY_SIDE:
            return self.axes['left'] if stack_id == "stack1" else self.axes['right']
        elif view_mode == ViewMode.OVERLAY:
            return self.axes['main']
        elif view_mode == ViewMode.TOP_BOTTOM:
            return self.axes['top'] if stack_id == "stack1" else self.axes['bottom']
        
        return None
    
    @log_function
    def set_contrast(self, stack_id: str, vmin: float, vmax: float) -> None:
        """Set contrast limits for a stack"""
        self._contrast_limits[stack_id] = (vmin, vmax)
        self.update_display()
    
    @log_function
    def auto_contrast(self, stack_id: str) -> None:
        """Automatically set contrast for a stack"""
        frame = image_loader.get_frame(stack_id, self._current_frame)
        if frame is not None:
            vmin = np.percentile(frame, 1)
            vmax = np.percentile(frame, 99)
            self.set_contrast(stack_id, vmin, vmax)
    
    @log_function
    def set_overlay_alpha(self, alpha: float) -> None:
        """Set overlay transparency"""
        self._overlay_alpha = alpha
        if state_manager.get_state().view_mode == ViewMode.OVERLAY:
            self.update_display()
    
    def _on_click(self, event) -> None:
        """Handle mouse click events"""
        if event.inaxes is None:
            return
            
        # Handle different click types
        if event.button == 1:  # Left click
            pass
        elif event.button == 2:  # Middle click
            pass
        elif event.button == 3:  # Right click
            pass
    
    def _on_key_press(self, event) -> None:
        """Handle keyboard events"""
        if event.key == 'r':  # Reset view
            self._reset_view()
        elif event.key == 'c':  # Auto contrast
            self._auto_contrast_all()
    
    def _reset_view(self) -> None:
        """Reset view to default"""
        for ax in self.axes.values():
            ax.set_xlim(auto=True)
            ax.set_ylim(auto=True)
        self.fig.canvas.draw_idle()
    
    def _auto_contrast_all(self) -> None:
        """Auto contrast all visible stacks"""
        for stack_id in ["stack1", "stack2"]:
            if image_loader.is_stack_loaded(stack_id):
                self.auto_contrast(stack_id)




    def register_sync_callback(self, callback: Callable) -> None:
        """
        Register a synchronization callback for the visualization manager
        
        Args:
            callback (Callable): Callback function for synchronization
        """
        try:
            # If you want to store multiple callbacks, you might create a list
            if not hasattr(self, '_sync_callbacks'):
                self._sync_callbacks = []
            
            # Add the callback if it's not already in the list
            if callback not in self._sync_callbacks:
                self._sync_callbacks.append(callback)
            
            logger.logger.debug(f"Registered sync callback: {callback}")
        except Exception as e:
            logger.log_error(e, {"context": "Registering sync callback"})

# Create global visualization manager instance
visualization_manager = VisualizationManager()

# Example usage:
if __name__ == "__main__":
    # Create test figure
    fig = plt.figure(figsize=(12, 6))
    visualization_manager.initialize_display(fig)
    plt.show()