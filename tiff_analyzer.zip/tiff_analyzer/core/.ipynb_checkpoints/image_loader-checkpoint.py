# tiff_analyzer/core/image_loader.py

import numpy as np
from typing import Optional, Tuple, List, Dict
import tifffile
from pathlib import Path
import threading
from concurrent.futures import ThreadPoolExecutor
from ..utils.logger import logger, log_function
from ..core.state_manager import state_manager
from ..utils.config import config_manager

class ImageStack:
    """Represents a single TIFF stack with metadata and processing methods"""
    
    def __init__(self, file_path: str):
        self.file_path = file_path
        self.data: Optional[np.ndarray] = None
        self.metadata: Dict = {}
        self.frame_count: int = 0
        self.shape: Tuple = ()
        self.dtype = None
        self._lock = threading.Lock()
        self._loaded = False
        
    @log_function
    def load(self) -> bool:
        """Load the TIFF stack into memory"""
        try:
            with tifffile.TiffFile(self.file_path) as tif:
                with self._lock:
                    self.data = tif.asarray()
                    self.metadata = dict(tif.imagej_metadata) if tif.imagej_metadata else {}
                    self.frame_count = len(tif.pages)
                    self.shape = self.data.shape
                    self.dtype = self.data.dtype
                    self._loaded = True
            return True
            
        except Exception as e:
            logger.log_error(e, {
                "context": "Loading TIFF stack",
                "file_path": self.file_path
            })
            return False
    
    @log_function
    def unload(self) -> None:
        """Unload the stack from memory"""
        with self._lock:
            self.data = None
            self._loaded = False
    
    @log_function
    def get_frame(self, index: int) -> Optional[np.ndarray]:
        """Get a specific frame from the stack"""
        try:
            with self._lock:
                if not self._loaded:
                    return None
                if 0 <= index < self.frame_count:
                    return self.data[index].copy()
                return None
        except Exception as e:
            logger.log_error(e, {
                "context": "Getting frame",
                "frame_index": index
            })
            return None
    
    @property
    def is_loaded(self) -> bool:
        """Check if stack is loaded"""
        return self._loaded

class ImageLoader:
    """Manages loading and caching of TIFF stacks"""
    
    def __init__(self):
        self.stacks: Dict[str, ImageStack] = {}
        self._cache_size = config_manager.get_config_value('core', 'cache_size', default=512)
        self._executor = ThreadPoolExecutor(max_workers=2)
        self._lock = threading.Lock()


    def set_cache_size(self, cache_size: int) -> None:
        """Set the cache size for the image loader"""
        with self._lock:
            self._cache_size = cache_size
    
    def get_cache_size(self) -> int:
        """Get the current cache size"""
        return self._cache_size
        
    @log_function
    def load_stack(self, stack_id: str, file_path: str) -> bool:
        """Load a new stack"""
        try:
            # Create new stack object
            stack = ImageStack(file_path)
            
            # Load stack in background
            future = self._executor.submit(stack.load)
            success = future.result()
            
            if success:
                with self._lock:
                    self.stacks[stack_id] = stack
                    
                # Update application state
                if stack_id == "stack1":
                    state_manager.update_state(
                        stack1_loaded=True,
                        stack1_path=file_path
                    )
                elif stack_id == "stack2":
                    state_manager.update_state(
                        stack2_loaded=True,
                        stack2_path=file_path
                    )
                
                return True
            return False
            
        except Exception as e:
            logger.log_error(e, {
                "context": "Loading stack",
                "stack_id": stack_id,
                "file_path": file_path
            })
            return False
    
    @log_function
    def get_frame(self, stack_id: str, frame_index: int) -> Optional[np.ndarray]:
        """Get a specific frame from a loaded stack"""
        try:
            with self._lock:
                if stack_id in self.stacks:
                    return self.stacks[stack_id].get_frame(frame_index)
            return None
            
        except Exception as e:
            logger.log_error(e, {
                "context": "Getting frame",
                "stack_id": stack_id,
                "frame_index": frame_index
            })
            return None
    
    @log_function
    def unload_stack(self, stack_id: str) -> bool:
        """Unload a stack from memory"""
        try:
            with self._lock:
                if stack_id in self.stacks:
                    self.stacks[stack_id].unload()
                    del self.stacks[stack_id]
                    
                    # Update application state
                    if stack_id == "stack1":
                        state_manager.update_state(
                            stack1_loaded=False,
                            stack1_path=None
                        )
                    elif stack_id == "stack2":
                        state_manager.update_state(
                            stack2_loaded=False,
                            stack2_path=None
                        )
                    
                    return True
            return False
            
        except Exception as e:
            logger.log_error(e, {
                "context": "Unloading stack",
                "stack_id": stack_id
            })
            return False
    
    @log_function
    def get_stack_info(self, stack_id: str) -> Dict:
        """Get information about a loaded stack"""
        try:
            with self._lock:
                if stack_id in self.stacks:
                    stack = self.stacks[stack_id]
                    return {
                        "file_path": stack.file_path,
                        "frame_count": stack.frame_count,
                        "shape": stack.shape,
                        "dtype": str(stack.dtype),
                        "metadata": stack.metadata
                    }
            return {}
            
        except Exception as e:
            logger.log_error(e, {
                "context": "Getting stack info",
                "stack_id": stack_id
            })
            return {}
    
    def is_stack_loaded(self, stack_id: str) -> bool:
        """Check if a stack is loaded"""
        with self._lock:
            return stack_id in self.stacks and self.stacks[stack_id].is_loaded
    
    @log_function
    def validate_tiff(self, file_path: str) -> Tuple[bool, str]:
        """Validate a TIFF file before loading"""
        try:
            with tifffile.TiffFile(file_path) as tif:
                # Check if it's a valid TIFF stack
                if not tif.pages:
                    return False, "Empty TIFF file"
                
                # Check if all pages have the same shape
                first_shape = tif.pages[0].shape
                if not all(page.shape == first_shape for page in tif.pages):
                    return False, "Inconsistent frame dimensions"
                
                return True, "Valid TIFF stack"
                
        except Exception as e:
            return False, f"Invalid TIFF file: {str(e)}"
    
    def cleanup(self) -> None:
        """Clean up resources"""
        with self._lock:
            for stack_id in list(self.stacks.keys()):
                self.unload_stack(stack_id)
        self._executor.shutdown()

# Create global image loader instance
image_loader = ImageLoader()

# Example usage:
if __name__ == "__main__":
    # Test image loading
    test_file = "path/to/test.tif"
    if Path(test_file).exists():
        success = image_loader.load_stack("test_stack", test_file)
        if success:
            frame = image_loader.get_frame("test_stack", 0)
            print("Frame shape:", frame.shape if frame is not None else None)
            image_loader.cleanup()