# tiff_analyzer/core/synchronizer.py

from typing import Dict, Optional, Tuple, List, Any, Callable 
import threading
from ..utils.logger import logger, log_function
from ..core.state_manager import state_manager, ViewMode
from ..core.visualization import visualization_manager
from ..core.image_loader import image_loader
from ..utils.config import config_manager

class ViewSynchronizer:
    """Manages synchronization between different views and components"""
    
    def __init__(self):
        self._lock = threading.Lock()
        self._sync_enabled = config_manager.get_config_value('view', 'sync_views')
        self._zoom_states: Dict[str, Dict[str, Any]] = {
            'stack1': {'xlim': None, 'ylim': None, 'zoom_level': 1.0},
            'stack2': {'xlim': None, 'ylim': None, 'zoom_level': 1.0}
        }
        self._roi_sync: Dict[str, List] = {'stack1': [], 'stack2': []}
        self._contrast_sync: Dict[str, Tuple[float, float]] = {}
        self._last_active_view: Optional[str] = None
        
    @property
    def sync_enabled(self) -> bool:
        """Get sync status"""
        return self._sync_enabled
    
    @sync_enabled.setter
    def sync_enabled(self, value: bool) -> None:
        """Set sync status"""
        self._sync_enabled = value
        if value:
            self._sync_all_views()
    
    @log_function
    def sync_zoom(self, source_stack: str, xlim: Tuple[float, float], 
                 ylim: Tuple[float, float], zoom_level: float) -> None:
        """Synchronize zoom levels between views"""
        if not self._sync_enabled:
            return
            
        with self._lock:
            # Update source state
            self._zoom_states[source_stack] = {
                'xlim': xlim,
                'ylim': ylim,
                'zoom_level': zoom_level
            }
            
            # Apply to other stack if in sync mode
            target_stack = 'stack2' if source_stack == 'stack1' else 'stack1'
            if image_loader.is_stack_loaded(target_stack):
                visualization_manager.set_view_limits(
                    target_stack, xlim, ylim, zoom_level
                )
    
    @log_function
    def sync_roi(self, source_stack: str, roi_info: Dict) -> None:
        """Synchronize ROI between views"""
        if not self._sync_enabled:
            return
            
        with self._lock:
            # Store ROI for source stack
            self._roi_sync[source_stack].append(roi_info)
            
            # Apply to other stack if in sync mode
            target_stack = 'stack2' if source_stack == 'stack1' else 'stack1'
            if image_loader.is_stack_loaded(target_stack):
                visualization_manager.add_roi(target_stack, roi_info)
    
    @log_function
    def sync_contrast(self, source_stack: str, vmin: float, vmax: float) -> None:
        """Synchronize contrast settings between views"""
        if not self._sync_enabled:
            return
            
        with self._lock:
            # Store contrast settings
            self._contrast_sync[source_stack] = (vmin, vmax)
            
            # Apply to other stack if in sync mode
            target_stack = 'stack2' if source_stack == 'stack1' else 'stack1'
            if image_loader.is_stack_loaded(target_stack):
                visualization_manager.set_contrast(target_stack, vmin, vmax)
    
    @log_function
    def sync_pan(self, source_stack: str, center_x: float, center_y: float) -> None:
        """Synchronize pan position between views"""
        if not self._sync_enabled:
            return
            
        with self._lock:
            target_stack = 'stack2' if source_stack == 'stack1' else 'stack1'
            if image_loader.is_stack_loaded(target_stack):
                visualization_manager.set_view_center(target_stack, center_x, center_y)
    
    def _sync_all_views(self) -> None:
        """Synchronize all view properties"""
        if not self._sync_enabled:
            return
            
        with self._lock:
            # Use last active view as source if available
            source_stack = self._last_active_view or 'stack1'
            target_stack = 'stack2' if source_stack == 'stack1' else 'stack1'
            
            # Sync zoom
            if self._zoom_states[source_stack]['xlim'] is not None:
                self.sync_zoom(
                    source_stack,
                    self._zoom_states[source_stack]['xlim'],
                    self._zoom_states[source_stack]['ylim'],
                    self._zoom_states[source_stack]['zoom_level']
                )
            
            # Sync ROIs
            for roi in self._roi_sync[source_stack]:
                self.sync_roi(source_stack, roi)
            
            # Sync contrast
            if source_stack in self._contrast_sync:
                vmin, vmax = self._contrast_sync[source_stack]
                self.sync_contrast(source_stack, vmin, vmax)
    
    @log_function
    def set_active_view(self, stack_id: str) -> None:
        """Set the currently active view"""
        self._last_active_view = stack_id
    
    @log_function
    def clear_sync_state(self) -> None:
        """Clear all synchronization states"""
        with self._lock:
            self._zoom_states = {
                'stack1': {'xlim': None, 'ylim': None, 'zoom_level': 1.0},
                'stack2': {'xlim': None, 'ylim': None, 'zoom_level': 1.0}
            }
            self._roi_sync = {'stack1': [], 'stack2': []}
            self._contrast_sync = {}
    
    @log_function
    def get_sync_state(self) -> Dict:
        """Get current synchronization state"""
        with self._lock:
            return {
                'enabled': self._sync_enabled,
                'zoom_states': self._zoom_states.copy(),
                'roi_sync': self._roi_sync.copy(),
                'contrast_sync': self._contrast_sync.copy(),
                'last_active_view': self._last_active_view
            }
    
    @log_function
    def restore_sync_state(self, state: Dict) -> None:
        """Restore synchronization state"""
        with self._lock:
            self._sync_enabled = state.get('enabled', False)
            self._zoom_states = state.get('zoom_states', {}).copy()
            self._roi_sync = state.get('roi_sync', {}).copy()
            self._contrast_sync = state.get('contrast_sync', {}).copy()
            self._last_active_view = state.get('last_active_view')


    @log_function
    def enable(self, sync_enabled: bool) -> None:
        """Enable or disable view synchronization"""
        self.sync_enabled = sync_enabled
        
    def on_view_mode_changed(self, new_mode: ViewMode) -> None:
        """Handle view mode changes"""
        if new_mode == ViewMode.OVERLAY:
            # Temporarily disable sync in overlay mode
            self._sync_enabled = False
        elif self._sync_enabled:
            # Re-sync views when returning to split view modes
            self._sync_all_views()
            
    def register_sync_callback(self, callback: Callable) -> None:
        """
        Register a synchronization callback
        
        Args:
            callback (Callable): Callback function for view synchronization
        """
        # This is a placeholder implementation
        # You might want to store these callbacks if needed
        try:
            # Log the callback registration
            logger.logger.debug(f"Registering sync callback: {callback}")
        except Exception as e:
            logger.log_error(e, {"context": "Registering sync callback"})
    
    @log_function
    def sync_measurements(self, source_stack: str, measurement_type: str, 
                        data: Dict) -> None:
        """Synchronize measurements between views"""
        if not self._sync_enabled:
            return
            
        target_stack = 'stack2' if source_stack == 'stack1' else 'stack1'
        if image_loader.is_stack_loaded(target_stack):
            visualization_manager.add_measurement(target_stack, measurement_type, data)

# Create global synchronizer instance
view_synchronizer = ViewSynchronizer()

# Example usage:
if __name__ == "__main__":
    # Test synchronization
    view_synchronizer.sync_enabled = True
    view_synchronizer.sync_zoom('stack1', (0, 100), (0, 100), 1.5)