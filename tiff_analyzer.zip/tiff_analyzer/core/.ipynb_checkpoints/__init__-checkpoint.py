# tiff_analyzer/core/__init__.py

from typing import Optional, Dict, Any
from pathlib import Path
import threading
from ..utils.logger import logger, log_function
from ..utils.config import config_manager
from ..utils.settings import settings  # Add this import
from ..utils.events import event_manager, EventType, Event

# Import core components
from .state_manager import state_manager
from .image_loader import image_loader
from .visualization import visualization_manager
from .animation import animation_manager
from .synchronizer import view_synchronizer

class CoreManager:
    """Manages initialization and coordination of core components"""
    
    def __init__(self):
        self._initialized = False
        self._lock = threading.Lock()
        self._components = {
            'state_manager': state_manager,
            'image_loader': image_loader,
            'visualization': visualization_manager,
            'animation': animation_manager,
            'synchronizer': view_synchronizer
        }
        
        # Initialize default configuration
        self._default_config = {
            'core': {
                'cache_size': 512,
                'initial_state': None
            }
        }
        self._ensure_config()
    
    def _ensure_config(self) -> None:
        """Ensure core configuration exists"""
        try:
            # Initialize with default values if not exist
            for section, values in self._default_config.items():
                for key, value in values.items():
                    current_value = config_manager.get_config_value(section, key)
                    if current_value is None:
                        config_manager.set_config_value(section, key, value)
                        logger.logger.info(f"Set default config: {section}.{key} = {value}")
            
        except Exception as e:
            logger.log_error(e, {"context": "Ensuring core configuration"})

    @property
    def initialized(self) -> bool:
        """Getter for initialization status"""
        return self._initialized
            
    @log_function
    def initialize(self) -> bool:
        """Initialize all core components"""
        if self._initialized:
            return True
            
        try:
            with self._lock:
                logger.logger.info("Initializing core components...")
                
                # Initialize components in order
                self._init_state_manager()
                self._init_image_loader()
                self._init_visualization()
                self._init_animation()
                self._init_synchronizer()
                
                # Set up component interactions
                self._setup_component_interactions()
                
                self._initialized = True
                logger.logger.info("Core components initialized successfully")
                return True
                
        except Exception as e:
            logger.log_error(e, {"context": "Core initialization"})
            return False

            
    def _init_state_manager(self) -> None:
        """Initialize state manager"""
        try:
            initial_state = config_manager.get_config_value('core', 'initial_state')
            if initial_state:
                try:
                    # Handle string representation of state
                    if isinstance(initial_state, str):
                        import json
                        initial_state = json.loads(initial_state)
                except json.JSONDecodeError:
                    logger.logger.warning("Invalid initial state format in config")
                    initial_state = None
                    
            # Restore state if available, otherwise use defaults
            success = state_manager.restore_state(initial_state)
            if not success:
                logger.logger.info("Using default initial state")
                
        except Exception as e:
            logger.log_error(e, {"context": "State manager initialization"})
            raise
    
    def _init_image_loader(self) -> None:
        """Initialize image loader"""
        try:
            cache_size = config_manager.get_config_value('core', 'cache_size', 512)
            image_loader.set_cache_size(cache_size)
        except Exception as e:
            logger.log_error(e, {"context": "Image loader initialization"})
            raise
    
    def _init_visualization(self) -> None:
        """Initialize visualization manager"""
        try:
            # Get theme preference
            theme = settings.get('view', 'theme', 'dark')
            visualization_manager.configure_display(
                dark_mode=(theme == 'dark'),
                overlay_alpha=settings.get('view', 'overlay_alpha', 0.5)
            )
        except Exception as e:
            logger.log_error(e, {"context": "Visualization initialization"})
            raise
    
    def _init_animation(self) -> None:
        """Initialize animation manager"""
        try:
            # Default configuration if not set
            default_config = {
                'playback': {
                    'default_fps': 10,
                    'loop': True
                }
            }
            
            # Ensure default configurations exist
            for section, values in default_config.items():
                for key, value in values.items():
                    current_value = settings.get(section, key)
                    if current_value is None:
                        settings.set(section, key, value)
            
            # Retrieve settings
            fps = settings.get('playback', 'default_fps')
            loop = settings.get('playback', 'loop')
            
            # Configure animation manager
            animation_manager.configure(fps=fps, loop=loop)
        except Exception as e:
            logger.log_error(e, {"context": "Animation initialization"})
            raise
    
    def _init_synchronizer(self) -> None:
        """Initialize view synchronizer"""
        try:
            sync_enabled = settings.get('view', 'sync_views', True)
            view_synchronizer.enable(sync_enabled)
        except Exception as e:
            logger.log_error(e, {"context": "Synchronizer initialization"})
            raise
    
    def _setup_component_interactions(self) -> None:
        """Set up interactions between components"""
        # Register state change callbacks
        state_manager.add_observer('visualization', 
                                 visualization_manager.update_display)
        state_manager.add_observer('animation', 
                                 animation_manager.on_state_change)
        
        # Register synchronization callbacks
        visualization_manager.register_sync_callback(
            view_synchronizer.sync_zoom
        )
        
        # Register frame update callbacks
        animation_manager.register_frame_callback(
            'visualization',
            visualization_manager.update_display
        )
    
    def get_component(self, name: str) -> Optional[Any]:
        """Get a core component by name"""
        return self._components.get(name)
    
    def cleanup(self) -> None:
        """Shutdown core components"""
        if not self._initialized:
            return
            
        try:
            with self._lock:
                logger.logger.info("Shutting down core components...")
                
                # Stop animation
                animation_manager.stop_playback()
                
                # Clean up image loader
                image_loader.cleanup()
                
                self._initialized = False
                logger.logger.info("Core components shut down successfully")
                
        except Exception as e:
            logger.log_error(e, {"context": "Core shutdown"})
            raise

# Create global core manager instance
core_manager = CoreManager()

# Export components
__all__ = [
    'core_manager',
    'state_manager',
    'image_loader',
    'visualization_manager',
    'animation_manager',
    'view_synchronizer'
]