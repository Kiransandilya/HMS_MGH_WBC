# tiff_analyzer/tests/test_data.py

import numpy as np
from pathlib import Path
import tifffile
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from ..utils.logger import logger, log_function

@dataclass
class TestDataConfig:
    """Configuration for test data generation"""
    stack_size: Tuple[int, int] = (100, 100)
    num_frames: int = 10
    wbc_count: int = 3
    noise_level: float = 0.1
    intensity_range: Tuple[int, int] = (0, 255)

class TestDataGenerator:
    """Generates test data for WBC analysis"""
    
    def __init__(self, config: Optional[TestDataConfig] = None):
        self.config = config or TestDataConfig()
        self.test_data_dir = Path(__file__).parent / 'test_data'
        self.test_data_dir.mkdir(exist_ok=True)
    
    @log_function
    def generate_wbc_stack(self, save: bool = True) -> np.ndarray:
        """Generate stack with WBC-like objects"""
        stack = np.zeros((self.config.num_frames, 
                         *self.config.stack_size), 
                        dtype=np.uint8)
        
        for frame in range(self.config.num_frames):
            # Create background with noise
            background = np.random.normal(
                loc=20,
                scale=self.config.noise_level * 255,
                size=self.config.stack_size
            ).astype(np.uint8)
            
            # Add WBC-like objects
            for _ in range(self.config.wbc_count):
                x = np.random.randint(20, self.config.stack_size[0]-20)
                y = np.random.randint(20, self.config.stack_size[1]-20)
                
                # Create cell membrane
                radius = np.random.randint(10, 15)
                y_grid, x_grid = np.ogrid[-radius:radius+1, -radius:radius+1]
                mask = x_grid**2 + y_grid**2 <= radius**2
                
                # Add to appropriate position in image
                y_indices = slice(max(0, y-radius), min(self.config.stack_size[0], y+radius+1))
                x_indices = slice(max(0, x-radius), min(self.config.stack_size[1], x+radius+1))
                
                mask_part = mask[
                    max(0, -(y-radius)):min(mask.shape[0], self.config.stack_size[0]-(y-radius)),
                    max(0, -(x-radius)):min(mask.shape[1], self.config.stack_size[1]-(x-radius))
                ]
                
                background[y_indices, x_indices][mask_part] = np.random.randint(150, 200)
                
                # Add nucleus
                nucleus_radius = int(radius * 0.4)
                y_grid, x_grid = np.ogrid[-nucleus_radius:nucleus_radius+1, -nucleus_radius:nucleus_radius+1]
                nucleus_mask = x_grid**2 + y_grid**2 <= nucleus_radius**2
                
                y_indices = slice(max(0, y-nucleus_radius), min(self.config.stack_size[0], y+nucleus_radius+1))
                x_indices = slice(max(0, x-nucleus_radius), min(self.config.stack_size[1], x+nucleus_radius+1))
                
                mask_part = nucleus_mask[
                    max(0, -(y-nucleus_radius)):min(nucleus_mask.shape[0], self.config.stack_size[0]-(y-nucleus_radius)),
                    max(0, -(x-nucleus_radius)):min(nucleus_mask.shape[1], self.config.stack_size[1]-(x-nucleus_radius))
                ]
                
                background[y_indices, x_indices][mask_part] = np.random.randint(200, 250)
            
            stack[frame] = background
        
        if save:
            self._save_stack(stack)
        
        return stack
    
    @log_function
    def generate_test_stack(self, pattern: str = 'gradient', save: bool = True) -> np.ndarray:
        """Generate test stack with specified pattern"""
        stack = np.zeros((self.config.num_frames, 
                         *self.config.stack_size), 
                        dtype=np.uint8)
        
        if pattern == 'gradient':
            for frame in range(self.config.num_frames):
                x = np.linspace(0, 255, self.config.stack_size[0])
                y = np.linspace(0, 255, self.config.stack_size[1])
                X, Y = np.meshgrid(x, y)
                stack[frame] = (X + Y) / 2
                
        elif pattern == 'random':
            stack = np.random.randint(
                self.config.intensity_range[0],
                self.config.intensity_range[1],
                (self.config.num_frames, *self.config.stack_size),
                dtype=np.uint8
            )
        
        if save:
            self._save_stack(stack, suffix=pattern)
        
        return stack
    
    def _save_stack(self, stack: np.ndarray, suffix: str = 'wbc') -> Path:
        """Save stack to file"""
        filename = f"test_stack_{suffix}.tif"
        filepath = self.test_data_dir / filename
        tifffile.imwrite(str(filepath), stack)
        return filepath
    
    @log_function
    def generate_test_dataset(self) -> Dict[str, Path]:
        """Generate complete test dataset"""
        dataset = {}
        
        # Generate WBC stack
        wbc_stack = self.generate_wbc_stack()
        dataset['wbc'] = self._save_stack(wbc_stack, 'wbc')
        
        # Generate gradient stack
        gradient_stack = self.generate_test_stack(pattern='gradient')
        dataset['gradient'] = self._save_stack(gradient_stack, 'gradient')
        
        # Generate random stack
        random_stack = self.generate_test_stack(pattern='random')
        dataset['random'] = self._save_stack(random_stack, 'random')
        
        return dataset
    
    @staticmethod
    def verify_test_data(data_path: Path) -> bool:
        """Verify test data integrity"""
        try:
            with tifffile.TiffFile(str(data_path)) as tif:
                # Check basic properties
                if not tif.pages:
                    return False
                
                # Verify consistency
                first_shape = tif.pages[0].shape
                return all(page.shape == first_shape for page in tif.pages)
                
        except Exception as e:
            logger.log_error(e, {
                "context": "Test data verification",
                "path": str(data_path)
            })
            return False

# Create global test data generator instance
test_data_generator = TestDataGenerator()

if __name__ == '__main__':
    # Generate test dataset
    dataset = test_data_generator.generate_test_dataset()
    print("Generated test dataset:")
    for key, path in dataset.items():
        print(f"{key}: {path}")