# tiff_analyzer/tests/test_integration.py

import unittest
import tkinter as tk
from pathlib import Path
import numpy as np
import time
from ..tests.test_utils import BaseTest
from ..ui import ui_manager
from ..core import core_manager
from ..core.state_manager import state_manager
from ..utils.events import event_manager, EventType

class TestUICoreCommunication(BaseTest):
    """Test communication between UI and core components"""
    
    def setUp(self):
        super().setUp()
        self.root = tk.Tk()
        self.logger.info("Setting up UI and core components")
        core_manager.initialize()
        ui_manager.initialize(self.root)
        
    def tearDown(self):
        if self.root:
            self.root.destroy()
        super().tearDown()
    
    def test_state_ui_sync(self):
        """Test state changes reflect in UI"""
        self.logger.info("Testing state-UI synchronization")
        
        # Update state
        test_states = [
            ('view_mode', 'overlay'),
            ('current_frame', 5),
            ('zoom_level', 1.5)
        ]
        
        for state_key, state_value in test_states:
            # Log initial state
            self.logger.info(f"Testing state change: {state_key} = {state_value}")
            
            # Update state
            state_manager.update_state(**{state_key: state_value})
            self.root.update()
            
            # Verify UI reflection
            ui_state = ui_manager.get_current_ui_state()
            self.assertEqual(
                ui_state.get(state_key),
                state_value,
                f"UI not reflecting state change for {state_key}"
            )
    
    def test_ui_state_sync(self):
        """Test UI actions update state"""
        self.logger.info("Testing UI-state synchronization")
        
        # Simulate UI actions
        main_window = ui_manager.get_component('main_window')
        toolbar = ui_manager.get_component('toolbar')
        
        # Test view mode change
        toolbar._set_view_mode('overlay')
        self.root.update()
        
        current_state = state_manager.get_state()
        self.assertEqual(
            current_state.view_mode,
            'overlay',
            "State not updated from UI action"
        )

class TestFileOperations(BaseTest):
    """Test file operations integration"""
    
    def setUp(self):
        super().setUp()
        self.root = tk.Tk()
        self.test_data_dir = Path(__file__).parent / 'test_data'
        self.test_data_dir.mkdir(exist_ok=True)
        
        core_manager.initialize()
        ui_manager.initialize(self.root)
        
    def tearDown(self):
        if self.root:
            self.root.destroy()
        super().tearDown()
    
    def test_file_loading(self):
        """Test file loading through UI"""
        self.logger.info("Testing file loading integration")
        
        # Create test TIFF file
        test_stack = np.random.randint(0, 255, (10, 100, 100), dtype=np.uint8)
        test_file = self.test_data_dir / 'test_stack.tif'
        
        import tifffile
        tifffile.imwrite(str(test_file), test_stack)
        
        # Simulate file loading through UI
        events = []
        def event_collector(event):
            events.append(event)
        
        event_manager.subscribe(EventType.FILE_LOADED, event_collector)
        
        # Trigger file load
        ui_manager.load_file(str(test_file))
        self.root.update()
        
        # Verify loading reflected in both UI and core
        self.assertTrue(
            any(e.type == EventType.FILE_LOADED for e in events),
            "File load event not triggered"
        )
        self.assertTrue(
            core_manager.get_component('image_loader').is_stack_loaded('stack1'),
            "Stack not loaded in core"
        )

class TestAnalysisIntegration(BaseTest):
    """Test analysis feature integration"""
    
    def setUp(self):
        super().setUp()
        self.root = tk.Tk()
        core_manager.initialize()
        ui_manager.initialize(self.root)
        
    def tearDown(self):
        if self.root:
            self.root.destroy()
        super().tearDown()
    
    def test_roi_analysis(self):
        """Test ROI analysis integration"""
        self.logger.info("Testing ROI analysis integration")
        
        # Create test image
        test_image = np.random.randint(0, 255, (100, 100), dtype=np.uint8)
        
        # Simulate ROI selection through UI
        roi_coords = [(10, 10), (50, 50)]
        events = []
        
        def event_collector(event):
            events.append(event)
        
        event_manager.subscribe(EventType.ROI_CREATED, event_collector)
        
        # Create ROI through UI
        ui_manager.create_roi('rectangle', roi_coords)
        self.root.update()
        
        # Verify ROI creation and analysis
        self.assertTrue(
            any(e.type == EventType.ROI_CREATED for e in events),
            "ROI creation event not triggered"
        )
        self.assertTrue(
            any(e.type == EventType.ANALYSIS_COMPLETED for e in events),
            "Analysis not triggered for ROI"
        )

def run_integration_tests():
    """Run all integration tests"""
    test_classes = [
        TestUICoreCommunication,
        TestFileOperations,
        TestAnalysisIntegration
    ]
    
    suite = unittest.TestSuite()
    for test_class in test_classes:
        suite.addTests(unittest.TestLoader().loadTestsFromTestCase(test_class))
    
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite)

if __name__ == '__main__':
    run_integration_tests()