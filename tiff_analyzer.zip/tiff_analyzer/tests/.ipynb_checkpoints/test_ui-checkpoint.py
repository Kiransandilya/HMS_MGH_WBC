# tiff_analyzer/tests/test_ui.py

import unittest
import tkinter as tk
from tkinter import ttk
import time
from pathlib import Path
from ..tests.test_utils import BaseTest
from ..ui import ui_manager
from ..ui.main_window import MainWindow
from ..ui.toolbar import Toolbar
from ..ui.controls import Controls
from ..core.state_manager import state_manager

class TestUIManager(BaseTest):
    """Test UI manager initialization and management"""
    
    def setUp(self):
        super().setUp()
        self.root = tk.Tk()
        self.logger.info(f"Created root window with ID: {self.root.winfo_id()}")
    
    def tearDown(self):
        if self.root:
            self.logger.info(f"Destroying root window with ID: {self.root.winfo_id()}")
            self.root.destroy()
        super().tearDown()
    
    def test_ui_initialization(self):
        """Test UI initialization sequence"""
        self.logger.info("Testing UI initialization")
        
        # Test initial UI manager state
        self.assertFalse(ui_manager._initialized, "UI manager incorrectly marked as initialized")
        
        # Initialize UI
        result = ui_manager.initialize(self.root)
        self.assertTrue(result, "UI initialization failed")
        self.assertTrue(ui_manager._initialized, "UI manager not marked as initialized")
        
        # Verify components
        self.assertIsNotNone(ui_manager._components.get('main_window'), "Main window not created")
        self.assertIsNotNone(ui_manager._components.get('toolbar'), "Toolbar not created")
        self.assertIsNotNone(ui_manager._components.get('controls'), "Controls not created")
    
    def test_window_visibility(self):
        """Test window visibility and geometry"""
        self.logger.info("Testing window visibility")
        
        # Initialize UI
        ui_manager.initialize(self.root)
        
        # Force window update
        self.root.update_idletasks()
        self.root.update()
        
        # Log window state
        self.logger.info(f"Window geometry: {self.root.geometry()}")
        self.logger.info(f"Window state: {self.root.state()}")
        self.logger.info(f"Window visible: {self.root.winfo_viewable()}")
        self.logger.info(f"Window width: {self.root.winfo_width()}")
        self.logger.info(f"Window height: {self.root.winfo_height()}")
        
        # Verify window properties
        self.assertTrue(self.root.winfo_exists(), "Window does not exist")
        self.assertTrue(self.root.winfo_viewable(), "Window not visible")
        self.assertGreater(self.root.winfo_width(), 0, "Window has zero width")
        self.assertGreater(self.root.winfo_height(), 0, "Window has zero height")

class TestMainWindow(BaseTest):
    """Test main window functionality"""
    
    def setUp(self):
        super().setUp()
        self.root = tk.Tk()
        self.main_window = MainWindow(self.root)
    
    def tearDown(self):
        if self.root:
            self.root.destroy()
        super().tearDown()
    
    def test_layout_creation(self):
        """Test layout creation"""
        self.logger.info("Testing layout creation")
        
        # Verify frames exist
        self.assertTrue(hasattr(self.main_window, '_frames'), "Frames dict not created")
        
        required_frames = ['toolbar', 'main', 'controls', 'status']
        for frame in required_frames:
            self.assertIn(frame, self.main_window._frames, f"{frame} frame not created")
            self.assertTrue(
                isinstance(self.main_window._frames[frame], ttk.Frame),
                f"{frame} frame is not a ttk.Frame"
            )
    
    def test_view_modes(self):
        """Test view mode switching"""
        self.logger.info("Testing view mode switching")
        
        # Test each view mode
        view_modes = ['side_by_side', 'overlay', 'top_bottom']
        for mode in view_modes:
            self.main_window.set_view_mode(mode)
            self.root.update()
            
            # Verify mode switch
            visible_frame = next(
                (frame for frame in self.main_window._frames.values() 
                 if frame.winfo_viewable()),
                None
            )
            self.assertIsNotNone(visible_frame, f"No visible frame in {mode} mode")

class TestToolbar(BaseTest):
    """Test toolbar functionality"""
    
    def setUp(self):
        super().setUp()
        self.root = tk.Tk()
        self.frame = ttk.Frame(self.root)
        self.frame.pack(fill=tk.BOTH, expand=True)
        self.toolbar = Toolbar(self.frame)
    
    def tearDown(self):
        if self.root:
            self.root.destroy()
        super().tearDown()
    
    def test_button_creation(self):
        """Test button creation"""
        self.logger.info("Testing button creation")
        
        # Verify buttons exist
        required_buttons = ['open1', 'open2', 'save', 'theme', 'settings']
        for btn in required_buttons:
            self.assertIn(btn, self.toolbar._buttons, f"{btn} button not created")
            self.assertTrue(
                isinstance(self.toolbar._buttons[btn], ttk.Button),
                f"{btn} is not a ttk.Button"
            )
    
    def test_tool_panels(self):
        """Test tool panel functionality"""
        self.logger.info("Testing tool panels")
        
        # Test tool selection
        tools = ['zoom', 'roi_rect', 'measure']
        for tool in tools:
            self.toolbar._select_tool(tool)
            self.root.update()
            
            # Verify tool panel visibility
            self.assertEqual(
                self.toolbar._current_tool,
                tool,
                f"Tool {tool} not selected"
            )
            
            if tool in self.toolbar._tools:
                self.assertTrue(
                    self.toolbar._tools[tool].winfo_viewable(),
                    f"Tool panel for {tool} not visible"
                )

class TestControls(BaseTest):
    """Test controls functionality"""
    
    def setUp(self):
        super().setUp()
        self.root = tk.Tk()
        self.frame = ttk.Frame(self.root)
        self.frame.pack(fill=tk.BOTH, expand=True)
        self.controls = Controls(self.frame)
    
    def tearDown(self):
        if self.root:
            self.root.destroy()
        super().tearDown()
    
    def test_playback_controls(self):
        """Test playback controls"""
        self.logger.info("Testing playback controls")
        
        # Verify controls exist
        required_controls = ['play', 'stop', 'frame_slider']
        for control in required_controls:
            self.assertIn(
                control,
                self.controls._controls,
                f"{control} control not created"
            )
    
    def test_frame_navigation(self):
        """Test frame navigation"""
        self.logger.info("Testing frame navigation")
        
        # Test frame changes
        test_frames = [0, 5, 10]
        for frame in test_frames:
            self.controls._frame_var.set(frame)
            self.root.update()
            
            current_frame = state_manager.get_state().current_frame
            self.assertEqual(
                current_frame,
                frame,
                f"Frame navigation failed: expected {frame}, got {current_frame}"
            )

def run_ui_tests():
    """Run all UI component tests"""
    test_classes = [
        TestUIManager,
        TestMainWindow,
        TestToolbar,
        TestControls
    ]
    
    suite = unittest.TestSuite()
    for test_class in test_classes:
        suite.addTests(unittest.TestLoader().loadTestsFromTestCase(test_class))
    
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite)

if __name__ == '__main__':
    run_ui_tests()