# tiff_analyzer/tests/run_tests.py

import unittest
import sys
import os
from datetime import datetime
from pathlib import Path
import logging
import json
from typing import Dict, Any

# Import test suites
from .test_utils import BaseTest
from .test_core import TestCoreManager, TestStateManager, TestImageLoader, TestVisualization, TestAnimation, TestSynchronizer
from .test_ui import TestUIManager, TestMainWindow, TestToolbar, TestControls
from .test_integration import TestUICoreCommunication, TestFileOperations, TestAnalysisIntegration

class TestRunner:
    """Manages test execution and reporting"""
    
    def __init__(self):
        self.test_dir = Path(__file__).parent
        self.log_dir = self.test_dir / 'logs'
        self.log_dir.mkdir(exist_ok=True)
        
        self.timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.setup_logging()
        
        self.results = {
            'core': {},
            'ui': {},
            'integration': {}
        }
    
    def setup_logging(self) -> None:
        """Setup test logging"""
        # Main log file
        log_file = self.log_dir / f'test_run_{self.timestamp}.log'
        
        # Configure logging
        logging.basicConfig(
            level=logging.DEBUG,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler(sys.stdout)
            ]
        )
        
        self.logger = logging.getLogger('TestRunner')
        self.logger.info(f"Test run started at {self.timestamp}")
    
    def run_test_suite(self, suite_name: str, test_cases: list) -> None:
        """Run a test suite and collect results"""
        self.logger.info(f"Running {suite_name} tests")
        
        suite = unittest.TestSuite()
        for test_case in test_cases:
            suite.addTests(unittest.TestLoader().loadTestsFromTestCase(test_case))
        
        # Create separate log file for suite
        suite_log = self.log_dir / f'{suite_name.lower()}_{self.timestamp}.log'
        with open(suite_log, 'w') as f:
            runner = unittest.TextTestRunner(
                stream=f,
                verbosity=2,
                descriptions=True
            )
            result = runner.run(suite)
            
            # Store results
            self.results[suite_name.lower()] = {
                'total': result.testsRun,
                'failures': len(result.failures),
                'errors': len(result.errors),
                'skipped': len(result.skipped),
                'success': result.wasSuccessful()
            }
    
    def generate_report(self) -> None:
        """Generate test report"""
        report_file = self.log_dir / f'test_report_{self.timestamp}.json'
        
        report = {
            'timestamp': self.timestamp,
            'results': self.results,
            'summary': {
                'total_tests': sum(r['total'] for r in self.results.values()),
                'total_failures': sum(r['failures'] for r in self.results.values()),
                'total_errors': sum(r['errors'] for r in self.results.values()),
                'total_skipped': sum(r['skipped'] for r in self.results.values()),
                'all_successful': all(r['success'] for r in self.results.values())
            }
        }
        
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        self.logger.info(f"Test report generated: {report_file}")
        
        # Log summary
        self.logger.info("Test Run Summary:")
        self.logger.info(f"Total Tests: {report['summary']['total_tests']}")
        self.logger.info(f"Failures: {report['summary']['total_failures']}")
        self.logger.info(f"Errors: {report['summary']['total_errors']}")
        self.logger.info(f"Skipped: {report['summary']['total_skipped']}")
        self.logger.info(f"All Successful: {report['summary']['all_successful']}")
    
    def run_all_tests(self) -> None:
        """Run all test suites"""
        try:
            # Run core tests
            self.run_test_suite('Core', [
                TestCoreManager,
                TestStateManager,
                TestImageLoader,
                TestVisualization,
                TestAnimation,
                TestSynchronizer
            ])
            
            # Run UI tests
            self.run_test_suite('UI', [
                TestUIManager,
                TestMainWindow,
                TestToolbar,
                TestControls
            ])
            
            # Run integration tests
            self.run_test_suite('Integration', [
                TestUICoreCommunication,
                TestFileOperations,
                TestAnalysisIntegration
            ])
            
            # Generate report
            self.generate_report()
            
        except Exception as e:
            self.logger.error(f"Error during test execution: {str(e)}", exc_info=True)
            raise
        finally:
            self.logger.info("Test run completed")

def main():
    """Main entry point for running tests"""
    runner = TestRunner()
    runner.run_all_tests()

if __name__ == '__main__':
    main()