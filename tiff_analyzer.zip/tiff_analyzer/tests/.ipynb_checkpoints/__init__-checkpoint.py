# tiff_analyzer/tests/__init__.py

import os
import logging
from datetime import datetime
from pathlib import Path

# Configure test logging
TEST_LOG_DIR = Path(__file__).parent / 'logs'
TEST_LOG_DIR.mkdir(exist_ok=True)

def setup_test_logging():
    """Setup logging for tests"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = TEST_LOG_DIR / f'test_run_{timestamp}.log'
    
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler()
        ]
    )
    return log_file

# Setup test logging
current_log_file = setup_test_logging()