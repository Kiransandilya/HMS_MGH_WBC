# tiff_analyzer/tests/test_core.py

import unittest
import tkinter as tk
import numpy as np
from pathlib import Path
from ..tests.test_utils import BaseTest
from ..core import core_manager
from ..core.state_manager import state_manager
from ..core.image_loader import image_loader
from ..core.visualization import visualization_manager
from ..core.animation import animation_manager
from ..core.synchronizer import view_synchronizer

class TestCoreManager(BaseTest):
    """Test core manager initialization and management"""
    
    def test_initialization(self):
        """Test core manager initialization"""
        self.logger.info("Testing core manager initialization")
        result = core_manager.initialize()
        self.assertTrue(result, "Core manager initialization failed")
        self.assertTrue(core_manager.initialized, "Core manager not marked as initialized")
    
    def test_component_access(self):
        """Test core component access"""
        self.logger.info("Testing core component access")
        components = [
            'state_manager',
            'image_loader',
            'visualization',
            'animation',
            'synchronizer'
        ]
        for component in components:
            self.assertIsNotNone(
                core_manager.get_component(component),
                f"Component {component} not accessible"
            )

class TestStateManager(BaseTest):
    """Test state management functionality"""
    
    def setUp(self):
        super().setUp()
        self.test_state = {
            'current_frame': 0,
            'view_mode': 'side_by_side',
            'zoom_level': 1.0
        }
    
    def test_state_update(self):
        """Test state updates"""
        self.logger.info("Testing state updates")
        state_manager.update_state(**self.test_state)
        current_state = state_manager.get_state()
        for key, value in self.test_state.items():
            self.assertEqual(
                getattr(current_state, key),
                value,
                f"State mismatch for {key}"
            )
    
    def test_state_observation(self):
        """Test state observation"""
        self.logger.info("Testing state observation")
        observed_states = []
        
        def observer(state):
            observed_states.append(state)
        
        # Use valid state attributes instead of test_value
        state_manager.add_observer('test', observer)
        state_manager.update_state(current_frame=0)  # Use a valid state attribute
        
        self.assertEqual(len(observed_states), 1, "Observer not called")
        self.assertTrue(hasattr(observed_states[0], 'current_frame'))

class TestImageLoader(BaseTest):
    """Test image loading functionality"""
    
    def setUp(self):
        super().setUp()
        self.test_data_dir = Path(__file__).parent / 'test_data'
        self.test_data_dir.mkdir(exist_ok=True)
        self.test_stack = self.create_test_stack()
    
    def test_stack_loading(self):
        """Test stack loading"""
        self.logger.info("Testing stack loading")
        test_file = self.test_data_dir / 'test_stack.tif'
        
        # Save test stack
        import tifffile
        tifffile.imwrite(str(test_file), self.test_stack)
        
        # Test loading
        result = image_loader.load_stack('test', str(test_file))
        self.assertTrue(result, "Stack loading failed")
        self.assertTrue(
            image_loader.is_stack_loaded('test'),
            "Stack not marked as loaded"
        )
        
        # Test frame access
        frame = image_loader.get_frame('test', 0)
        self.assertIsNotNone(frame, "Frame access failed")
        np.testing.assert_array_equal(
            frame,
            self.test_stack[0],
            "Frame content mismatch"
        )

class TestVisualization(BaseTest):
    """Test visualization functionality"""
    
    def setUp(self):
        super().setUp()
        self.root = tk.Tk()
        self.test_image = self.create_test_image()
    
    def tearDown(self):
        super().tearDown()
        if self.root:
            self.root.destroy()
    
    def test_display_initialization(self):
        """Test display initialization"""
        self.logger.info("Testing display initialization")
        visualization_manager.initialize_display(self.root)
        self.assertTrue(
            hasattr(visualization_manager, 'canvas'),
            "Display not initialized"
        )
    
    def test_image_display(self):
        """Test image display"""
        self.logger.info("Testing image display")
        visualization_manager.initialize_display(self.root)
        visualization_manager.display_frame(self.test_image)
        
        # Verify display update
        self.root.update()
        self.assertTrue(
            visualization_manager.canvas.get_tk_widget().winfo_viewable(),
            "Display not visible"
        )

class TestAnimation(BaseTest):
    """Test animation functionality"""
    
    def test_playback_control(self):
        """Test playback controls"""
        self.logger.info("Testing playback controls")
        
        # Test play/pause
        animation_manager.start_playback()
        self.assertTrue(animation_manager._is_playing, "Playback not started")
        
        animation_manager.pause_playback()
        self.assertFalse(animation_manager._is_playing, "Playback not paused")
        
        # Test frame navigation
        animation_manager.next_frame()
        self.assertEqual(
            animation_manager._current_frame,
            1,
            "Frame navigation failed"
        )

class TestSynchronizer(BaseTest):
    """Test view synchronization"""
    
    def test_sync_control(self):
        """Test synchronization controls"""
        self.logger.info("Testing synchronization")
        
        # Test sync enable/disable
        view_synchronizer.sync_enabled = True
        self.assertTrue(
            view_synchronizer.sync_enabled,
            "Sync not enabled"
        )
        
        view_synchronizer.sync_enabled = False
        self.assertFalse(
            view_synchronizer.sync_enabled,
            "Sync not disabled"
        )

def run_core_tests():
    """Run all core component tests"""
    test_classes = [
        TestCoreManager,
        TestStateManager,
        TestImageLoader,
        TestVisualization,
        TestAnimation,
        TestSynchronizer
    ]
    
    suite = unittest.TestSuite()
    for test_class in test_classes:
        suite.addTests(unittest.TestLoader().loadTestsFromTestCase(test_class))
    
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite)

if __name__ == '__main__':
    run_core_tests()