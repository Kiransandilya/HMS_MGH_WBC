# tiff_analyzer/tests/data_generator.py

import numpy as np
from pathlib import Path
import tifffile
import json
from datetime import datetime
from typing import Dict, Any, List, Tuple

class TestDataGenerator:
    """Generates test data for TIFF analyzer testing"""
    
    def __init__(self):
        self.test_data_dir = Path(__file__).parent / 'test_data'
        self.test_data_dir.mkdir(exist_ok=True)
    
    def generate_tiff_stack(self, 
                           frames: int = 10, 
                           size: Tuple[int, int] = (100, 100),
                           pattern: str = 'random') -> Path:
        """Generate test TIFF stack"""
        if pattern == 'random':
            stack = np.random.randint(0, 255, (frames, *size), dtype=np.uint8)
        elif pattern == 'wbc':
            stack = self._generate_wbc_pattern(frames, size)
        else:
            stack = self._generate_gradient_pattern(frames, size)
        
        # Save stack
        filename = f"test_stack_{pattern}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.tif"
        filepath = self.test_data_dir / filename
        tifffile.imwrite(str(filepath), stack)
        
        return filepath
    
    def _generate_wbc_pattern(self, frames: int, 
                            size: Tuple[int, int]) -> np.ndarray:
        """Generate WBC-like patterns"""
        stack = np.zeros((frames, *size), dtype=np.uint8)
        
        for frame in range(frames):
            # Create background
            background = np.random.randint(20, 50, size, dtype=np.uint8)
            
            # Add cell-like structures
            num_cells = np.random.randint(1, 4)
            for _ in range(num_cells):
                cx = np.random.randint(30, size[0]-30)
                cy = np.random.randint(30, size[1]-30)
                r_nucleus = np.random.randint(5, 10)
                r_cell = np.random.randint(15, 25)
                
                # Create cell membrane
                y, x = np.ogrid[-cy:size[0]-cy, -cx:size[1]-cx]
                cell_mask = x*x + y*y <= r_cell*r_cell
                background[cell_mask] = np.random.randint(100, 150)
                
                # Create nucleus
                nucleus_mask = x*x + y*y <= r_nucleus*r_nucleus
                background[nucleus_mask] = np.random.randint(180, 250)
            
            stack[frame] = background
        
        return stack
    
    def _generate_gradient_pattern(self, frames: int, 
                                 size: Tuple[int, int]) -> np.ndarray:
        """Generate gradient patterns"""
        stack = np.zeros((frames, *size), dtype=np.uint8)
        
        for frame in range(frames):
            x = np.linspace(0, 255, size[0])
            y = np.linspace(0, 255, size[1])
            X, Y = np.meshgrid(x, y)
            gradient = np.sin(2 * np.pi * frame / frames) * X + \
                      np.cos(2 * np.pi * frame / frames) * Y
            stack[frame] = gradient.astype(np.uint8)
        
        return stack
    
    def generate_test_dataset(self) -> Dict[str, Path]:
        """Generate complete test dataset"""
        dataset = {}
        
        # Generate different types of stacks
        patterns = ['random', 'wbc', 'gradient']
        sizes = [(100, 100), (200, 200)]
        frames = [10, 20]
        
        for pattern in patterns:
            for size in sizes:
                for frame_count in frames:
                    key = f"{pattern}_{size[0]}x{size[1]}_{frame_count}frames"
                    dataset[key] = self.generate_tiff_stack(
                        frames=frame_count,
                        size=size,
                        pattern=pattern
                    )
        
        # Save dataset metadata
        metadata = {
            'generated_at': datetime.now().isoformat(),
            'files': {k: str(v) for k, v in dataset.items()}
        }
        
        metadata_file = self.test_data_dir / 'dataset_metadata.json'
        with open(metadata_file, 'w') as f:
            json.dump(metadata, f, indent=2)
        
        return dataset

def generate_test_data():
    """Generate test data for all tests"""
    generator = TestDataGenerator()
    return generator.generate_test_dataset()

if __name__ == '__main__':
    generate_test_data()