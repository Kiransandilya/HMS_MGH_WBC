# tiff_analyzer/tests/test_utils.py

import unittest
import logging
from pathlib import Path
import numpy as np

class BaseTest(unittest.TestCase):
    """Base test class with common utilities"""
    
    @classmethod
    def setUpClass(cls):
        cls.logger = logging.getLogger(cls.__name__)
        cls.logger.info(f"Starting {cls.__name__} tests")
        
    def setUp(self):
        self.logger.info(f"Setting up {self._testMethodName}")
        
    def tearDown(self):
        self.logger.info(f"Tearing down {self._testMethodName}")
    
    @classmethod
    def tearDownClass(cls):
        cls.logger.info(f"Completed {cls.__name__} tests")
    
    def create_test_image(self, size=(100, 100)) -> np.ndarray:
        """Create test image"""
        return np.random.randint(0, 255, size, dtype=np.uint8)
    
    def create_test_stack(self, frames=10, size=(100, 100)) -> np.ndarray:
        """Create test image stack"""
        return np.random.randint(0, 255, (frames, *size), dtype=np.uint8)

# Test fixtures
def create_test_data_dir():
    """Create test data directory"""
    test_data_dir = Path(__file__).parent / 'test_data'
    test_data_dir.mkdir(exist_ok=True)
    return test_data_dir