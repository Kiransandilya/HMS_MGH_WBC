import json
import os
from pathlib import Path
from typing import Any, Dict, Optional
from dataclasses import dataclass, asdict
import yaml
from .logger import logger, log_function
import configparser



@dataclass
class ViewConfig:
    dark_mode: bool = True
    show_toolbar: bool = True
    default_view: str = "side_by_side"
    window_size: tuple = (1200, 800)
    zoom_sensitivity: float = 1.0
    sync_views: bool = True

@dataclass
class AnalysisConfig:
    default_roi_tool: str = "rectangle"
    auto_contrast: bool = True
    feature_extraction_level: str = "basic"
    save_analysis_results: bool = True
    wbc_analysis_enabled: bool = True
    measurement_units: str = "pixels"

@dataclass
class PlaybackConfig:
    default_fps: int = 10
    max_fps: int = 60
    autoplay: bool = False
    loop_playback: bool = True
    frame_interpolation: bool = False



class ConfigManager:
    """Manages application configuration"""
    
    def __init__(self):
        """Initialize configuration manager"""
        self._config = configparser.ConfigParser()
        self._config_dir = Path(__file__).parent.parent / 'config'
        self._config_file = self._config_dir / 'config.ini'
        self._defaults = {
            'core': {
                'cache_size': '512',
                'initial_state': 'None'
            },
            'view': {
                'theme': 'light',
                'overlay_alpha': '0.5',
                'sync_views': 'true'
            },
            'plugins': {
                'configs': '{}'
            },
            'ui': {
                'save_state': 'true',
                'window_geometry': '800x600'
            },
            'features': {
                'tiff_support': 'true',
                'numpy_support': 'true'
            },
            'analysis': {
                'default_mode': 'basic',
                'roi_types': 'rectangle,ellipse',
                'measurement_types': 'distance,area,intensity'
            },
            'playback': {
                'default_fps': '30',
                'loop_playback': 'true'
            }
        }
        self._load_config()

    @property
    def config_dir(self) -> Path:
        """Get configuration directory path"""
        return self._config_dir
    
    def _load_config(self) -> None:
        """Load configuration from file"""
        try:
            if self._config_file.exists():
                self._config.read(self._config_file)
                logger.logger.info(f"Configuration loaded from {self._config_file}")
            else:
                self._create_default_config()
                logger.logger.info("Created default configuration")
        except Exception as e:
            logger.log_error(e, {"context": "Loading configuration"})
            self._create_default_config()
    
    def _create_default_config(self) -> None:
        """Create default configuration"""
        try:
            for section, values in self._defaults.items():
                if not self._config.has_section(section):
                    self._config.add_section(section)
                for key, value in values.items():
                    self._config.set(section, key, value)
            
            # Ensure config directory exists
            os.makedirs(self._config_dir, exist_ok=True)
            
            # Save default config
            with open(self._config_file, 'w') as configfile:
                self._config.write(configfile)
                
            logger.logger.info("Default configuration created successfully")
        except Exception as e:
            logger.log_error(e, {"context": "Creating default configuration"})
    
    def get_config_value(self, section: str, key: str, default: Any = None) -> Any:
        """Get configuration value"""
        try:
            if self._config.has_option(section, key):
                return self._config.get(section, key)
            
            # If section/key doesn't exist, try to create with default
            if default is not None:
                self.set_config_value(section, key, default)
                return default
                
            # If no default provided, check defaults dictionary
            if section in self._defaults and key in self._defaults[section]:
                default_value = self._defaults[section][key]
                self.set_config_value(section, key, default_value)
                return default_value
            
            logger.log_error(ValueError(f"Invalid config section or key: {section}.{key}"), 
                           {"context": "Getting configuration value"})
            return default
            
        except Exception as e:
            logger.log_error(e, {"context": f"Getting config value: {section}.{key}"})
            return default
    
    def set_config_value(self, section: str, key: str, value: Any) -> bool:
        """Set configuration value"""
        try:
            if not self._config.has_section(section):
                self._config.add_section(section)
            
            self._config.set(section, key, str(value))
            
            with open(self._config_file, 'w') as configfile:
                self._config.write(configfile)
            
            logger.logger.debug(f"Set config: {section}.{key} = {value}")
            return True
            
        except Exception as e:
            logger.log_error(e, {"context": f"Setting config value: {section}.{key}"})
            return False
    
    def get_section(self, section: str) -> Dict[str, str]:
        """Get all key-value pairs in a section"""
        try:
            if self._config.has_section(section):
                return dict(self._config.items(section))
            return {}
        except Exception as e:
            logger.log_error(e, {"context": f"Getting config section: {section}"})
            return {}
    
    def save(self) -> bool:
        """Save current configuration to file"""
        try:
            with open(self._config_file, 'w') as configfile:
                self._config.write(configfile)
            logger.logger.info("Configuration saved successfully")
            return True
        except Exception as e:
            logger.log_error(e, {"context": "Saving configuration"})
            return False


# Create a global config instance
config_manager = ConfigManager()

# Example usage:
if __name__ == "__main__":
    # Test configuration management
    print("Current FPS:", config_manager.get_config_value('playback', 'default_fps'))
    config_manager.set_config_value('playback', 'default_fps', 15)
    print("Updated FPS:", config_manager.get_config_value('playback', 'default_fps'))