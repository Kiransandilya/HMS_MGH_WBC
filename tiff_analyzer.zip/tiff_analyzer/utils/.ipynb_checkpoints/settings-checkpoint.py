# tiff_analyzer/utils/settings.py

from typing import Any, Dict, Optional
import json
from pathlib import Path
from .logger import logger, log_function
from .config import config_manager

class Settings:
    """Manages application settings and preferences"""
    
    def __init__(self):
        self._settings: Dict[str, Dict[str, Any]] = {
            'general': {
                'load_last_session': True,
                'check_updates': True,
                'auto_save': True,
                'recent_files_limit': 10
            },
            'display': {
                'theme': 'dark',
                'default_view': 'side_by_side',
                'interpolation': True,
                'auto_contrast': True
            },
            'playback': {
                'default_fps': 10,
                'loop': True,
                'interpolation': False
            },
            'analysis': {
                'default_roi': 'rectangle',
                'auto_detection': True,
                'feature_extraction': 'basic'
            },
            'export': {
                'image_format': 'TIFF',
                'data_format': 'CSV'
            },
            'advanced': {
                'cache_size': 512,  # MB
                'debug_mode': False
            }
        }
        self._settings_file = Path(config_manager.config_dir) / 'settings.json'
        self.load_settings()
 
        self.ensure_configurations()
    
    @log_function
    def load_settings(self) -> None:
        """Load settings from file"""
        try:
            if self._settings_file.exists():
                with open(self._settings_file, 'r') as f:
                    stored_settings = json.load(f)
                    # Update only existing settings
                    for category, values in stored_settings.items():
                        if category in self._settings:
                            self._settings[category].update(values)
        except Exception as e:
            logger.log_error(e, {"context": "Loading settings"})
    
    @log_function
    def save_settings(self) -> None:
        """Save settings to file"""
        try:
            self._settings_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self._settings_file, 'w') as f:
                json.dump(self._settings, f, indent=4)
        except Exception as e:
            logger.log_error(e, {"context": "Saving settings"})
    
    def get(self, category: str, key: str, default: Any = None) -> Any:
        """Get setting value with robust error handling"""
        try:
            # Check if category exists
            if category not in self._settings:
                # If category doesn't exist, add it with the default
                self._settings[category] = {}
                return default
            
            # Check if key exists in category
            if key not in self._settings[category]:
                return default
            
            return self._settings[category][key]
        except Exception as e:
            logger.log_error(e, {"context": f"Getting setting: {category}.{key}"})
            return default
        
    def set(self, category: str, key: str, value: Any) -> None:
        """Set setting value with automatic category creation"""
        try:
            # Create category if it doesn't exist
            if category not in self._settings:
                self._settings[category] = {}
            
            # Set the value
            self._settings[category][key] = value
            
            # Save settings immediately
            self.save_settings()
        except Exception as e:
            logger.log_error(e, {"context": f"Setting value: {category}.{key}"})
    
    def get_category(self, category: str) -> Dict[str, Any]:
        """Get all settings in category"""
        return self._settings.get(category, {}).copy()
    
    @log_function
    def reset_category(self, category: str) -> None:
        """Reset category to defaults"""
        if category in self._settings:
            self._settings[category] = self._get_defaults()[category]
            self.save_settings()
    
    @log_function
    def reset_all(self) -> None:
        """Reset all settings to defaults"""
        self._settings = self._get_defaults()
        self.save_settings()
        
    
    # def _get_defaults(self) -> Dict[str, Dict[str, Any]]:
    #     """Get default settings with comprehensive configurations"""
    #     return {
    #         **self._settings,
    #         'general': {
    #             'load_last_session': True,
    #             'check_updates': True,
    #             'auto_save': True,
    #             'recent_files_limit': 10,
    #             'data_directory': str(Path.home() / '.tiff_analyzer' / 'data')
    #         },
    #         'view': {
    #             'theme': 'dark',
    #             'default_view': 'side_by_side',
    #             'interpolation': True,
    #             'auto_contrast': True,
    #             'overlay_alpha': 0.5
    #         },
    #         'core': {
    #             'cache_size': 512,  # MB
    #             'initial_state': None
    #         },
    #         'analysis': {
    #             'cache_size': 256,  # MB
    #             'default_roi': 'rectangle'
    #         },
    #         'plugins': {
    #             'configs': {},
    #             'enabled': []
    #         }
    #     }
    
    def _get_defaults(self) -> Dict[str, Dict[str, Any]]:
        """Get default settings with comprehensive configurations"""
        return {
            **self._settings,  # Preserve existing default settings
            'plugins': {
                'configs': {},  # Explicitly address 'plugins.configs' warning
                'enabled': []
            },
            'view': {
                'theme': 'dark',
                'overlay_alpha': 0.5,
                'sync_views': True
            },
            'core': {
                'cache_size': 512,
                'initial_state': None
            },
            'playback': {
                'default_fps': 10,
                'loop': True
            }
        }
    @property
    def categories(self) -> list:
        """Get list of setting categories"""
        return list(self._settings.keys())


    
    def validate_setting(self, category: str, key: str, value: Any) -> bool:
        """Validate setting value"""
        try:
            if category not in self._settings:
                return False
                
            # Type validation
            current_value = self._settings[category].get(key)
            if current_value is not None and not isinstance(value, type(current_value)):
                return False
                
            # Range validation for specific settings
            if category == 'general' and key == 'recent_files_limit':
                return 0 <= int(value) <= 50
                
            if category == 'playback' and key == 'default_fps':
                return 1 <= float(value) <= 60
                
            if category == 'advanced' and key == 'cache_size':
                return 64 <= int(value) <= 4096
                
            return True
            
        except (ValueError, TypeError):
            return False

    def ensure_configurations(self) -> None:
        """Ensure all required configurations are present"""
        defaults = self._get_defaults()
        for category, settings in defaults.items():
            if category not in self._settings:
                self._settings[category] = {}
            
            for key, default_value in settings.items():
                if key not in self._settings[category]:
                    self._settings[category][key] = default_value
        
        # Save to persist any added configurations
        self.save_settings()

# Create global settings instance
settings = Settings()

# Example usage
if __name__ == "__main__":
    # Test settings
    print("Theme:", settings.get('display', 'theme'))
    settings.set('display', 'theme', 'light')
    print("Updated theme:", settings.get('display', 'theme'))