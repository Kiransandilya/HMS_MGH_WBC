# tiff_analyzer/utils/plugins.py

from typing import Dict, List, Optional, Any, Type
import importlib.util
import inspect
from pathlib import Path
import abc
from .logger import logger, log_function
from .config import config_manager
from .events import event_manager, Event, EventType

class PluginBase(abc.ABC):
    """Base class for all plugins"""
    
    @abc.abstractmethod
    def initialize(self) -> bool:
        """Initialize the plugin"""
        pass
    
    @abc.abstractmethod
    def shutdown(self) -> None:
        """Shutdown the plugin"""
        pass
    
    @property
    @abc.abstractmethod
    def name(self) -> str:
        """Plugin name"""
        pass
    
    @property
    @abc.abstractmethod
    def version(self) -> str:
        """Plugin version"""
        pass
    
    @property
    @abc.abstractmethod
    def description(self) -> str:
        """Plugin description"""
        pass

class PluginManager:
    """Manages plugin loading, activation, and lifecycle"""
    
    def __init__(self):
        self._plugins: Dict[str, PluginBase] = {}
        self._active_plugins: Dict[str, bool] = {}
        self._plugin_dir = Path(config_manager.config_dir) / 'plugins'
        self._plugin_configs: Dict[str, Dict] = {}
        self._load_plugin_configs()
    
    def _load_plugin_configs(self) -> None:
        """Load plugin configurations"""
        config = config_manager.get_config_value('plugins', 'configs')
        if config:
            self._plugin_configs = config
    
    def _save_plugin_configs(self) -> None:
        """Save plugin configurations"""
        config_manager.set_config_value('plugins', 'configs', self._plugin_configs)
    
    @log_function
    def discover_plugins(self) -> List[str]:
        """Discover available plugins"""
        discovered = []
        
        # Create plugin directory if it doesn't exist
        self._plugin_dir.mkdir(parents=True, exist_ok=True)
        
        # Search for plugin files
        for plugin_file in self._plugin_dir.glob('*.py'):
            try:
                if self._is_valid_plugin(plugin_file):
                    discovered.append(plugin_file.stem)
            except Exception as e:
                logger.log_error(e, {
                    "context": "Plugin discovery",
                    "plugin_file": str(plugin_file)
                })
        
        return discovered
    
    def _is_valid_plugin(self, plugin_file: Path) -> bool:
        """Check if file contains valid plugin"""
        try:
            spec = importlib.util.spec_from_file_location(
                plugin_file.stem,
                str(plugin_file)
            )
            if spec and spec.loader:
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                
                # Look for plugin class
                for item in dir(module):
                    obj = getattr(module, item)
                    if (inspect.isclass(obj) and 
                        issubclass(obj, PluginBase) and 
                        obj != PluginBase):
                        return True
            return False
            
        except Exception as e:
            logger.log_error(e, {
                "context": "Plugin validation",
                "plugin_file": str(plugin_file)
            })
            return False
    
    @log_function
    def load_plugin(self, plugin_name: str) -> bool:
        """Load a specific plugin"""
        plugin_file = self._plugin_dir / f"{plugin_name}.py"
        
        try:
            if not plugin_file.exists():
                logger.logger.error(f"Plugin file not found: {plugin_file}")
                return False
            
            spec = importlib.util.spec_from_file_location(plugin_name, str(plugin_file))
            if spec and spec.loader:
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                
                # Find plugin class
                plugin_class = None
                for item in dir(module):
                    obj = getattr(module, item)
                    if (inspect.isclass(obj) and 
                        issubclass(obj, PluginBase) and 
                        obj != PluginBase):
                        plugin_class = obj
                        break
                
                if plugin_class:
                    plugin = plugin_class()
                    if plugin.initialize():
                        self._plugins[plugin_name] = plugin
                        self._active_plugins[plugin_name] = True
                        event_manager.emit(Event(
                            EventType.PLUGIN_LOADED,
                            data={'name': plugin_name}
                        ))
                        return True
            
            return False
            
        except Exception as e:
            logger.log_error(e, {
                "context": "Plugin loading",
                "plugin_name": plugin_name
            })
            return False
    
    @log_function
    def unload_plugin(self, plugin_name: str) -> bool:
        """Unload a specific plugin"""
        try:
            if plugin_name in self._plugins:
                plugin = self._plugins[plugin_name]
                plugin.shutdown()
                del self._plugins[plugin_name]
                del self._active_plugins[plugin_name]
                event_manager.emit(Event(
                    EventType.PLUGIN_UNLOADED,
                    data={'name': plugin_name}
                ))
                return True
            return False
            
        except Exception as e:
            logger.log_error(e, {
                "context": "Plugin unloading",
                "plugin_name": plugin_name
            })
            return False
    
    def get_plugin(self, plugin_name: str) -> Optional[PluginBase]:
        """Get plugin instance by name"""
        return self._plugins.get(plugin_name)
    
    def is_plugin_active(self, plugin_name: str) -> bool:
        """Check if plugin is active"""
        return self._active_plugins.get(plugin_name, False)
    
    @log_function
    def enable_plugin(self, plugin_name: str) -> bool:
        """Enable a plugin"""
        if plugin_name in self._plugins and not self._active_plugins[plugin_name]:
            try:
                if self._plugins[plugin_name].initialize():
                    self._active_plugins[plugin_name] = True
                    return True
            except Exception as e:
                logger.log_error(e, {
                    "context": "Plugin enabling",
                    "plugin_name": plugin_name
                })
        return False
    
    @log_function
    def disable_plugin(self, plugin_name: str) -> bool:
        """Disable a plugin"""
        if plugin_name in self._plugins and self._active_plugins[plugin_name]:
            try:
                self._plugins[plugin_name].shutdown()
                self._active_plugins[plugin_name] = False
                return True
            except Exception as e:
                logger.log_error(e, {
                    "context": "Plugin disabling",
                    "plugin_name": plugin_name
                })
        return False
    
    def get_plugin_info(self, plugin_name: str) -> Dict[str, Any]:
        """Get plugin information"""
        plugin = self.get_plugin(plugin_name)
        if plugin:
            return {
                'name': plugin.name,
                'version': plugin.version,
                'description': plugin.description,
                'active': self.is_plugin_active(plugin_name)
            }
        return {}
    
    def get_all_plugins(self) -> List[Dict[str, Any]]:
        """Get information about all plugins"""
        return [
            self.get_plugin_info(name)
            for name in self._plugins.keys()
        ]

# Create global plugin manager instance
plugin_manager = PluginManager()

# Example plugin class
class ExamplePlugin(PluginBase):
    def initialize(self) -> bool:
        return True
    
    def shutdown(self) -> None:
        pass
    
    @property
    def name(self) -> str:
        return "Example Plugin"
    
    @property
    def version(self) -> str:
        return "1.0.0"
    
    @property
    def description(self) -> str:
        return "An example plugin"

# Example usage
if __name__ == "__main__":
    # Test plugin management
    plugins = plugin_manager.discover_plugins()
    print(f"Discovered plugins: {plugins}")