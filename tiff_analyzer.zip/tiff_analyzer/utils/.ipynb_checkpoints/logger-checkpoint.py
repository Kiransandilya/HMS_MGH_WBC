# tiff_analyzer/utils/logger.py

import logging
import sys
from pathlib import Path
from datetime import datetime
from functools import wraps
import traceback
import json
from typing import Optional, Dict, Any

class TiffAnalyzerLogger:
    """
    Advanced logger for the TiffAnalyzer application.
    Handles different log levels, function entry/exit logging, and performance tracking.
    """
    
    def __init__(self, name: str = "TiffAnalyzer"):
        self._is_initialized = False
        self.logger = None
        self.name = name
        self.performance_logs: Dict[str, float] = {}
        self.initialize()
        
    def initialize(self) -> None:
        """Explicit initialization method"""
        try:
            # Create logger
            self.logger = logging.getLogger(self.name)
            self._setup_logger()
            
            # Mark as initialized
            self._is_initialized = True
            
            # Log initialization
            self.logger.info(f"{self.name} Logger initialized successfully")
        except Exception as e:
            self._is_initialized = False
            print(f"Logger initialization failed: {e}")
            raise
    
    def is_initialized(self) -> bool:
        """Check if logger is initialized"""
        return self._is_initialized
    
        
    def _setup_logger(self) -> None:
        """Configure the logger with appropriate handlers and formatters."""
        # Create logs directory if it doesn't exist
        logs_dir = Path(__file__).parent.parent / 'logs'
        logs_dir.mkdir(exist_ok=True)
        
        # Generate log filename with timestamp
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        log_file = logs_dir / f'tiff_analyzer_{timestamp}.log'
        
        # Create formatters
        file_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s'
        )
        console_formatter = logging.Formatter(
            '%(levelname)s: %(message)s'
        )
        
        # File handler
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(file_formatter)
        
        # Console handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(console_formatter)
        
        # Configure logger
        self.logger.setLevel(logging.DEBUG)
        self.logger.addHandler(file_handler)
        self.logger.addHandler(console_handler)
        
    def log_function_entry_exit(self, func_name: str) -> None:
        """Decorator to log function entry and exit."""
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                self.logger.debug(f"Entering function: {func_name}")
                try:
                    result = func(*args, **kwargs)
                    self.logger.debug(f"Exiting function: {func_name}")
                    return result
                except Exception as e:
                    self.logger.error(f"Error in function {func_name}: {str(e)}")
                    self.logger.error(f"Traceback: {traceback.format_exc()}")
                    raise
            return wrapper
        return decorator
    
    def log_performance(self, operation: str, duration: float) -> None:
        """Log performance metrics."""
        self.performance_logs[operation] = duration
        self.logger.info(f"Performance - {operation}: {duration:.4f} seconds")
    
    def export_performance_logs(self, filepath: Optional[str] = None) -> None:
        """Export performance logs to JSON file."""
        if not filepath:
            logs_dir = Path(__file__).parent.parent / 'logs'
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filepath = logs_dir / f'performance_logs_{timestamp}.json'
        
        with open(filepath, 'w') as f:
            json.dump(self.performance_logs, f, indent=4)
    
    def log_error(self, error: Exception, context: Dict[str, Any] = None) -> None:
        """Log detailed error information."""
        error_info = {
            'error_type': type(error).__name__,
            'error_message': str(error),
            'traceback': traceback.format_exc(),
            'context': context or {}
        }
        self.logger.error(f"Detailed error information: {json.dumps(error_info, indent=2)}")
    
    def log_state_change(self, component: str, old_state: Any, new_state: Any) -> None:
        """Log state changes in the application."""
        self.logger.debug(
            f"State change in {component}: {old_state} -> {new_state}"
        )
    
    def log_feature_usage(self, feature_name: str, success: bool) -> None:
        """Log feature usage statistics."""
        status = "successfully" if success else "unsuccessfully"
        self.logger.info(f"Feature '{feature_name}' used {status}")
    
    def get_recent_logs(self, num_lines: int = 100) -> list:
        """Retrieve recent log entries."""
        log_files = sorted(
            (Path(__file__).parent.parent / 'logs').glob('tiff_analyzer_*.log'),
            reverse=True
        )
        if not log_files:
            return []
            
        recent_logs = []
        with open(log_files[0], 'r') as f:
            recent_logs = f.readlines()[-num_lines:]
        return recent_logs

# Create a global logger instance
logger = TiffAnalyzerLogger()

# Decorator for function logging
def log_function(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        return logger.log_function_entry_exit(func.__name__)(func)(*args, **kwargs)
    return wrapper

    
# Example usage:
if __name__ == "__main__":
    # Test the logger
    @log_function
    def test_function():
        logger.logger.info("This is a test message")
        raise ValueError("Test error")
    
    try:
        test_function()
    except ValueError:
        pass  # Expected error