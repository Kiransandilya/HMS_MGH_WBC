# tiff_analyzer/utils/events.py

from typing import Dict, List, Callable, Any
from enum import Enum, auto
import queue
import threading
from .logger import logger, log_function
import time 

class EventType(Enum):
    """Defines all possible event types in the application"""
    # File events
    FILE_LOADED = auto()
    FILE_SAVED = auto()
    FILE_CLOSED = auto()
    
    # View events
    VIEW_CHANGED = auto()
    ZOOM_CHANGED = auto()
    CONTRAST_CHANGED = auto()
    
    # Playback events
    PLAYBACK_STARTED = auto()
    PLAYBACK_PAUSED = auto()
    PLAYBACK_STOPPED = auto()
    FRAME_CHANGED = auto()
    
    # Analysis events
    ROI_CREATED = auto()
    ROI_MODIFIED = auto()
    ROI_DELETED = auto()
    ANALYSIS_STARTED = auto()
    ANALYSIS_COMPLETED = auto()
    ANALYSIS_ERROR = auto()
    
    # State events
    STATE_CHANGED = auto()
    SETTINGS_CHANGED = auto()
    
    # Error events
    ERROR_OCCURRED = auto()

class Event:
    """Represents an event in the system"""
    
    def __init__(self, event_type: EventType, data: Any = None, source: Any = None):
        self.type = event_type
        self.data = data
        self.source = source
        self.timestamp = time.time()

class EventManager:
    """Manages event dispatching and handling"""
    
    def __init__(self):
        self._handlers: Dict[EventType, List[Callable]] = {}
        self._event_queue = queue.Queue()
        self._is_processing = False
        self._lock = threading.Lock()
        self._start_event_processing()
    
    @log_function
    def subscribe(self, event_type: EventType, handler: Callable) -> None:
        """Subscribe to an event type"""
        with self._lock:
            if event_type not in self._handlers:
                self._handlers[event_type] = []
            if handler not in self._handlers[event_type]:
                self._handlers[event_type].append(handler)
                logger.logger.debug(f"Subscribed handler to {event_type.name}")
    
    @log_function
    def unsubscribe(self, event_type: EventType, handler: Callable) -> None:
        """Unsubscribe from an event type"""
        with self._lock:
            if event_type in self._handlers and handler in self._handlers[event_type]:
                self._handlers[event_type].remove(handler)
                logger.logger.debug(f"Unsubscribed handler from {event_type.name}")
    
    @log_function
    def emit(self, event: Event) -> None:
        """Emit an event"""
        try:
            self._event_queue.put(event)
            logger.logger.debug(f"Emitted event: {event.type.name}")
        except Exception as e:
            logger.log_error(e, {
                "context": "Event emission",
                "event_type": event.type.name
            })
    
    def _start_event_processing(self) -> None:
        """Start event processing thread"""
        self._is_processing = True
        threading.Thread(target=self._process_events, daemon=True).start()
    
    def _process_events(self) -> None:
        """Process events from queue"""
        while self._is_processing:
            try:
                event = self._event_queue.get(timeout=0.1)
                self._dispatch_event(event)
                self._event_queue.task_done()
            except queue.Empty:
                continue
            except Exception as e:
                logger.log_error(e, {"context": "Event processing"})
    
    def _dispatch_event(self, event: Event) -> None:
        """Dispatch event to all registered handlers"""
        with self._lock:
            if event.type in self._handlers:
                for handler in self._handlers[event.type]:
                    try:
                        handler(event)
                    except Exception as e:
                        logger.log_error(e, {
                            "context": "Event handling",
                            "event_type": event.type.name,
                            "handler": str(handler)
                        })
    
    @log_function
    def shutdown(self) -> None:
        """Shutdown event processing"""
        self._is_processing = False
        # Clear any remaining events
        while not self._event_queue.empty():
            try:
                self._event_queue.get_nowait()
                self._event_queue.task_done()
            except queue.Empty:
                break

# Create global event manager instance
event_manager = EventManager()

# Example usage
if __name__ == "__main__":
    def on_frame_change(event: Event):
        print(f"Frame changed to: {event.data}")
    
    # Subscribe to frame change events
    event_manager.subscribe(EventType.FRAME_CHANGED, on_frame_change)
    
    # Emit a frame change event
    event_manager.emit(Event(EventType.FRAME_CHANGED, data=5))
    
    # Wait for event processing
    import time
    time.sleep(0.1)
    
    # Clean up
    event_manager.shutdown()