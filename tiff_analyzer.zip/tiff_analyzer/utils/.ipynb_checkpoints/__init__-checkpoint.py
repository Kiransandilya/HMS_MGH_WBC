# tiff_analyzer/utils/__init__.py

from typing import Dict, Any
import sys
from pathlib import Path

# Import utility components
from .logger import logger
from .config import config_manager
from .settings import settings
from .events import event_manager, EventType, Event
from .plugins import plugin_manager

class UtilsManager:
    """Manages initialization and coordination of utility components"""
    
    def __init__(self):
        self._initialized = False
        self._components = {
            'logger': logger,
            'config': config_manager,
            'settings': settings,
            'events': event_manager,
            'plugins': plugin_manager
        }
    
    def initialize(self) -> bool:
        """Initialize all utility components in correct order"""
        if self._initialized:
            return True
            
        try:
            # Initialize components in dependency order
            self._init_logger()
            self._init_config()
            self._init_settings()
            self._init_events()
            self._init_plugins()
            
            self._initialized = True
            logger.logger.info("Utility components initialized successfully")
            return True
            
        except Exception as e:
            print(f"Error initializing utilities: {str(e)}")
            return False
    
    def _init_logger(self) -> None:
        """Ensure logger is properly initialized"""
        try:
            logger.logger.info("Logger initialized")
        except Exception as e:
            print(f"Failed to initialize logger: {str(e)}")
            sys.exit(1)
    
    def _init_config(self) -> None:
        """Initialize configuration manager"""
        try:
            config_dir = Path.home() / '.tiff_analyzer'
            config_dir.mkdir(exist_ok=True, parents=True)
            logger.logger.info("Configuration manager initialized")
        except Exception as e:
            logger.log_error(e, {"context": "Config initialization"})
            raise
    
    def _init_settings(self) -> None:
        """Initialize settings manager"""
        try:
            # Ensure all default configurations are present
            settings.ensure_configurations()
            
            # Load settings or reset to defaults if loading fails
            if not settings._settings_file.exists():
                settings.reset_all()
            else:
                settings.load_settings()
            
            logger.logger.info("Settings manager initialized")
        except Exception as e:
            logger.log_error(e, {"context": "Settings initialization"})
            raise
    
    def _init_events(self) -> None:
        """Initialize event system"""
        try:
            # Register core event handlers
            event_manager.subscribe(EventType.ERROR_OCCURRED, self._handle_error)
            logger.logger.info("Event manager initialized")
        except Exception as e:
            logger.log_error(e, {"context": "Events initialization"})
            raise
    
    def _init_plugins(self) -> None:
        """Initialize plugin system"""
        try:
            # Discover and load enabled plugins
            discovered = plugin_manager.discover_plugins()
            logger.logger.info(f"Discovered {len(discovered)} plugins")
        except Exception as e:
            logger.log_error(e, {"context": "Plugins initialization"})
            raise
    
    def _handle_error(self, event: Event) -> None:
        """Handle error events"""
        error_data = event.data
        logger.log_error(
            error_data.get('error'),
            error_data.get('context', {})
        )
    
    def shutdown(self) -> None:
        """Shutdown all utility components"""
        if not self._initialized:
            return
            
        try:
            # Shutdown in reverse order
            plugin_manager.unload_all_plugins()
            event_manager.shutdown()
            settings.save_settings()
            
            self._initialized = False
            logger.logger.info("Utility components shut down successfully")
            
        except Exception as e:
            logger.log_error(e, {"context": "Utils shutdown"})
    
    def get_component(self, name: str) -> Any:
        """Get utility component by name"""
        return self._components.get(name)
    
    def get_status(self) -> Dict[str, Any]:
        """Get status of all utility components"""
        return {
            'initialized': self._initialized,
            'logger': logger.is_initialized(),
            'config': bool(config_manager.is_initialized) if hasattr(config_manager, 'is_initialized') else False,
            'settings': bool(settings.get_category('general')),
            'events': getattr(event_manager, '_is_processing', False),
            'plugins': len(plugin_manager.get_all_plugins())
        }

# Create global utils manager instance
utils_manager = UtilsManager()

# Initialize utilities on import
if not utils_manager.initialize():
    sys.exit(1)

# Export components
__all__ = [
    'utils_manager',
    'logger',
    'config_manager',
    'settings',
    'event_manager',
    'EventType',
    'Event',
    'plugin_manager'
]